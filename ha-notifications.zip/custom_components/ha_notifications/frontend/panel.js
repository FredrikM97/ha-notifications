// frontend/editor/types.ts
var editorSections = [
  { title: "Basic" },
  { title: "When to check" },
  { title: "Condition" },
  { title: "Recipients" },
  { title: "Notification" },
  {
    title: "Post-send actions",
    setting: "postSendActions",
    parent: "Notification",
    status: "postSendActions"
  },
  { title: "Confirmation", setting: "confirmation", status: "confirmation" },
  {
    title: "Reminder policy",
    setting: "confirmationReminder",
    parent: "Confirmation",
    status: "confirmationReminder"
  },
  {
    title: "Notify recipients when confirmed",
    setting: "confirmationNotification",
    parent: "Confirmation",
    status: "confirmationNotification"
  },
  {
    title: "Post-confirmation actions",
    setting: "postConfirmationActions",
    parent: "Confirmation",
    status: "postConfirmationActions"
  }
];
var ACTIONS_PLACEHOLDER = `- action: switch.turn_on
  metadata: {}
  target:
    entity_id:
      - switch.garage_door
      - light.living_room
  data: {}`;
var clone = (value) => JSON.parse(JSON.stringify(value));

// frontend/alert-payload.ts
function durationToSeconds(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return Math.max(0, value);
  }
  if (typeof value === "string") {
    const parts = value.split(":").map(Number);
    if (parts.some((part) => !Number.isFinite(part))) return void 0;
    if (parts.length === 2) parts.unshift(0);
    if (parts.length !== 3) return void 0;
    return Math.max(0, parts[0] * 3600 + parts[1] * 60 + parts[2]);
  }
  if (value && typeof value === "object") {
    return Math.max(
      0,
      (Number(value.hours) || 0) * 3600 + (Number(value.minutes) || 0) * 60 + (Number(value.seconds) || 0)
    );
  }
  return void 0;
}
function requiredDurationSeconds(value, field2) {
  if (value === void 0) {
    return void 0;
  }
  const seconds = durationToSeconds(value);
  if (seconds === void 0) {
    throw new Error(`${field2} must be a valid duration.`);
  }
  return seconds;
}
function serializeAlertDurations(alert) {
  const result = clone(alert);
  if (result.monitor) {
    const evaluateInterval = requiredDurationSeconds(
      result.monitor.interval,
      "Monitor interval"
    );
    if (evaluateInterval !== void 0) {
      result.monitor.interval = evaluateInterval;
    }
  }
  result.conditions = serializeConditionDurations(result.conditions);
  if (result.confirmation?.reminders) {
    const interval = requiredDurationSeconds(
      result.confirmation.reminders.interval,
      "Confirmation reminder interval"
    );
    const timeout = requiredDurationSeconds(
      result.confirmation.reminders.timeout,
      "Confirmation timeout"
    );
    result.confirmation = {
      ...result.confirmation,
      reminders: {
        ...result.confirmation.reminders,
        ...interval === void 0 ? {} : { interval },
        ...timeout === void 0 ? {} : { timeout }
      }
    };
  }
  return result;
}
function serializeConditionDurations(condition) {
  return condition.map(
    (item) => Object.fromEntries(
      Object.entries(item).map(([key, value]) => {
        if (key === "for") {
          return [
            key,
            requiredDurationSeconds(
              value,
              "Condition duration"
            )
          ];
        }
        if (Array.isArray(value)) {
          return [
            key,
            value.map(
              (item2) => item2 && typeof item2 === "object" ? serializeConditionDurations([item2])[0] : item2
            )
          ];
        }
        if (value && typeof value === "object") {
          return [
            key,
            serializeConditionDurations([value])[0]
          ];
        }
        return [key, value];
      })
    )
  );
}
function hasRecipients(target) {
  return Object.values(target).some(
    (values) => Array.isArray(values) && values.length > 0
  );
}
function buildAlertPayload(original, values, validate = true) {
  const result = clone(original);
  delete result.runtime;
  if (validate && !hasRecipients(values.notification.target)) {
    throw new Error(
      "Select at least one device, area, label, or notification entity in Recipients."
    );
  }
  result.name = values.identity.name.trim();
  result.description = values.identity.description;
  result.icon = values.identity.icon?.trim() || result.icon || "mdi:bell-outline";
  result.conditions = values.evaluate.condition;
  result.monitor = {
    ...result.monitor,
    on_change: values.evaluate.onChange,
    startup: values.evaluate.startup
  };
  if (values.evaluate.clearOnInactive !== void 0) {
    result.monitor.clear_on_inactive = values.evaluate.clearOnInactive;
  }
  if (values.evaluate.interval) {
    result.monitor.interval = values.evaluate.interval;
  }
  result.notification = {
    ...result.notification,
    target: values.notification.target,
    data: {
      ...result.notification.data,
      title: values.notification.title,
      message: values.notification.message
    }
  };
  result.confirmation = {
    ...values.confirmation,
    notification: {
      ...result.confirmation?.notification,
      target: result.confirmation?.notification.target || values.notification.target,
      data: {
        ...result.confirmation?.notification.data,
        message: values.confirmation.notification.message
      }
    },
    actions: values.confirmation.actions.enabled ? values.confirmation.actions.items ?? [] : result.confirmation?.actions ?? []
  };
  if (values.post_send_actions.actions?.length || values.post_send_actions.postSendActionsEnabled || result.post_send_actions) {
    result.post_send_actions = {
      ...result.post_send_actions,
      enabled: values.post_send_actions.postSendActionsEnabled,
      ...values.post_send_actions.postSendActionsEnabled || values.post_send_actions.actions?.length ? { actions: values.post_send_actions.actions } : {}
    };
  }
  return serializeAlertDurations(result);
}

// frontend/api.ts
var DOMAIN = "ha_notifications";
function errorMessage(error) {
  if (error instanceof Error) {
    return error.message;
  }
  if (typeof error === "object" && error !== null) {
    const value = error;
    const nestedError = value.error;
    const details = value.details;
    return String(
      nestedError?.message || details?.message || value.message || error
    );
  }
  return String(error);
}
async function call(hass, command, data = {}) {
  try {
    return await hass.connection.sendMessagePromise({
      type: `${DOMAIN}/${command}`,
      ...data
    });
  } catch (error) {
    throw new Error(`${DOMAIN}/${command}: ${errorMessage(error)}`);
  }
}
async function callRegistry(hass, type) {
  const result = await hass.connection.sendMessagePromise({ type });
  if (Array.isArray(result)) {
    return result;
  }
  return [];
}
function toCanonicalAlert(alert) {
  const serialized = serializeAlertDurations(alert);
  const { runtime: _runtime, ...canonical } = serialized;
  return canonical;
}
async function loadRegistries(hass) {
  const [entities, states, devices, areas, labels, floors, users] = await Promise.all([
    callRegistry(hass, "config/entity_registry/list"),
    callRegistry(hass, "get_states"),
    callRegistry(hass, "config/device_registry/list"),
    callRegistry(hass, "config/area_registry/list"),
    callRegistry(hass, "config/label_registry/list"),
    callRegistry(hass, "config/floor_registry/list"),
    callRegistry(hass, "config/auth/list")
  ]);
  const friendlyNames = new Map(
    states.map((state) => [state.entity_id, state.attributes?.friendly_name])
  );
  return {
    entities: entities.map((entity) => ({
      ...entity,
      friendly_name: friendlyNames.get(entity.entity_id) || entity.friendly_name
    })),
    devices,
    areas,
    labels,
    floors,
    users
  };
}
async function getAlerts(hass) {
  const config = await call(hass, "get_config");
  if (!config || typeof config !== "object" || Array.isArray(config)) {
    throw new Error(
      "ha_notifications/get_config: expected canonical configuration with an alerts array."
    );
  }
  const alerts = config.alerts;
  if (!Array.isArray(alerts)) {
    throw new Error(
      "ha_notifications/get_config: expected canonical configuration with an alerts array."
    );
  }
  return alerts;
}
function getAutomationStatus(hass) {
  return call(hass, "automation_status");
}
function triggerAlert(hass, alertId) {
  return call(hass, "trigger", { alert_id: alertId });
}
function getHistory(hass, alertId) {
  return call(hass, "get_history", {
    ...alertId ? { alert_id: alertId } : {}
  });
}
async function saveAlert(hass, alert) {
  if (!alert.id || typeof alert.id !== "string") {
    throw new Error("ha_notifications/save_config: alert.id is required.");
  }
  const config = await getConfig(hass);
  const canonicalAlert = toCanonicalAlert(alert);
  const alerts = config.alerts.some(({ id }) => id === alert.id) ? config.alerts.map(
    (existingAlert) => existingAlert.id === alert.id ? canonicalAlert : existingAlert
  ) : [...config.alerts, canonicalAlert];
  const result = await saveConfig(hass, { ...config, alerts });
  const savedAlert = result.config.alerts.find(({ id }) => id === alert.id);
  if (!savedAlert) {
    throw new Error(`ha_notifications/save_config: saved alert ${alert.id} was not returned.`);
  }
  return savedAlert;
}
async function deleteAlert(hass, alertId) {
  const config = await getConfig(hass);
  if (!config.alerts.some(({ id }) => id === alertId)) {
    throw new Error(`ha_notifications/save_config: alert ${alertId} was not found.`);
  }
  return saveConfig(hass, {
    ...config,
    alerts: config.alerts.filter(({ id }) => id !== alertId)
  });
}
async function getConfig(hass) {
  return call(hass, "get_config");
}
async function validateConfig(hass, config) {
  return call(hass, "validate_config", {
    config
  });
}
async function validateAlert(hass, alert) {
  const config = await getConfig(hass);
  const canonicalAlert = toCanonicalAlert(alert);
  const alerts = config.alerts.some(({ id }) => id === alert.id) ? config.alerts.map(
    (existingAlert) => existingAlert.id === alert.id ? canonicalAlert : existingAlert
  ) : [...config.alerts, canonicalAlert];
  return validateConfig(hass, { ...config, alerts });
}
async function saveConfig(hass, config) {
  return call(
    hass,
    "save_config",
    {
      config
    }
  );
}
async function reload(hass) {
  return call(hass, "reload");
}

// node_modules/@lit/reactive-element/css-tag.js
var t = globalThis;
var e = t.ShadowRoot && (void 0 === t.ShadyCSS || t.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;
var s = /* @__PURE__ */ Symbol();
var o = /* @__PURE__ */ new WeakMap();
var n = class {
  constructor(t5, e5, o7) {
    if (this._$cssResult$ = true, o7 !== s) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t5, this.t = e5;
  }
  get styleSheet() {
    let t5 = this.o;
    const s5 = this.t;
    if (e && void 0 === t5) {
      const e5 = void 0 !== s5 && 1 === s5.length;
      e5 && (t5 = o.get(s5)), void 0 === t5 && ((this.o = t5 = new CSSStyleSheet()).replaceSync(this.cssText), e5 && o.set(s5, t5));
    }
    return t5;
  }
  toString() {
    return this.cssText;
  }
};
var r = (t5) => new n("string" == typeof t5 ? t5 : t5 + "", void 0, s);
var S = (s5, o7) => {
  if (e) s5.adoptedStyleSheets = o7.map((t5) => t5 instanceof CSSStyleSheet ? t5 : t5.styleSheet);
  else for (const e5 of o7) {
    const o8 = document.createElement("style"), n6 = t.litNonce;
    void 0 !== n6 && o8.setAttribute("nonce", n6), o8.textContent = e5.cssText, s5.appendChild(o8);
  }
};
var c = e ? (t5) => t5 : (t5) => t5 instanceof CSSStyleSheet ? ((t6) => {
  let e5 = "";
  for (const s5 of t6.cssRules) e5 += s5.cssText;
  return r(e5);
})(t5) : t5;

// node_modules/@lit/reactive-element/reactive-element.js
var { is: i2, defineProperty: e2, getOwnPropertyDescriptor: h, getOwnPropertyNames: r2, getOwnPropertySymbols: o2, getPrototypeOf: n2 } = Object;
var a = globalThis;
var c2 = a.trustedTypes;
var l = c2 ? c2.emptyScript : "";
var p = a.reactiveElementPolyfillSupport;
var d = (t5, s5) => t5;
var u = { toAttribute(t5, s5) {
  switch (s5) {
    case Boolean:
      t5 = t5 ? l : null;
      break;
    case Object:
    case Array:
      t5 = null == t5 ? t5 : JSON.stringify(t5);
  }
  return t5;
}, fromAttribute(t5, s5) {
  let i6 = t5;
  switch (s5) {
    case Boolean:
      i6 = null !== t5;
      break;
    case Number:
      i6 = null === t5 ? null : Number(t5);
      break;
    case Object:
    case Array:
      try {
        i6 = JSON.parse(t5);
      } catch (t6) {
        i6 = null;
      }
  }
  return i6;
} };
var f = (t5, s5) => !i2(t5, s5);
var b = { attribute: true, type: String, converter: u, reflect: false, useDefault: false, hasChanged: f };
Symbol.metadata ??= /* @__PURE__ */ Symbol("metadata"), a.litPropertyMetadata ??= /* @__PURE__ */ new WeakMap();
var y = class extends HTMLElement {
  static addInitializer(t5) {
    this._$Ei(), (this.l ??= []).push(t5);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t5, s5 = b) {
    if (s5.state && (s5.attribute = false), this._$Ei(), this.prototype.hasOwnProperty(t5) && ((s5 = Object.create(s5)).wrapped = true), this.elementProperties.set(t5, s5), !s5.noAccessor) {
      const i6 = /* @__PURE__ */ Symbol(), h4 = this.getPropertyDescriptor(t5, i6, s5);
      void 0 !== h4 && e2(this.prototype, t5, h4);
    }
  }
  static getPropertyDescriptor(t5, s5, i6) {
    const { get: e5, set: r6 } = h(this.prototype, t5) ?? { get() {
      return this[s5];
    }, set(t6) {
      this[s5] = t6;
    } };
    return { get: e5, set(s6) {
      const h4 = e5?.call(this);
      r6?.call(this, s6), this.requestUpdate(t5, h4, i6);
    }, configurable: true, enumerable: true };
  }
  static getPropertyOptions(t5) {
    return this.elementProperties.get(t5) ?? b;
  }
  static _$Ei() {
    if (this.hasOwnProperty(d("elementProperties"))) return;
    const t5 = n2(this);
    t5.finalize(), void 0 !== t5.l && (this.l = [...t5.l]), this.elementProperties = new Map(t5.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(d("finalized"))) return;
    if (this.finalized = true, this._$Ei(), this.hasOwnProperty(d("properties"))) {
      const t6 = this.properties, s5 = [...r2(t6), ...o2(t6)];
      for (const i6 of s5) this.createProperty(i6, t6[i6]);
    }
    const t5 = this[Symbol.metadata];
    if (null !== t5) {
      const s5 = litPropertyMetadata.get(t5);
      if (void 0 !== s5) for (const [t6, i6] of s5) this.elementProperties.set(t6, i6);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [t6, s5] of this.elementProperties) {
      const i6 = this._$Eu(t6, s5);
      void 0 !== i6 && this._$Eh.set(i6, t6);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(s5) {
    const i6 = [];
    if (Array.isArray(s5)) {
      const e5 = new Set(s5.flat(1 / 0).reverse());
      for (const s6 of e5) i6.unshift(c(s6));
    } else void 0 !== s5 && i6.push(c(s5));
    return i6;
  }
  static _$Eu(t5, s5) {
    const i6 = s5.attribute;
    return false === i6 ? void 0 : "string" == typeof i6 ? i6 : "string" == typeof t5 ? t5.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = false, this.hasUpdated = false, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t5) => this.enableUpdating = t5), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t5) => t5(this));
  }
  addController(t5) {
    (this._$EO ??= /* @__PURE__ */ new Set()).add(t5), void 0 !== this.renderRoot && this.isConnected && t5.hostConnected?.();
  }
  removeController(t5) {
    this._$EO?.delete(t5);
  }
  _$E_() {
    const t5 = /* @__PURE__ */ new Map(), s5 = this.constructor.elementProperties;
    for (const i6 of s5.keys()) this.hasOwnProperty(i6) && (t5.set(i6, this[i6]), delete this[i6]);
    t5.size > 0 && (this._$Ep = t5);
  }
  createRenderRoot() {
    const t5 = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return S(t5, this.constructor.elementStyles), t5;
  }
  connectedCallback() {
    this.renderRoot ??= this.createRenderRoot(), this.enableUpdating(true), this._$EO?.forEach((t5) => t5.hostConnected?.());
  }
  enableUpdating(t5) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t5) => t5.hostDisconnected?.());
  }
  attributeChangedCallback(t5, s5, i6) {
    this._$AK(t5, i6);
  }
  _$ET(t5, s5) {
    const i6 = this.constructor.elementProperties.get(t5), e5 = this.constructor._$Eu(t5, i6);
    if (void 0 !== e5 && true === i6.reflect) {
      const h4 = (void 0 !== i6.converter?.toAttribute ? i6.converter : u).toAttribute(s5, i6.type);
      this._$Em = t5, null == h4 ? this.removeAttribute(e5) : this.setAttribute(e5, h4), this._$Em = null;
    }
  }
  _$AK(t5, s5) {
    const i6 = this.constructor, e5 = i6._$Eh.get(t5);
    if (void 0 !== e5 && this._$Em !== e5) {
      const t6 = i6.getPropertyOptions(e5), h4 = "function" == typeof t6.converter ? { fromAttribute: t6.converter } : void 0 !== t6.converter?.fromAttribute ? t6.converter : u;
      this._$Em = e5;
      const r6 = h4.fromAttribute(s5, t6.type);
      this[e5] = r6 ?? this._$Ej?.get(e5) ?? r6, this._$Em = null;
    }
  }
  requestUpdate(t5, s5, i6, e5 = false, h4) {
    if (void 0 !== t5) {
      const r6 = this.constructor;
      if (false === e5 && (h4 = this[t5]), i6 ??= r6.getPropertyOptions(t5), !((i6.hasChanged ?? f)(h4, s5) || i6.useDefault && i6.reflect && h4 === this._$Ej?.get(t5) && !this.hasAttribute(r6._$Eu(t5, i6)))) return;
      this.C(t5, s5, i6);
    }
    false === this.isUpdatePending && (this._$ES = this._$EP());
  }
  C(t5, s5, { useDefault: i6, reflect: e5, wrapped: h4 }, r6) {
    i6 && !(this._$Ej ??= /* @__PURE__ */ new Map()).has(t5) && (this._$Ej.set(t5, r6 ?? s5 ?? this[t5]), true !== h4 || void 0 !== r6) || (this._$AL.has(t5) || (this.hasUpdated || i6 || (s5 = void 0), this._$AL.set(t5, s5)), true === e5 && this._$Em !== t5 && (this._$Eq ??= /* @__PURE__ */ new Set()).add(t5));
  }
  async _$EP() {
    this.isUpdatePending = true;
    try {
      await this._$ES;
    } catch (t6) {
      Promise.reject(t6);
    }
    const t5 = this.scheduleUpdate();
    return null != t5 && await t5, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ??= this.createRenderRoot(), this._$Ep) {
        for (const [t7, s6] of this._$Ep) this[t7] = s6;
        this._$Ep = void 0;
      }
      const t6 = this.constructor.elementProperties;
      if (t6.size > 0) for (const [s6, i6] of t6) {
        const { wrapped: t7 } = i6, e5 = this[s6];
        true !== t7 || this._$AL.has(s6) || void 0 === e5 || this.C(s6, void 0, i6, e5);
      }
    }
    let t5 = false;
    const s5 = this._$AL;
    try {
      t5 = this.shouldUpdate(s5), t5 ? (this.willUpdate(s5), this._$EO?.forEach((t6) => t6.hostUpdate?.()), this.update(s5)) : this._$EM();
    } catch (s6) {
      throw t5 = false, this._$EM(), s6;
    }
    t5 && this._$AE(s5);
  }
  willUpdate(t5) {
  }
  _$AE(t5) {
    this._$EO?.forEach((t6) => t6.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = true, this.firstUpdated(t5)), this.updated(t5);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = false;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t5) {
    return true;
  }
  update(t5) {
    this._$Eq &&= this._$Eq.forEach((t6) => this._$ET(t6, this[t6])), this._$EM();
  }
  updated(t5) {
  }
  firstUpdated(t5) {
  }
};
y.elementStyles = [], y.shadowRootOptions = { mode: "open" }, y[d("elementProperties")] = /* @__PURE__ */ new Map(), y[d("finalized")] = /* @__PURE__ */ new Map(), p?.({ ReactiveElement: y }), (a.reactiveElementVersions ??= []).push("2.1.2");

// node_modules/lit-html/lit-html.js
var t2 = globalThis;
var i3 = (t5) => t5;
var s2 = t2.trustedTypes;
var e3 = s2 ? s2.createPolicy("lit-html", { createHTML: (t5) => t5 }) : void 0;
var h2 = "$lit$";
var o3 = `lit$${Math.random().toFixed(9).slice(2)}$`;
var n3 = "?" + o3;
var r3 = `<${n3}>`;
var l2 = document;
var c3 = () => l2.createComment("");
var a2 = (t5) => null === t5 || "object" != typeof t5 && "function" != typeof t5;
var u2 = Array.isArray;
var d2 = (t5) => u2(t5) || "function" == typeof t5?.[Symbol.iterator];
var f2 = "[ 	\n\f\r]";
var v = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g;
var _ = /-->/g;
var m = />/g;
var p2 = RegExp(`>|${f2}(?:([^\\s"'>=/]+)(${f2}*=${f2}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g");
var g = /'/g;
var $ = /"/g;
var y2 = /^(?:script|style|textarea|title)$/i;
var x = (t5) => (i6, ...s5) => ({ _$litType$: t5, strings: i6, values: s5 });
var b2 = x(1);
var w = x(2);
var T = x(3);
var E = /* @__PURE__ */ Symbol.for("lit-noChange");
var A = /* @__PURE__ */ Symbol.for("lit-nothing");
var C = /* @__PURE__ */ new WeakMap();
var P = l2.createTreeWalker(l2, 129);
function V(t5, i6) {
  if (!u2(t5) || !t5.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return void 0 !== e3 ? e3.createHTML(i6) : i6;
}
var N = (t5, i6) => {
  const s5 = t5.length - 1, e5 = [];
  let n6, l3 = 2 === i6 ? "<svg>" : 3 === i6 ? "<math>" : "", c5 = v;
  for (let i7 = 0; i7 < s5; i7++) {
    const s6 = t5[i7];
    let a3, u3, d3 = -1, f4 = 0;
    for (; f4 < s6.length && (c5.lastIndex = f4, u3 = c5.exec(s6), null !== u3); ) f4 = c5.lastIndex, c5 === v ? "!--" === u3[1] ? c5 = _ : void 0 !== u3[1] ? c5 = m : void 0 !== u3[2] ? (y2.test(u3[2]) && (n6 = RegExp("</" + u3[2], "g")), c5 = p2) : void 0 !== u3[3] && (c5 = p2) : c5 === p2 ? ">" === u3[0] ? (c5 = n6 ?? v, d3 = -1) : void 0 === u3[1] ? d3 = -2 : (d3 = c5.lastIndex - u3[2].length, a3 = u3[1], c5 = void 0 === u3[3] ? p2 : '"' === u3[3] ? $ : g) : c5 === $ || c5 === g ? c5 = p2 : c5 === _ || c5 === m ? c5 = v : (c5 = p2, n6 = void 0);
    const x2 = c5 === p2 && t5[i7 + 1].startsWith("/>") ? " " : "";
    l3 += c5 === v ? s6 + r3 : d3 >= 0 ? (e5.push(a3), s6.slice(0, d3) + h2 + s6.slice(d3) + o3 + x2) : s6 + o3 + (-2 === d3 ? i7 : x2);
  }
  return [V(t5, l3 + (t5[s5] || "<?>") + (2 === i6 ? "</svg>" : 3 === i6 ? "</math>" : "")), e5];
};
var S2 = class _S {
  constructor({ strings: t5, _$litType$: i6 }, e5) {
    let r6;
    this.parts = [];
    let l3 = 0, a3 = 0;
    const u3 = t5.length - 1, d3 = this.parts, [f4, v2] = N(t5, i6);
    if (this.el = _S.createElement(f4, e5), P.currentNode = this.el.content, 2 === i6 || 3 === i6) {
      const t6 = this.el.content.firstChild;
      t6.replaceWith(...t6.childNodes);
    }
    for (; null !== (r6 = P.nextNode()) && d3.length < u3; ) {
      if (1 === r6.nodeType) {
        if (r6.hasAttributes()) for (const t6 of r6.getAttributeNames()) if (t6.endsWith(h2)) {
          const i7 = v2[a3++], s5 = r6.getAttribute(t6).split(o3), e6 = /([.?@])?(.*)/.exec(i7);
          d3.push({ type: 1, index: l3, name: e6[2], strings: s5, ctor: "." === e6[1] ? I : "?" === e6[1] ? L : "@" === e6[1] ? z : H }), r6.removeAttribute(t6);
        } else t6.startsWith(o3) && (d3.push({ type: 6, index: l3 }), r6.removeAttribute(t6));
        if (y2.test(r6.tagName)) {
          const t6 = r6.textContent.split(o3), i7 = t6.length - 1;
          if (i7 > 0) {
            r6.textContent = s2 ? s2.emptyScript : "";
            for (let s5 = 0; s5 < i7; s5++) r6.append(t6[s5], c3()), P.nextNode(), d3.push({ type: 2, index: ++l3 });
            r6.append(t6[i7], c3());
          }
        }
      } else if (8 === r6.nodeType) if (r6.data === n3) d3.push({ type: 2, index: l3 });
      else {
        let t6 = -1;
        for (; -1 !== (t6 = r6.data.indexOf(o3, t6 + 1)); ) d3.push({ type: 7, index: l3 }), t6 += o3.length - 1;
      }
      l3++;
    }
  }
  static createElement(t5, i6) {
    const s5 = l2.createElement("template");
    return s5.innerHTML = t5, s5;
  }
};
function M(t5, i6, s5 = t5, e5) {
  if (i6 === E) return i6;
  let h4 = void 0 !== e5 ? s5._$Co?.[e5] : s5._$Cl;
  const o7 = a2(i6) ? void 0 : i6._$litDirective$;
  return h4?.constructor !== o7 && (h4?._$AO?.(false), void 0 === o7 ? h4 = void 0 : (h4 = new o7(t5), h4._$AT(t5, s5, e5)), void 0 !== e5 ? (s5._$Co ??= [])[e5] = h4 : s5._$Cl = h4), void 0 !== h4 && (i6 = M(t5, h4._$AS(t5, i6.values), h4, e5)), i6;
}
var R = class {
  constructor(t5, i6) {
    this._$AV = [], this._$AN = void 0, this._$AD = t5, this._$AM = i6;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t5) {
    const { el: { content: i6 }, parts: s5 } = this._$AD, e5 = (t5?.creationScope ?? l2).importNode(i6, true);
    P.currentNode = e5;
    let h4 = P.nextNode(), o7 = 0, n6 = 0, r6 = s5[0];
    for (; void 0 !== r6; ) {
      if (o7 === r6.index) {
        let i7;
        2 === r6.type ? i7 = new k(h4, h4.nextSibling, this, t5) : 1 === r6.type ? i7 = new r6.ctor(h4, r6.name, r6.strings, this, t5) : 6 === r6.type && (i7 = new Z(h4, this, t5)), this._$AV.push(i7), r6 = s5[++n6];
      }
      o7 !== r6?.index && (h4 = P.nextNode(), o7++);
    }
    return P.currentNode = l2, e5;
  }
  p(t5) {
    let i6 = 0;
    for (const s5 of this._$AV) void 0 !== s5 && (void 0 !== s5.strings ? (s5._$AI(t5, s5, i6), i6 += s5.strings.length - 2) : s5._$AI(t5[i6])), i6++;
  }
};
var k = class _k {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t5, i6, s5, e5) {
    this.type = 2, this._$AH = A, this._$AN = void 0, this._$AA = t5, this._$AB = i6, this._$AM = s5, this.options = e5, this._$Cv = e5?.isConnected ?? true;
  }
  get parentNode() {
    let t5 = this._$AA.parentNode;
    const i6 = this._$AM;
    return void 0 !== i6 && 11 === t5?.nodeType && (t5 = i6.parentNode), t5;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t5, i6 = this) {
    t5 = M(this, t5, i6), a2(t5) ? t5 === A || null == t5 || "" === t5 ? (this._$AH !== A && this._$AR(), this._$AH = A) : t5 !== this._$AH && t5 !== E && this._(t5) : void 0 !== t5._$litType$ ? this.$(t5) : void 0 !== t5.nodeType ? this.T(t5) : d2(t5) ? this.k(t5) : this._(t5);
  }
  O(t5) {
    return this._$AA.parentNode.insertBefore(t5, this._$AB);
  }
  T(t5) {
    this._$AH !== t5 && (this._$AR(), this._$AH = this.O(t5));
  }
  _(t5) {
    this._$AH !== A && a2(this._$AH) ? this._$AA.nextSibling.data = t5 : this.T(l2.createTextNode(t5)), this._$AH = t5;
  }
  $(t5) {
    const { values: i6, _$litType$: s5 } = t5, e5 = "number" == typeof s5 ? this._$AC(t5) : (void 0 === s5.el && (s5.el = S2.createElement(V(s5.h, s5.h[0]), this.options)), s5);
    if (this._$AH?._$AD === e5) this._$AH.p(i6);
    else {
      const t6 = new R(e5, this), s6 = t6.u(this.options);
      t6.p(i6), this.T(s6), this._$AH = t6;
    }
  }
  _$AC(t5) {
    let i6 = C.get(t5.strings);
    return void 0 === i6 && C.set(t5.strings, i6 = new S2(t5)), i6;
  }
  k(t5) {
    u2(this._$AH) || (this._$AH = [], this._$AR());
    const i6 = this._$AH;
    let s5, e5 = 0;
    for (const h4 of t5) e5 === i6.length ? i6.push(s5 = new _k(this.O(c3()), this.O(c3()), this, this.options)) : s5 = i6[e5], s5._$AI(h4), e5++;
    e5 < i6.length && (this._$AR(s5 && s5._$AB.nextSibling, e5), i6.length = e5);
  }
  _$AR(t5 = this._$AA.nextSibling, s5) {
    for (this._$AP?.(false, true, s5); t5 !== this._$AB; ) {
      const s6 = i3(t5).nextSibling;
      i3(t5).remove(), t5 = s6;
    }
  }
  setConnected(t5) {
    void 0 === this._$AM && (this._$Cv = t5, this._$AP?.(t5));
  }
};
var H = class {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t5, i6, s5, e5, h4) {
    this.type = 1, this._$AH = A, this._$AN = void 0, this.element = t5, this.name = i6, this._$AM = e5, this.options = h4, s5.length > 2 || "" !== s5[0] || "" !== s5[1] ? (this._$AH = Array(s5.length - 1).fill(new String()), this.strings = s5) : this._$AH = A;
  }
  _$AI(t5, i6 = this, s5, e5) {
    const h4 = this.strings;
    let o7 = false;
    if (void 0 === h4) t5 = M(this, t5, i6, 0), o7 = !a2(t5) || t5 !== this._$AH && t5 !== E, o7 && (this._$AH = t5);
    else {
      const e6 = t5;
      let n6, r6;
      for (t5 = h4[0], n6 = 0; n6 < h4.length - 1; n6++) r6 = M(this, e6[s5 + n6], i6, n6), r6 === E && (r6 = this._$AH[n6]), o7 ||= !a2(r6) || r6 !== this._$AH[n6], r6 === A ? t5 = A : t5 !== A && (t5 += (r6 ?? "") + h4[n6 + 1]), this._$AH[n6] = r6;
    }
    o7 && !e5 && this.j(t5);
  }
  j(t5) {
    t5 === A ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t5 ?? "");
  }
};
var I = class extends H {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t5) {
    this.element[this.name] = t5 === A ? void 0 : t5;
  }
};
var L = class extends H {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t5) {
    this.element.toggleAttribute(this.name, !!t5 && t5 !== A);
  }
};
var z = class extends H {
  constructor(t5, i6, s5, e5, h4) {
    super(t5, i6, s5, e5, h4), this.type = 5;
  }
  _$AI(t5, i6 = this) {
    if ((t5 = M(this, t5, i6, 0) ?? A) === E) return;
    const s5 = this._$AH, e5 = t5 === A && s5 !== A || t5.capture !== s5.capture || t5.once !== s5.once || t5.passive !== s5.passive, h4 = t5 !== A && (s5 === A || e5);
    e5 && this.element.removeEventListener(this.name, this, s5), h4 && this.element.addEventListener(this.name, this, t5), this._$AH = t5;
  }
  handleEvent(t5) {
    "function" == typeof this._$AH ? this._$AH.call(this.options?.host ?? this.element, t5) : this._$AH.handleEvent(t5);
  }
};
var Z = class {
  constructor(t5, i6, s5) {
    this.element = t5, this.type = 6, this._$AN = void 0, this._$AM = i6, this.options = s5;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t5) {
    M(this, t5);
  }
};
var j = { M: h2, P: o3, A: n3, C: 1, L: N, R, D: d2, V: M, I: k, H, N: L, U: z, B: I, F: Z };
var B = t2.litHtmlPolyfillSupport;
B?.(S2, k), (t2.litHtmlVersions ??= []).push("3.3.3");
var D = (t5, i6, s5) => {
  const e5 = s5?.renderBefore ?? i6;
  let h4 = e5._$litPart$;
  if (void 0 === h4) {
    const t6 = s5?.renderBefore ?? null;
    e5._$litPart$ = h4 = new k(i6.insertBefore(c3(), t6), t6, void 0, s5 ?? {});
  }
  return h4._$AI(t5), h4;
};

// node_modules/lit-element/lit-element.js
var s3 = globalThis;
var i4 = class extends y {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    const t5 = super.createRenderRoot();
    return this.renderOptions.renderBefore ??= t5.firstChild, t5;
  }
  update(t5) {
    const r6 = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t5), this._$Do = D(r6, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(true);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(false);
  }
  render() {
    return E;
  }
};
i4._$litElement$ = true, i4["finalized"] = true, s3.litElementHydrateSupport?.({ LitElement: i4 });
var o4 = s3.litElementPolyfillSupport;
o4?.({ LitElement: i4 });
(s3.litElementVersions ??= []).push("4.2.2");

// frontend/translations/en.json
var en_default = {
  panel: {
    tabs: { alerts: "Alerts", active: "Active", history: "History", yaml: "YAML" },
    admin_required: "Administrator access required",
    back_home: "Back to Home Assistant",
    title: "HA Notifications",
    subtitle: "Manage alerts, notifications and history.",
    add_alert: "Add alert",
    no_alerts: "No alerts yet",
    no_active_alerts: "No active alerts",
    create_first: "Create your first alert. You can trigger it from condition changes, an interval, or both.",
    create_alert: "Create alert",
    admin_help: "HA Notifications alerts can only be viewed and edited by Home Assistant administrators.",
    draft_test_sent: "Draft test notification sent.",
    condition_valid: "Condition is valid.",
    alert_created: "Alert created.",
    alert_saved: "Alert saved.",
    test_sent: "Test notification sent.",
    test_triggered: "Test automation triggered; conditions were evaluated.",
    alert_deleted: "Alert deleted.",
    show_all: "Show all",
    alert_added: "Alert added.",
    alert_enabled: "Alert enabled.",
    alert_disabled: "Alert disabled.",
    confirm_delete: "Delete alert {{name}}?"
  },
  alert: {
    disabled: "Disabled",
    enabled: "Enabled",
    automation_managed: "Automation managed",
    automation_manual: "Manual automation",
    automation_active: "Active",
    automation_triggered: "Triggered",
    automation_idle: "Idle",
    enable: "Enable",
    disable: "Disable",
    test: "Test alert",
    edit: "Edit alert",
    history: "View history",
    delete: "Delete alert",
    every: "every {{interval}}"
  },
  editor: {
    common: {
      new_alert: "New alert",
      close_sections: "Close section menu",
      manage_sections: "Manage sections",
      view_yaml: "View alert YAML",
      close: "Close",
      cancel: "Cancel",
      save_alert: "Save alert",
      test: "Test",
      alert_sections: "Alert sections",
      discard_title: "Unsaved changes",
      discard_message: "You have unsaved changes. Leave without saving?",
      stay: "Stay",
      discard: "Discard changes",
      alert_yaml: "Alert YAML",
      close_yaml: "Close YAML",
      duration: "Duration",
      duration_format: "Duration (HH:MM:SS)"
    },
    basic: {
      section: "Basic",
      name: "Name",
      alert_name: "Alert name",
      description: "Description",
      icon: "Icon"
    },
    evaluate: {
      section: "When to check",
      when_condition_changes: "When condition changes",
      clear_when_inactive: "Clear notification when inactive",
      check_startup: "Check at startup",
      condition_change_help: "Condition changes are detected for referenced entities. Use a condition that references an entity, or use Test and interval checks for static templates.",
      re_evaluate_every: "Re-evaluate condition every",
      interval_help: "Re-checks the condition at this interval, even when no relevant entity-change event occurs.",
      enable_history_retention: "Enable history retention",
      history_retention: "History retention",
      retention_days: "History retention days",
      retention_help: "Completed alert history is removed after this period."
    },
    condition: {
      section: "Condition",
      conditions_yaml: "Native Home Assistant condition",
      conditions_help: "Enter a Home Assistant condition as a template string, mapping, or list of mappings. YAML and JSON are supported.",
      type: "Type",
      entity: "Entity",
      for: "For",
      id_optional: "ID (optional)",
      state: "State",
      numeric_state: "Numeric state",
      attribute: "Attribute",
      above: "Above",
      below: "Below",
      expected_value: "Expected value"
    },
    recipients: {
      section: "Recipients",
      selected: "Selected recipients",
      search: "Search recipients",
      remove: "Remove",
      no_matching: "No matching recipients",
      empty: "No recipients available",
      help: "Search for a recipient, choose a type when needed, then select it. You can mix devices, areas, labels, floors, and notification entities.",
      service_help: "Selected devices, areas, labels, floors, and notification entities are passed to Home Assistant's standard Notify service."
    },
    notification: {
      section: "Notification",
      title: "Title",
      message: "Message",
      title_placeholder: "Notification title",
      message_placeholder: "Notification message",
      template_help: "Template variables and sensor helpers",
      templates_help: "Notification templates and helpers",
      show_template_help: "Show template variables and sensor helpers",
      post_send_actions: "Post-send actions",
      post_send_help: "Runs after every notification send. Enter a YAML list of Home Assistant actions. JSON arrays also work because JSON is valid YAML."
    },
    confirmation: {
      section: "Confirmation",
      toggle: "confirmation",
      message: "Confirmation message",
      add_response: "Add response button",
      remove_button: "Remove button",
      button_id: "Button ID",
      button_id_optional: "Button ID (optional)",
      button_label: "Button text",
      button_label_optional: "Button text (optional)",
      clear_on_acknowledge: "Clear notifications when acknowledged",
      reminder: {
        section: "Reminder policy",
        remind_every: "Remind every",
        maximum: "Maximum reminders",
        forget_after: "Forget after",
        enable_forget_after: "Enable forget after",
        show_attempt_count: "Show attempt count in notification title",
        keep_until: "Set to 00:00:00 to keep the notification until confirmation."
      },
      notification: {
        section: "Notify recipients when confirmed",
        follow_up_help: "Optionally send a follow-up message after acknowledgement.",
        example: "Example:"
      },
      actions: {
        section: "Post-confirmation actions",
        help: "Runs after a recipient confirms. Enter a YAML list of Home Assistant actions. JSON arrays also work because JSON is valid YAML."
      }
    }
  },
  history: {
    search: "Search history",
    for_alert: "History for {{name}}",
    alert_only: "Showing events for this alert only.",
    filter: "Filter history",
    more_filters: "More filters",
    clear: "Clear",
    showing: "Showing {{count}} of {{total}} events",
    no_matches: "No history entries match these filters.",
    all_alerts: "All alerts",
    all_event_types: "All event types",
    event_type: "Event type",
    filter_event_type: "Filter by event type",
    all_severities: "All severities",
    severity: "Severity",
    filter_severity: "Filter by severity",
    error: "Error",
    success: "Success",
    info: "Info",
    muted: "Muted",
    details: "Details",
    flow: "Flow",
    group_by_flow: "Group by flow",
    flow_events: "{{count}} events",
    alert: "Alert",
    filter_alert: "Filter by alert",
    unknown_alert: "Unknown alert",
    no_activity: "No activity yet",
    no_activity_for: "No activity for {{name}}",
    activity_help: "Notification activity and debug traces will appear here.",
    show_all: "Show all history"
  },
  yaml: {
    description: "Advanced editor. Copy this YAML to another system or import a validated configuration into Home Assistant.",
    copy: "Copy",
    validate: "Validate",
    reload: "Reload",
    save: "Save YAML",
    aria: "HA Notifications YAML",
    copied: "YAML copied to clipboard.",
    valid: "YAML is valid.",
    reloaded: "YAML configuration reloaded.",
    not_saved: "The YAML was not saved.",
    saved: "YAML saved and configuration reloaded."
  },
  common: { close: "Close", remove: "Remove", all: "All", devices: "Devices", areas: "Areas", floors: "Floors", labels: "Labels", notification_entities: "Notification entities", users: "Users" }
};

// frontend/localize.ts
function catalogValue(key) {
  let value = en_default;
  for (const part of key.split(".")) {
    if (typeof value === "string") return void 0;
    if (!value) return void 0;
    value = value[part];
  }
  return typeof value === "string" ? value : void 0;
}
function interpolate(value, variables) {
  return value.replace(/{{(\w+)}}/g, (_2, key) => String(variables[key] ?? ""));
}
function resolveLocalized(hass, key, variables = {}, fallback) {
  const haKey = `component.ha_notifications.frontend.${key}`;
  const runtimeValue = hass?.localize?.(haKey, variables);
  const value = runtimeValue && runtimeValue !== haKey ? runtimeValue : catalogValue(key);
  return interpolate(value || fallback || key, variables);
}
function createLocalizer(hass) {
  return (key, variables = {}, fallback) => resolveLocalized(hass, key, variables, fallback);
}
function localize(hass, key, variables = {}, fallback) {
  return resolveLocalized(hass, key, variables, fallback);
}
var editorTitleKeys = {
  Basic: "editor.basic.section",
  "When to check": "editor.evaluate.section",
  Condition: "editor.condition.section",
  Recipients: "editor.recipients.section",
  Notification: "editor.notification.section",
  "Post-send actions": "editor.notification.post_send_actions",
  Confirmation: "editor.confirmation.section",
  "Reminder policy": "editor.confirmation.reminder.section",
  "Notify recipients when confirmed": "editor.confirmation.notification.section",
  "Post-confirmation actions": "editor.confirmation.actions.section"
};
function localizeEditorTitle(translate, title) {
  return translate(editorTitleKeys[title] || title, {}, title);
}

// frontend/recipient-picker.ts
var RecipientPickerElement = class extends i4 {
  hass = null;
  labels = {};
  items = [];
  selected = /* @__PURE__ */ new Set();
  filter = "all";
  search = "";
  open = false;
  markDirty = () => void 0;
  createRenderRoot() {
    return this;
  }
  initialize(registries, target, markDirty, hass) {
    this.hass = hass;
    this.labels = { all: localize(hass, "common.all"), device_id: localize(hass, "common.devices"), area_id: localize(hass, "common.areas"), floor_id: localize(hass, "common.floors"), label_id: localize(hass, "common.labels"), entity_id: localize(hass, "common.notification_entities"), user_id: localize(hass, "common.users") };
    this.items = [
      ...registries.devices.map((item) => ({ type: "device_id", id: item.id, label: item.name_by_user || item.name || item.id })),
      ...registries.areas.map((item) => ({ type: "area_id", id: item.area_id || item.id || "", label: item.name || item.id || "" })),
      ...registries.floors.map((item) => ({ type: "floor_id", id: item.floor_id || item.id || "", label: item.name || item.id || "" })),
      ...registries.labels.map((item) => ({ type: "label_id", id: item.label_id || item.id || "", label: item.name || item.id || "" })),
      ...registries.entities.filter((item) => item.entity_id.startsWith("notify.")).map((item) => ({ type: "entity_id", id: item.entity_id, label: item.name || item.entity_id })),
      ...registries.users.filter((item) => item.is_active !== false).map((item) => ({ type: "user_id", id: item.id, label: item.name }))
    ];
    this.selected = new Set(
      Object.keys(this.labels).flatMap(
        (type) => (target[type] || []).map((value) => `${type}:${String(value)}`)
      )
    );
    this.markDirty = markDirty;
  }
  currentTarget() {
    const result = {};
    for (const key of this.selected) {
      const [type, ...parts] = key.split(":");
      const recipientType = type;
      result[recipientType] ||= [];
      result[recipientType]?.push(parts.join(":"));
    }
    return result;
  }
  renderImmediately() {
    this.rerender();
  }
  rerender() {
    D(this.render(), this);
  }
  render() {
    const query = this.search.trim().toLowerCase();
    const matches = this.items.filter((item) => !this.selected.has(`${item.type}:${item.id}`) && (this.filter === "all" || item.type === this.filter) && (!query || item.label.toLowerCase().includes(query)));
    const selectedItems = [...this.selected].map((key) => {
      const [type, ...parts] = key.split(":");
      const id = parts.join(":");
      return { key, type, id, item: this.items.find((candidate) => candidate.type === type && candidate.id === id) };
    });
    return b2`<div class="nc-target-picker">
      <div class="nc-target-selection-label">${localize(this.hass, "editor.recipients.selected")}</div>
      <div class="nc-target-chips">${selectedItems.map(({ key, type, id, item }) => b2`<span class="nc-target-chip" title=${this.labels[type]}>${item?.label || id}<button class="nc-chip-remove" @click=${() => this.removeRecipient(key)}>${localize(this.hass, "common.remove")}</button></span>`)}</div>
      <div class="nc-recipient-input"><div class="nc-recipient-toolbar">
        <ha-input type="search" class="nc-recipient-search" autocomplete="off" name="ha-notifications-recipient-search" placeholder=${localize(this.hass, "editor.recipients.search")} .value=${this.search} @input=${this.handleSearchInput} @focus=${this.openResults}></ha-input>
        <div class="nc-recipient-filters">${Object.keys(this.labels).map((key) => b2`<button class=${this.recipientFilterClass(this.filter === key)} @click=${() => this.selectFilter(key)}>${this.labels[key]}</button>`)}</div>
      </div>
      <div class="nc-recipient-results" ?hidden=${!this.open} @focusout=${this.handleResultsFocusOut}>${this.recipientMatchesTemplate(matches, query)}</div></div>
    </div>`;
  }
  removeRecipient(key) {
    this.selected.delete(key);
    this.notifyChange();
  }
  handleSearchInput = (event) => {
    this.search = event.currentTarget.value;
    this.openResults();
  };
  openResults = () => {
    this.open = true;
    this.rerender();
  };
  selectFilter = (filter) => {
    this.filter = filter;
    this.openResults();
  };
  handleResultsFocusOut = (event) => {
    const results = event.currentTarget;
    if (results.contains(event.relatedTarget)) return;
    this.open = false;
    this.rerender();
  };
  notifyChange() {
    this.markDirty();
    this.rerender();
  }
  recipientFilterClass(active) {
    return active ? "nc-recipient-filter active" : "nc-recipient-filter";
  }
  recipientMatchesTemplate(matches, query) {
    if (!matches.length) return b2`<div class="nc-recipient-empty">${query ? localize(this.hass, "editor.recipients.no_matching") : localize(this.hass, "editor.recipients.empty")}</div>`;
    return matches.map((item) => b2`<button class="nc-recipient-option" title=${this.labels[item.type]} @mousedown=${(event) => event.preventDefault()} @click=${() => this.selectRecipient(item)}>${item.label}</button>`);
  }
  selectRecipient(item) {
    this.selected.add(`${item.type}:${item.id}`);
    this.open = false;
    this.notifyChange();
  }
};
customElements.define("ha-notifications-recipient-picker", RecipientPickerElement);
function createRecipientPicker(registries, target, markDirty, hass) {
  const element = new RecipientPickerElement();
  element.initialize(registries, target, markDirty, hass);
  element.renderImmediately();
  return { element, target: () => element.currentTarget() };
}

// node_modules/yaml/browser/dist/nodes/identity.js
var ALIAS = /* @__PURE__ */ Symbol.for("yaml.alias");
var DOC = /* @__PURE__ */ Symbol.for("yaml.document");
var MAP = /* @__PURE__ */ Symbol.for("yaml.map");
var PAIR = /* @__PURE__ */ Symbol.for("yaml.pair");
var SCALAR = /* @__PURE__ */ Symbol.for("yaml.scalar");
var SEQ = /* @__PURE__ */ Symbol.for("yaml.seq");
var NODE_TYPE = /* @__PURE__ */ Symbol.for("yaml.node.type");
var isAlias = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === ALIAS;
var isDocument = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === DOC;
var isMap = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === MAP;
var isPair = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === PAIR;
var isScalar = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SCALAR;
var isSeq = (node) => !!node && typeof node === "object" && node[NODE_TYPE] === SEQ;
function isCollection(node) {
  if (node && typeof node === "object")
    switch (node[NODE_TYPE]) {
      case MAP:
      case SEQ:
        return true;
    }
  return false;
}
function isNode(node) {
  if (node && typeof node === "object")
    switch (node[NODE_TYPE]) {
      case ALIAS:
      case MAP:
      case SCALAR:
      case SEQ:
        return true;
    }
  return false;
}
var hasAnchor = (node) => (isScalar(node) || isCollection(node)) && !!node.anchor;

// node_modules/yaml/browser/dist/visit.js
var BREAK = /* @__PURE__ */ Symbol("break visit");
var SKIP = /* @__PURE__ */ Symbol("skip children");
var REMOVE = /* @__PURE__ */ Symbol("remove node");
function visit(node, visitor) {
  const visitor_ = initVisitor(visitor);
  if (isDocument(node)) {
    const cd = visit_(null, node.contents, visitor_, Object.freeze([node]));
    if (cd === REMOVE)
      node.contents = null;
  } else
    visit_(null, node, visitor_, Object.freeze([]));
}
visit.BREAK = BREAK;
visit.SKIP = SKIP;
visit.REMOVE = REMOVE;
function visit_(key, node, visitor, path) {
  const ctrl = callVisitor(key, node, visitor, path);
  if (isNode(ctrl) || isPair(ctrl)) {
    replaceNode(key, path, ctrl);
    return visit_(key, ctrl, visitor, path);
  }
  if (typeof ctrl !== "symbol") {
    if (isCollection(node)) {
      path = Object.freeze(path.concat(node));
      for (let i6 = 0; i6 < node.items.length; ++i6) {
        const ci = visit_(i6, node.items[i6], visitor, path);
        if (typeof ci === "number")
          i6 = ci - 1;
        else if (ci === BREAK)
          return BREAK;
        else if (ci === REMOVE) {
          node.items.splice(i6, 1);
          i6 -= 1;
        }
      }
    } else if (isPair(node)) {
      path = Object.freeze(path.concat(node));
      const ck = visit_("key", node.key, visitor, path);
      if (ck === BREAK)
        return BREAK;
      else if (ck === REMOVE)
        node.key = null;
      const cv = visit_("value", node.value, visitor, path);
      if (cv === BREAK)
        return BREAK;
      else if (cv === REMOVE)
        node.value = null;
    }
  }
  return ctrl;
}
async function visitAsync(node, visitor) {
  const visitor_ = initVisitor(visitor);
  if (isDocument(node)) {
    const cd = await visitAsync_(null, node.contents, visitor_, Object.freeze([node]));
    if (cd === REMOVE)
      node.contents = null;
  } else
    await visitAsync_(null, node, visitor_, Object.freeze([]));
}
visitAsync.BREAK = BREAK;
visitAsync.SKIP = SKIP;
visitAsync.REMOVE = REMOVE;
async function visitAsync_(key, node, visitor, path) {
  const ctrl = await callVisitor(key, node, visitor, path);
  if (isNode(ctrl) || isPair(ctrl)) {
    replaceNode(key, path, ctrl);
    return visitAsync_(key, ctrl, visitor, path);
  }
  if (typeof ctrl !== "symbol") {
    if (isCollection(node)) {
      path = Object.freeze(path.concat(node));
      for (let i6 = 0; i6 < node.items.length; ++i6) {
        const ci = await visitAsync_(i6, node.items[i6], visitor, path);
        if (typeof ci === "number")
          i6 = ci - 1;
        else if (ci === BREAK)
          return BREAK;
        else if (ci === REMOVE) {
          node.items.splice(i6, 1);
          i6 -= 1;
        }
      }
    } else if (isPair(node)) {
      path = Object.freeze(path.concat(node));
      const ck = await visitAsync_("key", node.key, visitor, path);
      if (ck === BREAK)
        return BREAK;
      else if (ck === REMOVE)
        node.key = null;
      const cv = await visitAsync_("value", node.value, visitor, path);
      if (cv === BREAK)
        return BREAK;
      else if (cv === REMOVE)
        node.value = null;
    }
  }
  return ctrl;
}
function initVisitor(visitor) {
  if (typeof visitor === "object" && (visitor.Collection || visitor.Node || visitor.Value)) {
    return Object.assign({
      Alias: visitor.Node,
      Map: visitor.Node,
      Scalar: visitor.Node,
      Seq: visitor.Node
    }, visitor.Value && {
      Map: visitor.Value,
      Scalar: visitor.Value,
      Seq: visitor.Value
    }, visitor.Collection && {
      Map: visitor.Collection,
      Seq: visitor.Collection
    }, visitor);
  }
  return visitor;
}
function callVisitor(key, node, visitor, path) {
  if (typeof visitor === "function")
    return visitor(key, node, path);
  if (isMap(node))
    return visitor.Map?.(key, node, path);
  if (isSeq(node))
    return visitor.Seq?.(key, node, path);
  if (isPair(node))
    return visitor.Pair?.(key, node, path);
  if (isScalar(node))
    return visitor.Scalar?.(key, node, path);
  if (isAlias(node))
    return visitor.Alias?.(key, node, path);
  return void 0;
}
function replaceNode(key, path, node) {
  const parent = path[path.length - 1];
  if (isCollection(parent)) {
    parent.items[key] = node;
  } else if (isPair(parent)) {
    if (key === "key")
      parent.key = node;
    else
      parent.value = node;
  } else if (isDocument(parent)) {
    parent.contents = node;
  } else {
    const pt = isAlias(parent) ? "alias" : "scalar";
    throw new Error(`Cannot replace node with ${pt} parent`);
  }
}

// node_modules/yaml/browser/dist/doc/directives.js
var escapeChars = {
  "!": "%21",
  ",": "%2C",
  "[": "%5B",
  "]": "%5D",
  "{": "%7B",
  "}": "%7D"
};
var escapeTagName = (tn) => tn.replace(/[!,[\]{}]/g, (ch) => escapeChars[ch]);
var Directives = class _Directives {
  constructor(yaml, tags) {
    this.docStart = null;
    this.docEnd = false;
    this.yaml = Object.assign({}, _Directives.defaultYaml, yaml);
    this.tags = Object.assign({}, _Directives.defaultTags, tags);
  }
  clone() {
    const copy = new _Directives(this.yaml, this.tags);
    copy.docStart = this.docStart;
    return copy;
  }
  /**
   * During parsing, get a Directives instance for the current document and
   * update the stream state according to the current version's spec.
   */
  atDocument() {
    const res = new _Directives(this.yaml, this.tags);
    switch (this.yaml.version) {
      case "1.1":
        this.atNextDocument = true;
        break;
      case "1.2":
        this.atNextDocument = false;
        this.yaml = {
          explicit: _Directives.defaultYaml.explicit,
          version: "1.2"
        };
        this.tags = Object.assign({}, _Directives.defaultTags);
        break;
    }
    return res;
  }
  /**
   * @param onError - May be called even if the action was successful
   * @returns `true` on success
   */
  add(line, onError) {
    if (this.atNextDocument) {
      this.yaml = { explicit: _Directives.defaultYaml.explicit, version: "1.1" };
      this.tags = Object.assign({}, _Directives.defaultTags);
      this.atNextDocument = false;
    }
    const parts = line.trim().split(/[ \t]+/);
    const name = parts.shift();
    switch (name) {
      case "%TAG": {
        if (parts.length !== 2) {
          onError(0, "%TAG directive should contain exactly two parts");
          if (parts.length < 2)
            return false;
        }
        const [handle, prefix] = parts;
        this.tags[handle] = prefix;
        return true;
      }
      case "%YAML": {
        this.yaml.explicit = true;
        if (parts.length !== 1) {
          onError(0, "%YAML directive should contain exactly one part");
          return false;
        }
        const [version] = parts;
        if (version === "1.1" || version === "1.2") {
          this.yaml.version = version;
          return true;
        } else {
          const isValid = /^\d+\.\d+$/.test(version);
          onError(6, `Unsupported YAML version ${version}`, isValid);
          return false;
        }
      }
      default:
        onError(0, `Unknown directive ${name}`, true);
        return false;
    }
  }
  /**
   * Resolves a tag, matching handles to those defined in %TAG directives.
   *
   * @returns Resolved tag, which may also be the non-specific tag `'!'` or a
   *   `'!local'` tag, or `null` if unresolvable.
   */
  tagName(source, onError) {
    if (source === "!")
      return "!";
    if (source[0] !== "!") {
      onError(`Not a valid tag: ${source}`);
      return null;
    }
    if (source[1] === "<") {
      const verbatim = source.slice(2, -1);
      if (verbatim === "!" || verbatim === "!!") {
        onError(`Verbatim tags aren't resolved, so ${source} is invalid.`);
        return null;
      }
      if (source[source.length - 1] !== ">")
        onError("Verbatim tags must end with a >");
      return verbatim;
    }
    const [, handle, suffix] = source.match(/^(.*!)([^!]*)$/s);
    if (!suffix)
      onError(`The ${source} tag has no suffix`);
    const prefix = this.tags[handle];
    if (prefix) {
      try {
        return prefix + decodeURIComponent(suffix);
      } catch (error) {
        onError(String(error));
        return null;
      }
    }
    if (handle === "!")
      return source;
    onError(`Could not resolve tag: ${source}`);
    return null;
  }
  /**
   * Given a fully resolved tag, returns its printable string form,
   * taking into account current tag prefixes and defaults.
   */
  tagString(tag) {
    for (const [handle, prefix] of Object.entries(this.tags)) {
      if (tag.startsWith(prefix))
        return handle + escapeTagName(tag.substring(prefix.length));
    }
    return tag[0] === "!" ? tag : `!<${tag}>`;
  }
  toString(doc) {
    const lines = this.yaml.explicit ? [`%YAML ${this.yaml.version || "1.2"}`] : [];
    const tagEntries = Object.entries(this.tags);
    let tagNames;
    if (doc && tagEntries.length > 0 && isNode(doc.contents)) {
      const tags = {};
      visit(doc.contents, (_key, node) => {
        if (isNode(node) && node.tag)
          tags[node.tag] = true;
      });
      tagNames = Object.keys(tags);
    } else
      tagNames = [];
    for (const [handle, prefix] of tagEntries) {
      if (handle === "!!" && prefix === "tag:yaml.org,2002:")
        continue;
      if (!doc || tagNames.some((tn) => tn.startsWith(prefix)))
        lines.push(`%TAG ${handle} ${prefix}`);
    }
    return lines.join("\n");
  }
};
Directives.defaultYaml = { explicit: false, version: "1.2" };
Directives.defaultTags = { "!!": "tag:yaml.org,2002:" };

// node_modules/yaml/browser/dist/doc/anchors.js
function anchorIsValid(anchor) {
  if (/[\x00-\x19\s,[\]{}]/.test(anchor)) {
    const sa = JSON.stringify(anchor);
    const msg = `Anchor must not contain whitespace or control characters: ${sa}`;
    throw new Error(msg);
  }
  return true;
}
function anchorNames(root) {
  const anchors = /* @__PURE__ */ new Set();
  visit(root, {
    Value(_key, node) {
      if (node.anchor)
        anchors.add(node.anchor);
    }
  });
  return anchors;
}
function findNewAnchor(prefix, exclude) {
  for (let i6 = 1; true; ++i6) {
    const name = `${prefix}${i6}`;
    if (!exclude.has(name))
      return name;
  }
}
function createNodeAnchors(doc, prefix) {
  const aliasObjects = [];
  const sourceObjects = /* @__PURE__ */ new Map();
  let prevAnchors = null;
  return {
    onAnchor: (source) => {
      aliasObjects.push(source);
      prevAnchors ?? (prevAnchors = anchorNames(doc));
      const anchor = findNewAnchor(prefix, prevAnchors);
      prevAnchors.add(anchor);
      return anchor;
    },
    /**
     * With circular references, the source node is only resolved after all
     * of its child nodes are. This is why anchors are set only after all of
     * the nodes have been created.
     */
    setAnchors: () => {
      for (const source of aliasObjects) {
        const ref = sourceObjects.get(source);
        if (typeof ref === "object" && ref.anchor && (isScalar(ref.node) || isCollection(ref.node))) {
          ref.node.anchor = ref.anchor;
        } else {
          const error = new Error("Failed to resolve repeated object (this should not happen)");
          error.source = source;
          throw error;
        }
      }
    },
    sourceObjects
  };
}

// node_modules/yaml/browser/dist/doc/applyReviver.js
function applyReviver(reviver, obj, key, val) {
  if (val && typeof val === "object") {
    if (Array.isArray(val)) {
      for (let i6 = 0, len = val.length; i6 < len; ++i6) {
        const v0 = val[i6];
        const v1 = applyReviver(reviver, val, String(i6), v0);
        if (v1 === void 0)
          delete val[i6];
        else if (v1 !== v0)
          val[i6] = v1;
      }
    } else if (val instanceof Map) {
      for (const k2 of Array.from(val.keys())) {
        const v0 = val.get(k2);
        const v1 = applyReviver(reviver, val, k2, v0);
        if (v1 === void 0)
          val.delete(k2);
        else if (v1 !== v0)
          val.set(k2, v1);
      }
    } else if (val instanceof Set) {
      for (const v0 of Array.from(val)) {
        const v1 = applyReviver(reviver, val, v0, v0);
        if (v1 === void 0)
          val.delete(v0);
        else if (v1 !== v0) {
          val.delete(v0);
          val.add(v1);
        }
      }
    } else {
      for (const [k2, v0] of Object.entries(val)) {
        const v1 = applyReviver(reviver, val, k2, v0);
        if (v1 === void 0)
          delete val[k2];
        else if (v1 !== v0)
          val[k2] = v1;
      }
    }
  }
  return reviver.call(obj, key, val);
}

// node_modules/yaml/browser/dist/nodes/toJS.js
function toJS(value, arg, ctx) {
  if (Array.isArray(value))
    return value.map((v2, i6) => toJS(v2, String(i6), ctx));
  if (value && typeof value.toJSON === "function") {
    if (!ctx || !hasAnchor(value))
      return value.toJSON(arg, ctx);
    const data = { aliasCount: 0, count: 1, res: void 0 };
    ctx.anchors.set(value, data);
    ctx.onCreate = (res2) => {
      data.res = res2;
      delete ctx.onCreate;
    };
    const res = value.toJSON(arg, ctx);
    if (ctx.onCreate)
      ctx.onCreate(res);
    return res;
  }
  if (typeof value === "bigint" && !ctx?.keep)
    return Number(value);
  return value;
}

// node_modules/yaml/browser/dist/nodes/Node.js
var NodeBase = class {
  constructor(type) {
    Object.defineProperty(this, NODE_TYPE, { value: type });
  }
  /** Create a copy of this node.  */
  clone() {
    const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /** A plain JavaScript representation of this node. */
  toJS(doc, { mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
    if (!isDocument(doc))
      throw new TypeError("A document argument is required");
    const ctx = {
      anchors: /* @__PURE__ */ new Map(),
      doc,
      keep: true,
      mapAsMap: mapAsMap === true,
      mapKeyWarned: false,
      maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
    };
    const res = toJS(this, "", ctx);
    if (typeof onAnchor === "function")
      for (const { count, res: res2 } of ctx.anchors.values())
        onAnchor(res2, count);
    return typeof reviver === "function" ? applyReviver(reviver, { "": res }, "", res) : res;
  }
};

// node_modules/yaml/browser/dist/nodes/Alias.js
var Alias = class extends NodeBase {
  constructor(source) {
    super(ALIAS);
    this.source = source;
    Object.defineProperty(this, "tag", {
      set() {
        throw new Error("Alias nodes cannot have tags");
      }
    });
  }
  /**
   * Resolve the value of this alias within `doc`, finding the last
   * instance of the `source` anchor before this node.
   */
  resolve(doc, ctx) {
    if (ctx?.maxAliasCount === 0)
      throw new ReferenceError("Alias resolution is disabled");
    let nodes;
    if (ctx?.aliasResolveCache) {
      nodes = ctx.aliasResolveCache;
    } else {
      nodes = [];
      visit(doc, {
        Node: (_key, node) => {
          if (isAlias(node) || hasAnchor(node))
            nodes.push(node);
        }
      });
      if (ctx)
        ctx.aliasResolveCache = nodes;
    }
    let found = void 0;
    for (const node of nodes) {
      if (node === this)
        break;
      if (node.anchor === this.source)
        found = node;
    }
    if (found && ctx) {
      const { anchors, doc: doc2, maxAliasCount } = ctx;
      let data = anchors.get(found);
      if (!data) {
        toJS(found, null, ctx);
        data = anchors.get(found);
      }
      if (data?.res === void 0) {
        const msg = "This should not happen: Alias anchor was not resolved?";
        throw new ReferenceError(msg);
      }
      if (maxAliasCount >= 0) {
        data.count += 1;
        if (data.aliasCount === 0)
          data.aliasCount = getAliasCount(doc2, found, anchors);
        if (data.count * data.aliasCount > maxAliasCount) {
          const msg = "Excessive alias count indicates a resource exhaustion attack";
          throw new ReferenceError(msg);
        }
      }
    }
    return found;
  }
  toJSON(_arg, ctx) {
    if (!ctx)
      return { source: this.source };
    const source = this.resolve(ctx.doc, ctx);
    if (!source) {
      const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
      throw new ReferenceError(msg);
    }
    return ctx.anchors.get(source).res;
  }
  toString(ctx, _onComment, _onChompKeep) {
    const src = `*${this.source}`;
    if (ctx) {
      anchorIsValid(this.source);
      if (ctx.options.verifyAliasOrder && !ctx.anchors.has(this.source)) {
        const msg = `Unresolved alias (the anchor must be set before the alias): ${this.source}`;
        throw new Error(msg);
      }
      if (ctx.implicitKey)
        return `${src} `;
    }
    return src;
  }
};
function getAliasCount(doc, node, anchors) {
  if (isAlias(node)) {
    const source = node.resolve(doc);
    const anchor = anchors && source && anchors.get(source);
    return anchor ? anchor.count * anchor.aliasCount : 0;
  } else if (isCollection(node)) {
    let count = 0;
    for (const item of node.items) {
      const c5 = getAliasCount(doc, item, anchors);
      if (c5 > count)
        count = c5;
    }
    return count;
  } else if (isPair(node)) {
    const kc = getAliasCount(doc, node.key, anchors);
    const vc = getAliasCount(doc, node.value, anchors);
    return Math.max(kc, vc);
  }
  return 1;
}

// node_modules/yaml/browser/dist/nodes/Scalar.js
var isScalarValue = (value) => !value || typeof value !== "function" && typeof value !== "object";
var Scalar = class extends NodeBase {
  constructor(value) {
    super(SCALAR);
    this.value = value;
  }
  toJSON(arg, ctx) {
    return ctx?.keep ? this.value : toJS(this.value, arg, ctx);
  }
  toString() {
    return String(this.value);
  }
};
Scalar.BLOCK_FOLDED = "BLOCK_FOLDED";
Scalar.BLOCK_LITERAL = "BLOCK_LITERAL";
Scalar.PLAIN = "PLAIN";
Scalar.QUOTE_DOUBLE = "QUOTE_DOUBLE";
Scalar.QUOTE_SINGLE = "QUOTE_SINGLE";

// node_modules/yaml/browser/dist/doc/createNode.js
var defaultTagPrefix = "tag:yaml.org,2002:";
function findTagObject(value, tagName, tags) {
  if (tagName) {
    const match = tags.filter((t5) => t5.tag === tagName);
    const tagObj = match.find((t5) => !t5.format) ?? match[0];
    if (!tagObj)
      throw new Error(`Tag ${tagName} not found`);
    return tagObj;
  }
  return tags.find((t5) => t5.identify?.(value) && !t5.format);
}
function createNode(value, tagName, ctx) {
  if (isDocument(value))
    value = value.contents;
  if (isNode(value))
    return value;
  if (isPair(value)) {
    const map2 = ctx.schema[MAP].createNode?.(ctx.schema, null, ctx);
    map2.items.push(value);
    return map2;
  }
  if (value instanceof String || value instanceof Number || value instanceof Boolean || typeof BigInt !== "undefined" && value instanceof BigInt) {
    value = value.valueOf();
  }
  const { aliasDuplicateObjects, onAnchor, onTagObj, schema: schema4, sourceObjects } = ctx;
  let ref = void 0;
  if (aliasDuplicateObjects && value && typeof value === "object") {
    ref = sourceObjects.get(value);
    if (ref) {
      ref.anchor ?? (ref.anchor = onAnchor(value));
      return new Alias(ref.anchor);
    } else {
      ref = { anchor: null, node: null };
      sourceObjects.set(value, ref);
    }
  }
  if (tagName?.startsWith("!!"))
    tagName = defaultTagPrefix + tagName.slice(2);
  let tagObj = findTagObject(value, tagName, schema4.tags);
  if (!tagObj) {
    if (value && typeof value.toJSON === "function") {
      value = value.toJSON();
    }
    if (!value || typeof value !== "object") {
      const node2 = new Scalar(value);
      if (ref)
        ref.node = node2;
      return node2;
    }
    tagObj = value instanceof Map ? schema4[MAP] : Symbol.iterator in Object(value) ? schema4[SEQ] : schema4[MAP];
  }
  if (onTagObj) {
    onTagObj(tagObj);
    delete ctx.onTagObj;
  }
  const node = tagObj?.createNode ? tagObj.createNode(ctx.schema, value, ctx) : typeof tagObj?.nodeClass?.from === "function" ? tagObj.nodeClass.from(ctx.schema, value, ctx) : new Scalar(value);
  if (tagName)
    node.tag = tagName;
  else if (!tagObj.default)
    node.tag = tagObj.tag;
  if (ref)
    ref.node = node;
  return node;
}

// node_modules/yaml/browser/dist/nodes/Collection.js
function collectionFromPath(schema4, path, value) {
  let v2 = value;
  for (let i6 = path.length - 1; i6 >= 0; --i6) {
    const k2 = path[i6];
    if (typeof k2 === "number" && Number.isInteger(k2) && k2 >= 0) {
      const a3 = [];
      a3[k2] = v2;
      v2 = a3;
    } else {
      v2 = /* @__PURE__ */ new Map([[k2, v2]]);
    }
  }
  return createNode(v2, void 0, {
    aliasDuplicateObjects: false,
    keepUndefined: false,
    onAnchor: () => {
      throw new Error("This should not happen, please report a bug.");
    },
    schema: schema4,
    sourceObjects: /* @__PURE__ */ new Map()
  });
}
var isEmptyPath = (path) => path == null || typeof path === "object" && !!path[Symbol.iterator]().next().done;
var Collection = class extends NodeBase {
  constructor(type, schema4) {
    super(type);
    Object.defineProperty(this, "schema", {
      value: schema4,
      configurable: true,
      enumerable: false,
      writable: true
    });
  }
  /**
   * Create a copy of this collection.
   *
   * @param schema - If defined, overwrites the original's schema
   */
  clone(schema4) {
    const copy = Object.create(Object.getPrototypeOf(this), Object.getOwnPropertyDescriptors(this));
    if (schema4)
      copy.schema = schema4;
    copy.items = copy.items.map((it) => isNode(it) || isPair(it) ? it.clone(schema4) : it);
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /**
   * Adds a value to the collection. For `!!map` and `!!omap` the value must
   * be a Pair instance or a `{ key, value }` object, which may not have a key
   * that already exists in the map.
   */
  addIn(path, value) {
    if (isEmptyPath(path))
      this.add(value);
    else {
      const [key, ...rest] = path;
      const node = this.get(key, true);
      if (isCollection(node))
        node.addIn(rest, value);
      else if (node === void 0 && this.schema)
        this.set(key, collectionFromPath(this.schema, rest, value));
      else
        throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
    }
  }
  /**
   * Removes a value from the collection.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(path) {
    const [key, ...rest] = path;
    if (rest.length === 0)
      return this.delete(key);
    const node = this.get(key, true);
    if (isCollection(node))
      return node.deleteIn(rest);
    else
      throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(path, keepScalar) {
    const [key, ...rest] = path;
    const node = this.get(key, true);
    if (rest.length === 0)
      return !keepScalar && isScalar(node) ? node.value : node;
    else
      return isCollection(node) ? node.getIn(rest, keepScalar) : void 0;
  }
  hasAllNullValues(allowScalar) {
    return this.items.every((node) => {
      if (!isPair(node))
        return false;
      const n6 = node.value;
      return n6 == null || allowScalar && isScalar(n6) && n6.value == null && !n6.commentBefore && !n6.comment && !n6.tag;
    });
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   */
  hasIn(path) {
    const [key, ...rest] = path;
    if (rest.length === 0)
      return this.has(key);
    const node = this.get(key, true);
    return isCollection(node) ? node.hasIn(rest) : false;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(path, value) {
    const [key, ...rest] = path;
    if (rest.length === 0) {
      this.set(key, value);
    } else {
      const node = this.get(key, true);
      if (isCollection(node))
        node.setIn(rest, value);
      else if (node === void 0 && this.schema)
        this.set(key, collectionFromPath(this.schema, rest, value));
      else
        throw new Error(`Expected YAML collection at ${key}. Remaining path: ${rest}`);
    }
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyComment.js
var stringifyComment = (str) => str.replace(/^(?!$)(?: $)?/gm, "#");
function indentComment(comment, indent) {
  if (/^\n+$/.test(comment))
    return comment.substring(1);
  return indent ? comment.replace(/^(?! *$)/gm, indent) : comment;
}
var lineComment = (str, indent, comment) => str.endsWith("\n") ? indentComment(comment, indent) : comment.includes("\n") ? "\n" + indentComment(comment, indent) : (str.endsWith(" ") ? "" : " ") + comment;

// node_modules/yaml/browser/dist/stringify/foldFlowLines.js
var FOLD_FLOW = "flow";
var FOLD_BLOCK = "block";
var FOLD_QUOTED = "quoted";
function foldFlowLines(text, indent, mode = "flow", { indentAtStart, lineWidth = 80, minContentWidth = 20, onFold, onOverflow } = {}) {
  if (!lineWidth || lineWidth < 0)
    return text;
  if (lineWidth < minContentWidth)
    minContentWidth = 0;
  const endStep = Math.max(1 + minContentWidth, 1 + lineWidth - indent.length);
  if (text.length <= endStep)
    return text;
  const folds = [];
  const escapedFolds = {};
  let end = lineWidth - indent.length;
  if (typeof indentAtStart === "number") {
    if (indentAtStart > lineWidth - Math.max(2, minContentWidth))
      folds.push(0);
    else
      end = lineWidth - indentAtStart;
  }
  let split = void 0;
  let prev = void 0;
  let overflow = false;
  let i6 = -1;
  let escStart = -1;
  let escEnd = -1;
  if (mode === FOLD_BLOCK) {
    i6 = consumeMoreIndentedLines(text, i6, indent.length);
    if (i6 !== -1)
      end = i6 + endStep;
  }
  for (let ch; ch = text[i6 += 1]; ) {
    if (mode === FOLD_QUOTED && ch === "\\") {
      escStart = i6;
      switch (text[i6 + 1]) {
        case "x":
          i6 += 3;
          break;
        case "u":
          i6 += 5;
          break;
        case "U":
          i6 += 9;
          break;
        default:
          i6 += 1;
      }
      escEnd = i6;
    }
    if (ch === "\n") {
      if (mode === FOLD_BLOCK)
        i6 = consumeMoreIndentedLines(text, i6, indent.length);
      end = i6 + indent.length + endStep;
      split = void 0;
    } else {
      if (ch === " " && prev && prev !== " " && prev !== "\n" && prev !== "	") {
        const next = text[i6 + 1];
        if (next && next !== " " && next !== "\n" && next !== "	")
          split = i6;
      }
      if (i6 >= end) {
        if (split) {
          folds.push(split);
          end = split + endStep;
          split = void 0;
        } else if (mode === FOLD_QUOTED) {
          while (prev === " " || prev === "	") {
            prev = ch;
            ch = text[i6 += 1];
            overflow = true;
          }
          const j2 = i6 > escEnd + 1 ? i6 - 2 : escStart - 1;
          if (escapedFolds[j2])
            return text;
          folds.push(j2);
          escapedFolds[j2] = true;
          end = j2 + endStep;
          split = void 0;
        } else {
          overflow = true;
        }
      }
    }
    prev = ch;
  }
  if (overflow && onOverflow)
    onOverflow();
  if (folds.length === 0)
    return text;
  if (onFold)
    onFold();
  let res = text.slice(0, folds[0]);
  for (let i7 = 0; i7 < folds.length; ++i7) {
    const fold = folds[i7];
    const end2 = folds[i7 + 1] || text.length;
    if (fold === 0)
      res = `
${indent}${text.slice(0, end2)}`;
    else {
      if (mode === FOLD_QUOTED && escapedFolds[fold])
        res += `${text[fold]}\\`;
      res += `
${indent}${text.slice(fold + 1, end2)}`;
    }
  }
  return res;
}
function consumeMoreIndentedLines(text, i6, indent) {
  let end = i6;
  let start = i6 + 1;
  let ch = text[start];
  while (ch === " " || ch === "	") {
    if (i6 < start + indent) {
      ch = text[++i6];
    } else {
      do {
        ch = text[++i6];
      } while (ch && ch !== "\n");
      end = i6;
      start = i6 + 1;
      ch = text[start];
    }
  }
  return end;
}

// node_modules/yaml/browser/dist/stringify/stringifyString.js
var getFoldOptions = (ctx, isBlock2) => ({
  indentAtStart: isBlock2 ? ctx.indent.length : ctx.indentAtStart,
  lineWidth: ctx.options.lineWidth,
  minContentWidth: ctx.options.minContentWidth
});
var containsDocumentMarker = (str) => /^(%|---|\.\.\.)/m.test(str);
function lineLengthOverLimit(str, lineWidth, indentLength) {
  if (!lineWidth || lineWidth < 0)
    return false;
  const limit = lineWidth - indentLength;
  const strLen = str.length;
  if (strLen <= limit)
    return false;
  for (let i6 = 0, start = 0; i6 < strLen; ++i6) {
    if (str[i6] === "\n") {
      if (i6 - start > limit)
        return true;
      start = i6 + 1;
      if (strLen - start <= limit)
        return false;
    }
  }
  return true;
}
function doubleQuotedString(value, ctx) {
  const json = JSON.stringify(value);
  if (ctx.options.doubleQuotedAsJSON)
    return json;
  const { implicitKey } = ctx;
  const minMultiLineLength = ctx.options.doubleQuotedMinMultiLineLength;
  const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
  let str = "";
  let start = 0;
  for (let i6 = 0, ch = json[i6]; ch; ch = json[++i6]) {
    if (ch === " " && json[i6 + 1] === "\\" && json[i6 + 2] === "n") {
      str += json.slice(start, i6) + "\\ ";
      i6 += 1;
      start = i6;
      ch = "\\";
    }
    if (ch === "\\")
      switch (json[i6 + 1]) {
        case "u":
          {
            str += json.slice(start, i6);
            const code = json.substr(i6 + 2, 4);
            switch (code) {
              case "0000":
                str += "\\0";
                break;
              case "0007":
                str += "\\a";
                break;
              case "000b":
                str += "\\v";
                break;
              case "001b":
                str += "\\e";
                break;
              case "0085":
                str += "\\N";
                break;
              case "00a0":
                str += "\\_";
                break;
              case "2028":
                str += "\\L";
                break;
              case "2029":
                str += "\\P";
                break;
              default:
                if (code.substr(0, 2) === "00")
                  str += "\\x" + code.substr(2);
                else
                  str += json.substr(i6, 6);
            }
            i6 += 5;
            start = i6 + 1;
          }
          break;
        case "n":
          if (implicitKey || json[i6 + 2] === '"' || json.length < minMultiLineLength) {
            i6 += 1;
          } else {
            str += json.slice(start, i6) + "\n\n";
            while (json[i6 + 2] === "\\" && json[i6 + 3] === "n" && json[i6 + 4] !== '"') {
              str += "\n";
              i6 += 2;
            }
            str += indent;
            if (json[i6 + 2] === " ")
              str += "\\";
            i6 += 1;
            start = i6 + 1;
          }
          break;
        default:
          i6 += 1;
      }
  }
  str = start ? str + json.slice(start) : json;
  return implicitKey ? str : foldFlowLines(str, indent, FOLD_QUOTED, getFoldOptions(ctx, false));
}
function singleQuotedString(value, ctx) {
  if (ctx.options.singleQuote === false || ctx.implicitKey && value.includes("\n") || /[ \t]\n|\n[ \t]/.test(value))
    return doubleQuotedString(value, ctx);
  const indent = ctx.indent || (containsDocumentMarker(value) ? "  " : "");
  const res = "'" + value.replace(/'/g, "''").replace(/\n+/g, `$&
${indent}`) + "'";
  return ctx.implicitKey ? res : foldFlowLines(res, indent, FOLD_FLOW, getFoldOptions(ctx, false));
}
function quotedString(value, ctx) {
  const { singleQuote } = ctx.options;
  let qs;
  if (singleQuote === false)
    qs = doubleQuotedString;
  else {
    const hasDouble = value.includes('"');
    const hasSingle = value.includes("'");
    if (hasDouble && !hasSingle)
      qs = singleQuotedString;
    else if (hasSingle && !hasDouble)
      qs = doubleQuotedString;
    else
      qs = singleQuote ? singleQuotedString : doubleQuotedString;
  }
  return qs(value, ctx);
}
var blockEndNewlines;
try {
  blockEndNewlines = new RegExp("(^|(?<!\n))\n+(?!\n|$)", "g");
} catch {
  blockEndNewlines = /\n+(?!\n|$)/g;
}
function blockString({ comment, type, value }, ctx, onComment, onChompKeep) {
  const { blockQuote, commentString, lineWidth } = ctx.options;
  if (!blockQuote || /\n[\t ]+$/.test(value)) {
    return quotedString(value, ctx);
  }
  const indent = ctx.indent || (ctx.forceBlockIndent || containsDocumentMarker(value) ? "  " : "");
  const literal = blockQuote === "literal" ? true : blockQuote === "folded" || type === Scalar.BLOCK_FOLDED ? false : type === Scalar.BLOCK_LITERAL ? true : !lineLengthOverLimit(value, lineWidth, indent.length);
  if (!value)
    return literal ? "|\n" : ">\n";
  let chomp;
  let endStart;
  for (endStart = value.length; endStart > 0; --endStart) {
    const ch = value[endStart - 1];
    if (ch !== "\n" && ch !== "	" && ch !== " ")
      break;
  }
  let end = value.substring(endStart);
  const endNlPos = end.indexOf("\n");
  if (endNlPos === -1) {
    chomp = "-";
  } else if (value === end || endNlPos !== end.length - 1) {
    chomp = "+";
    if (onChompKeep)
      onChompKeep();
  } else {
    chomp = "";
  }
  if (end) {
    value = value.slice(0, -end.length);
    if (end[end.length - 1] === "\n")
      end = end.slice(0, -1);
    end = end.replace(blockEndNewlines, `$&${indent}`);
  }
  let startWithSpace = false;
  let startEnd;
  let startNlPos = -1;
  for (startEnd = 0; startEnd < value.length; ++startEnd) {
    const ch = value[startEnd];
    if (ch === " ")
      startWithSpace = true;
    else if (ch === "\n")
      startNlPos = startEnd;
    else
      break;
  }
  let start = value.substring(0, startNlPos < startEnd ? startNlPos + 1 : startEnd);
  if (start) {
    value = value.substring(start.length);
    start = start.replace(/\n+/g, `$&${indent}`);
  }
  const indentSize = indent ? "2" : "1";
  let header = (startWithSpace ? indentSize : "") + chomp;
  if (comment) {
    header += " " + commentString(comment.replace(/ ?[\r\n]+/g, " "));
    if (onComment)
      onComment();
  }
  if (!literal) {
    const foldedValue = value.replace(/\n+/g, "\n$&").replace(/(?:^|\n)([\t ].*)(?:([\n\t ]*)\n(?![\n\t ]))?/g, "$1$2").replace(/\n+/g, `$&${indent}`);
    let literalFallback = false;
    const foldOptions = getFoldOptions(ctx, true);
    if (blockQuote !== "folded" && type !== Scalar.BLOCK_FOLDED) {
      foldOptions.onOverflow = () => {
        literalFallback = true;
      };
    }
    const body = foldFlowLines(`${start}${foldedValue}${end}`, indent, FOLD_BLOCK, foldOptions);
    if (!literalFallback)
      return `>${header}
${indent}${body}`;
  }
  value = value.replace(/\n+/g, `$&${indent}`);
  return `|${header}
${indent}${start}${value}${end}`;
}
function plainString(item, ctx, onComment, onChompKeep) {
  const { type, value } = item;
  const { actualString, implicitKey, indent, indentStep, inFlow } = ctx;
  if (implicitKey && value.includes("\n") || inFlow && /[[\]{},]/.test(value)) {
    return quotedString(value, ctx);
  }
  if (/^[\n\t ,[\]{}#&*!|>'"%@`]|^[?-]$|^[?-][ \t]|[\n:][ \t]|[ \t]\n|[\n\t ]#|[\n\t :]$/.test(value)) {
    return implicitKey || inFlow || !value.includes("\n") ? quotedString(value, ctx) : blockString(item, ctx, onComment, onChompKeep);
  }
  if (!implicitKey && !inFlow && type !== Scalar.PLAIN && value.includes("\n")) {
    return blockString(item, ctx, onComment, onChompKeep);
  }
  if (containsDocumentMarker(value)) {
    if (indent === "") {
      ctx.forceBlockIndent = true;
      return blockString(item, ctx, onComment, onChompKeep);
    } else if (implicitKey && indent === indentStep) {
      return quotedString(value, ctx);
    }
  }
  const str = value.replace(/\n+/g, `$&
${indent}`);
  if (actualString) {
    const test = (tag) => tag.default && tag.tag !== "tag:yaml.org,2002:str" && tag.test?.test(str);
    const { compat, tags } = ctx.doc.schema;
    if (tags.some(test) || compat?.some(test))
      return quotedString(value, ctx);
  }
  return implicitKey ? str : foldFlowLines(str, indent, FOLD_FLOW, getFoldOptions(ctx, false));
}
function stringifyString(item, ctx, onComment, onChompKeep) {
  const { implicitKey, inFlow } = ctx;
  const ss = typeof item.value === "string" ? item : Object.assign({}, item, { value: String(item.value) });
  let { type } = item;
  if (type !== Scalar.QUOTE_DOUBLE) {
    if (/[\x00-\x08\x0b-\x1f\x7f-\x9f\u{D800}-\u{DFFF}]/u.test(ss.value))
      type = Scalar.QUOTE_DOUBLE;
  }
  const _stringify = (_type) => {
    switch (_type) {
      case Scalar.BLOCK_FOLDED:
      case Scalar.BLOCK_LITERAL:
        return implicitKey || inFlow ? quotedString(ss.value, ctx) : blockString(ss, ctx, onComment, onChompKeep);
      case Scalar.QUOTE_DOUBLE:
        return doubleQuotedString(ss.value, ctx);
      case Scalar.QUOTE_SINGLE:
        return singleQuotedString(ss.value, ctx);
      case Scalar.PLAIN:
        return plainString(ss, ctx, onComment, onChompKeep);
      default:
        return null;
    }
  };
  let res = _stringify(type);
  if (res === null) {
    const { defaultKeyType, defaultStringType } = ctx.options;
    const t5 = implicitKey && defaultKeyType || defaultStringType;
    res = _stringify(t5);
    if (res === null)
      throw new Error(`Unsupported default string type ${t5}`);
  }
  return res;
}

// node_modules/yaml/browser/dist/stringify/stringify.js
function createStringifyContext(doc, options) {
  const opt = Object.assign({
    blockQuote: true,
    commentString: stringifyComment,
    defaultKeyType: null,
    defaultStringType: "PLAIN",
    directives: null,
    doubleQuotedAsJSON: false,
    doubleQuotedMinMultiLineLength: 40,
    falseStr: "false",
    flowCollectionPadding: true,
    indentSeq: true,
    lineWidth: 80,
    minContentWidth: 20,
    nullStr: "null",
    simpleKeys: false,
    singleQuote: null,
    trailingComma: false,
    trueStr: "true",
    verifyAliasOrder: true
  }, doc.schema.toStringOptions, options);
  let inFlow;
  switch (opt.collectionStyle) {
    case "block":
      inFlow = false;
      break;
    case "flow":
      inFlow = true;
      break;
    default:
      inFlow = null;
  }
  return {
    anchors: /* @__PURE__ */ new Set(),
    doc,
    flowCollectionPadding: opt.flowCollectionPadding ? " " : "",
    indent: "",
    indentStep: typeof opt.indent === "number" ? " ".repeat(opt.indent) : "  ",
    inFlow,
    options: opt
  };
}
function getTagObject(tags, item) {
  if (item.tag) {
    const match = tags.filter((t5) => t5.tag === item.tag);
    if (match.length > 0)
      return match.find((t5) => t5.format === item.format) ?? match[0];
  }
  let tagObj = void 0;
  let obj;
  if (isScalar(item)) {
    obj = item.value;
    let match = tags.filter((t5) => t5.identify?.(obj));
    if (match.length > 1) {
      const testMatch = match.filter((t5) => t5.test);
      if (testMatch.length > 0)
        match = testMatch;
    }
    tagObj = match.find((t5) => t5.format === item.format) ?? match.find((t5) => !t5.format);
  } else {
    obj = item;
    tagObj = tags.find((t5) => t5.nodeClass && obj instanceof t5.nodeClass);
  }
  if (!tagObj) {
    const name = obj?.constructor?.name ?? (obj === null ? "null" : typeof obj);
    throw new Error(`Tag not resolved for ${name} value`);
  }
  return tagObj;
}
function stringifyProps(node, tagObj, { anchors, doc }) {
  if (!doc.directives)
    return "";
  const props = [];
  const anchor = (isScalar(node) || isCollection(node)) && node.anchor;
  if (anchor && anchorIsValid(anchor)) {
    anchors.add(anchor);
    props.push(`&${anchor}`);
  }
  const tag = node.tag ?? (tagObj.default ? null : tagObj.tag);
  if (tag)
    props.push(doc.directives.tagString(tag));
  return props.join(" ");
}
function stringify(item, ctx, onComment, onChompKeep) {
  if (isPair(item))
    return item.toString(ctx, onComment, onChompKeep);
  if (isAlias(item)) {
    if (ctx.doc.directives)
      return item.toString(ctx);
    if (ctx.resolvedAliases?.has(item)) {
      throw new TypeError(`Cannot stringify circular structure without alias nodes`);
    } else {
      if (ctx.resolvedAliases)
        ctx.resolvedAliases.add(item);
      else
        ctx.resolvedAliases = /* @__PURE__ */ new Set([item]);
      item = item.resolve(ctx.doc);
    }
  }
  let tagObj = void 0;
  const node = isNode(item) ? item : ctx.doc.createNode(item, { onTagObj: (o7) => tagObj = o7 });
  tagObj ?? (tagObj = getTagObject(ctx.doc.schema.tags, node));
  const props = stringifyProps(node, tagObj, ctx);
  if (props.length > 0)
    ctx.indentAtStart = (ctx.indentAtStart ?? 0) + props.length + 1;
  const str = typeof tagObj.stringify === "function" ? tagObj.stringify(node, ctx, onComment, onChompKeep) : isScalar(node) ? stringifyString(node, ctx, onComment, onChompKeep) : node.toString(ctx, onComment, onChompKeep);
  if (!props)
    return str;
  return isScalar(node) || str[0] === "{" || str[0] === "[" ? `${props} ${str}` : `${props}
${ctx.indent}${str}`;
}

// node_modules/yaml/browser/dist/stringify/stringifyPair.js
function stringifyPair({ key, value }, ctx, onComment, onChompKeep) {
  const { allNullValues, doc, indent, indentStep, options: { commentString, indentSeq, simpleKeys } } = ctx;
  let keyComment = isNode(key) && key.comment || null;
  if (simpleKeys) {
    if (keyComment) {
      throw new Error("With simple keys, key nodes cannot have comments");
    }
    if (isCollection(key) || !isNode(key) && typeof key === "object") {
      const msg = "With simple keys, collection cannot be used as a key value";
      throw new Error(msg);
    }
  }
  let explicitKey = !simpleKeys && (!key || keyComment && value == null && !ctx.inFlow || isCollection(key) || (isScalar(key) ? key.type === Scalar.BLOCK_FOLDED || key.type === Scalar.BLOCK_LITERAL : typeof key === "object"));
  ctx = Object.assign({}, ctx, {
    allNullValues: false,
    implicitKey: !explicitKey && (simpleKeys || !allNullValues),
    indent: indent + indentStep
  });
  let keyCommentDone = false;
  let chompKeep = false;
  let str = stringify(key, ctx, () => keyCommentDone = true, () => chompKeep = true);
  if (!explicitKey && !ctx.inFlow && str.length > 1024) {
    if (simpleKeys)
      throw new Error("With simple keys, single line scalar must not span more than 1024 characters");
    explicitKey = true;
  }
  if (ctx.inFlow) {
    if (allNullValues || value == null) {
      if (keyCommentDone && onComment)
        onComment();
      return str === "" ? "?" : explicitKey ? `? ${str}` : str;
    }
  } else if (allNullValues && !simpleKeys || value == null && explicitKey) {
    str = `? ${str}`;
    if (keyComment && !keyCommentDone) {
      str += lineComment(str, ctx.indent, commentString(keyComment));
    } else if (chompKeep && onChompKeep)
      onChompKeep();
    return str;
  }
  if (keyCommentDone)
    keyComment = null;
  if (explicitKey) {
    if (keyComment)
      str += lineComment(str, ctx.indent, commentString(keyComment));
    str = `? ${str}
${indent}:`;
  } else {
    str = `${str}:`;
    if (keyComment)
      str += lineComment(str, ctx.indent, commentString(keyComment));
  }
  let vsb, vcb, valueComment;
  if (isNode(value)) {
    vsb = !!value.spaceBefore;
    vcb = value.commentBefore;
    valueComment = value.comment;
  } else {
    vsb = false;
    vcb = null;
    valueComment = null;
    if (value && typeof value === "object")
      value = doc.createNode(value);
  }
  ctx.implicitKey = false;
  if (!explicitKey && !keyComment && isScalar(value))
    ctx.indentAtStart = str.length + 1;
  chompKeep = false;
  if (!indentSeq && indentStep.length >= 2 && !ctx.inFlow && !explicitKey && isSeq(value) && !value.flow && !value.tag && !value.anchor) {
    ctx.indent = ctx.indent.substring(2);
  }
  let valueCommentDone = false;
  const valueStr = stringify(value, ctx, () => valueCommentDone = true, () => chompKeep = true);
  let ws = " ";
  if (keyComment || vsb || vcb) {
    ws = vsb ? "\n" : "";
    if (vcb) {
      const cs = commentString(vcb);
      ws += `
${indentComment(cs, ctx.indent)}`;
    }
    if (valueStr === "" && !ctx.inFlow) {
      if (ws === "\n" && valueComment)
        ws = "\n\n";
    } else {
      ws += `
${ctx.indent}`;
    }
  } else if (!explicitKey && isCollection(value)) {
    const vs0 = valueStr[0];
    const nl0 = valueStr.indexOf("\n");
    const hasNewline = nl0 !== -1;
    const flow = ctx.inFlow ?? value.flow ?? value.items.length === 0;
    if (hasNewline || !flow) {
      let hasPropsLine = false;
      if (hasNewline && (vs0 === "&" || vs0 === "!")) {
        let sp0 = valueStr.indexOf(" ");
        if (vs0 === "&" && sp0 !== -1 && sp0 < nl0 && valueStr[sp0 + 1] === "!") {
          sp0 = valueStr.indexOf(" ", sp0 + 1);
        }
        if (sp0 === -1 || nl0 < sp0)
          hasPropsLine = true;
      }
      if (!hasPropsLine)
        ws = `
${ctx.indent}`;
    }
  } else if (valueStr === "" || valueStr[0] === "\n") {
    ws = "";
  }
  str += ws + valueStr;
  if (ctx.inFlow) {
    if (valueCommentDone && onComment)
      onComment();
  } else if (valueComment && !valueCommentDone) {
    str += lineComment(str, ctx.indent, commentString(valueComment));
  } else if (chompKeep && onChompKeep) {
    onChompKeep();
  }
  return str;
}

// node_modules/yaml/browser/dist/log.js
function warn(logLevel, warning) {
  if (logLevel === "debug" || logLevel === "warn") {
    console.warn(warning);
  }
}

// node_modules/yaml/browser/dist/schema/yaml-1.1/merge.js
var MERGE_KEY = "<<";
var merge = {
  identify: (value) => value === MERGE_KEY || typeof value === "symbol" && value.description === MERGE_KEY,
  default: "key",
  tag: "tag:yaml.org,2002:merge",
  test: /^<<$/,
  resolve: () => Object.assign(new Scalar(Symbol(MERGE_KEY)), {
    addToJSMap: addMergeToJSMap
  }),
  stringify: () => MERGE_KEY
};
var isMergeKey = (ctx, key) => (merge.identify(key) || isScalar(key) && (!key.type || key.type === Scalar.PLAIN) && merge.identify(key.value)) && ctx?.doc.schema.tags.some((tag) => tag.tag === merge.tag && tag.default);
function addMergeToJSMap(ctx, map2, value) {
  const source = resolveAliasValue(ctx, value);
  if (isSeq(source))
    for (const it of source.items)
      mergeValue(ctx, map2, it);
  else if (Array.isArray(source))
    for (const it of source)
      mergeValue(ctx, map2, it);
  else
    mergeValue(ctx, map2, source);
}
function mergeValue(ctx, map2, value) {
  const source = resolveAliasValue(ctx, value);
  if (!isMap(source))
    throw new Error("Merge sources must be maps or map aliases");
  const srcMap = source.toJSON(null, ctx, Map);
  for (const [key, value2] of srcMap) {
    if (map2 instanceof Map) {
      if (!map2.has(key))
        map2.set(key, value2);
    } else if (map2 instanceof Set) {
      map2.add(key);
    } else if (!Object.prototype.hasOwnProperty.call(map2, key)) {
      Object.defineProperty(map2, key, {
        value: value2,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
  }
  return map2;
}
function resolveAliasValue(ctx, value) {
  return ctx && isAlias(value) ? value.resolve(ctx.doc, ctx) : value;
}

// node_modules/yaml/browser/dist/nodes/addPairToJSMap.js
function addPairToJSMap(ctx, map2, { key, value }) {
  if (isNode(key) && key.addToJSMap)
    key.addToJSMap(ctx, map2, value);
  else if (isMergeKey(ctx, key))
    addMergeToJSMap(ctx, map2, value);
  else {
    const jsKey = toJS(key, "", ctx);
    if (map2 instanceof Map) {
      map2.set(jsKey, toJS(value, jsKey, ctx));
    } else if (map2 instanceof Set) {
      map2.add(jsKey);
    } else {
      const stringKey = stringifyKey(key, jsKey, ctx);
      const jsValue = toJS(value, stringKey, ctx);
      if (stringKey in map2)
        Object.defineProperty(map2, stringKey, {
          value: jsValue,
          writable: true,
          enumerable: true,
          configurable: true
        });
      else
        map2[stringKey] = jsValue;
    }
  }
  return map2;
}
function stringifyKey(key, jsKey, ctx) {
  if (jsKey === null)
    return "";
  if (typeof jsKey !== "object")
    return String(jsKey);
  if (isNode(key) && ctx?.doc) {
    const strCtx = createStringifyContext(ctx.doc, {});
    strCtx.anchors = /* @__PURE__ */ new Set();
    for (const node of ctx.anchors.keys())
      strCtx.anchors.add(node.anchor);
    strCtx.inFlow = true;
    strCtx.inStringifyKey = true;
    const strKey = key.toString(strCtx);
    if (!ctx.mapKeyWarned) {
      let jsonStr = JSON.stringify(strKey);
      if (jsonStr.length > 40)
        jsonStr = jsonStr.substring(0, 36) + '..."';
      warn(ctx.doc.options.logLevel, `Keys with collection values will be stringified due to JS Object restrictions: ${jsonStr}. Set mapAsMap: true to use object keys.`);
      ctx.mapKeyWarned = true;
    }
    return strKey;
  }
  return JSON.stringify(jsKey);
}

// node_modules/yaml/browser/dist/nodes/Pair.js
function createPair(key, value, ctx) {
  const k2 = createNode(key, void 0, ctx);
  const v2 = createNode(value, void 0, ctx);
  return new Pair(k2, v2);
}
var Pair = class _Pair {
  constructor(key, value = null) {
    Object.defineProperty(this, NODE_TYPE, { value: PAIR });
    this.key = key;
    this.value = value;
  }
  clone(schema4) {
    let { key, value } = this;
    if (isNode(key))
      key = key.clone(schema4);
    if (isNode(value))
      value = value.clone(schema4);
    return new _Pair(key, value);
  }
  toJSON(_2, ctx) {
    const pair = ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
    return addPairToJSMap(ctx, pair, this);
  }
  toString(ctx, onComment, onChompKeep) {
    return ctx?.doc ? stringifyPair(this, ctx, onComment, onChompKeep) : JSON.stringify(this);
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyCollection.js
function stringifyCollection(collection, ctx, options) {
  const flow = ctx.inFlow ?? collection.flow;
  const stringify4 = flow ? stringifyFlowCollection : stringifyBlockCollection;
  return stringify4(collection, ctx, options);
}
function stringifyBlockCollection({ comment, items }, ctx, { blockItemPrefix, flowChars, itemIndent, onChompKeep, onComment }) {
  const { indent, options: { commentString } } = ctx;
  const itemCtx = Object.assign({}, ctx, { indent: itemIndent, type: null });
  let chompKeep = false;
  const lines = [];
  for (let i6 = 0; i6 < items.length; ++i6) {
    const item = items[i6];
    let comment2 = null;
    if (isNode(item)) {
      if (!chompKeep && item.spaceBefore)
        lines.push("");
      addCommentBefore(ctx, lines, item.commentBefore, chompKeep);
      if (item.comment)
        comment2 = item.comment;
    } else if (isPair(item)) {
      const ik = isNode(item.key) ? item.key : null;
      if (ik) {
        if (!chompKeep && ik.spaceBefore)
          lines.push("");
        addCommentBefore(ctx, lines, ik.commentBefore, chompKeep);
      }
    }
    chompKeep = false;
    let str2 = stringify(item, itemCtx, () => comment2 = null, () => chompKeep = true);
    if (comment2)
      str2 += lineComment(str2, itemIndent, commentString(comment2));
    if (chompKeep && comment2)
      chompKeep = false;
    lines.push(blockItemPrefix + str2);
  }
  let str;
  if (lines.length === 0) {
    str = flowChars.start + flowChars.end;
  } else {
    str = lines[0];
    for (let i6 = 1; i6 < lines.length; ++i6) {
      const line = lines[i6];
      str += line ? `
${indent}${line}` : "\n";
    }
  }
  if (comment) {
    str += "\n" + indentComment(commentString(comment), indent);
    if (onComment)
      onComment();
  } else if (chompKeep && onChompKeep)
    onChompKeep();
  return str;
}
function stringifyFlowCollection({ items }, ctx, { flowChars, itemIndent }) {
  const { indent, indentStep, flowCollectionPadding: fcPadding, options: { commentString } } = ctx;
  itemIndent += indentStep;
  const itemCtx = Object.assign({}, ctx, {
    indent: itemIndent,
    inFlow: true,
    type: null
  });
  let reqNewline = false;
  let linesAtValue = 0;
  const lines = [];
  for (let i6 = 0; i6 < items.length; ++i6) {
    const item = items[i6];
    let comment = null;
    if (isNode(item)) {
      if (item.spaceBefore)
        lines.push("");
      addCommentBefore(ctx, lines, item.commentBefore, false);
      if (item.comment)
        comment = item.comment;
    } else if (isPair(item)) {
      const ik = isNode(item.key) ? item.key : null;
      if (ik) {
        if (ik.spaceBefore)
          lines.push("");
        addCommentBefore(ctx, lines, ik.commentBefore, false);
        if (ik.comment)
          reqNewline = true;
      }
      const iv = isNode(item.value) ? item.value : null;
      if (iv) {
        if (iv.comment)
          comment = iv.comment;
        if (iv.commentBefore)
          reqNewline = true;
      } else if (item.value == null && ik?.comment) {
        comment = ik.comment;
      }
    }
    if (comment)
      reqNewline = true;
    let str = stringify(item, itemCtx, () => comment = null);
    reqNewline || (reqNewline = lines.length > linesAtValue || str.includes("\n"));
    if (i6 < items.length - 1) {
      str += ",";
    } else if (ctx.options.trailingComma) {
      if (ctx.options.lineWidth > 0) {
        reqNewline || (reqNewline = lines.reduce((sum, line) => sum + line.length + 2, 2) + (str.length + 2) > ctx.options.lineWidth);
      }
      if (reqNewline) {
        str += ",";
      }
    }
    if (comment)
      str += lineComment(str, itemIndent, commentString(comment));
    lines.push(str);
    linesAtValue = lines.length;
  }
  const { start, end } = flowChars;
  if (lines.length === 0) {
    return start + end;
  } else {
    if (!reqNewline) {
      const len = lines.reduce((sum, line) => sum + line.length + 2, 2);
      reqNewline = ctx.options.lineWidth > 0 && len > ctx.options.lineWidth;
    }
    if (reqNewline) {
      let str = start;
      for (const line of lines)
        str += line ? `
${indentStep}${indent}${line}` : "\n";
      return `${str}
${indent}${end}`;
    } else {
      return `${start}${fcPadding}${lines.join(" ")}${fcPadding}${end}`;
    }
  }
}
function addCommentBefore({ indent, options: { commentString } }, lines, comment, chompKeep) {
  if (comment && chompKeep)
    comment = comment.replace(/^\n+/, "");
  if (comment) {
    const ic = indentComment(commentString(comment), indent);
    lines.push(ic.trimStart());
  }
}

// node_modules/yaml/browser/dist/nodes/YAMLMap.js
function findPair(items, key) {
  const k2 = isScalar(key) ? key.value : key;
  for (const it of items) {
    if (isPair(it)) {
      if (it.key === key || it.key === k2)
        return it;
      if (isScalar(it.key) && it.key.value === k2)
        return it;
    }
  }
  return void 0;
}
var YAMLMap = class extends Collection {
  static get tagName() {
    return "tag:yaml.org,2002:map";
  }
  constructor(schema4) {
    super(MAP, schema4);
    this.items = [];
  }
  /**
   * A generic collection parsing method that can be extended
   * to other node classes that inherit from YAMLMap
   */
  static from(schema4, obj, ctx) {
    const { keepUndefined, replacer } = ctx;
    const map2 = new this(schema4);
    const add = (key, value) => {
      if (typeof replacer === "function")
        value = replacer.call(obj, key, value);
      else if (Array.isArray(replacer) && !replacer.includes(key))
        return;
      if (value !== void 0 || keepUndefined)
        map2.items.push(createPair(key, value, ctx));
    };
    if (obj instanceof Map) {
      for (const [key, value] of obj)
        add(key, value);
    } else if (obj && typeof obj === "object") {
      for (const key of Object.keys(obj))
        add(key, obj[key]);
    }
    if (typeof schema4.sortMapEntries === "function") {
      map2.items.sort(schema4.sortMapEntries);
    }
    return map2;
  }
  /**
   * Adds a value to the collection.
   *
   * @param overwrite - If not set `true`, using a key that is already in the
   *   collection will throw. Otherwise, overwrites the previous value.
   */
  add(pair, overwrite) {
    let _pair;
    if (isPair(pair))
      _pair = pair;
    else if (!pair || typeof pair !== "object" || !("key" in pair)) {
      _pair = new Pair(pair, pair?.value);
    } else
      _pair = new Pair(pair.key, pair.value);
    const prev = findPair(this.items, _pair.key);
    const sortEntries = this.schema?.sortMapEntries;
    if (prev) {
      if (!overwrite)
        throw new Error(`Key ${_pair.key} already set`);
      if (isScalar(prev.value) && isScalarValue(_pair.value))
        prev.value.value = _pair.value;
      else
        prev.value = _pair.value;
    } else if (sortEntries) {
      const i6 = this.items.findIndex((item) => sortEntries(_pair, item) < 0);
      if (i6 === -1)
        this.items.push(_pair);
      else
        this.items.splice(i6, 0, _pair);
    } else {
      this.items.push(_pair);
    }
  }
  delete(key) {
    const it = findPair(this.items, key);
    if (!it)
      return false;
    const del = this.items.splice(this.items.indexOf(it), 1);
    return del.length > 0;
  }
  get(key, keepScalar) {
    const it = findPair(this.items, key);
    const node = it?.value;
    return (!keepScalar && isScalar(node) ? node.value : node) ?? void 0;
  }
  has(key) {
    return !!findPair(this.items, key);
  }
  set(key, value) {
    this.add(new Pair(key, value), true);
  }
  /**
   * @param ctx - Conversion context, originally set in Document#toJS()
   * @param {Class} Type - If set, forces the returned collection type
   * @returns Instance of Type, Map, or Object
   */
  toJSON(_2, ctx, Type) {
    const map2 = Type ? new Type() : ctx?.mapAsMap ? /* @__PURE__ */ new Map() : {};
    if (ctx?.onCreate)
      ctx.onCreate(map2);
    for (const item of this.items)
      addPairToJSMap(ctx, map2, item);
    return map2;
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    for (const item of this.items) {
      if (!isPair(item))
        throw new Error(`Map items must all be pairs; found ${JSON.stringify(item)} instead`);
    }
    if (!ctx.allNullValues && this.hasAllNullValues(false))
      ctx = Object.assign({}, ctx, { allNullValues: true });
    return stringifyCollection(this, ctx, {
      blockItemPrefix: "",
      flowChars: { start: "{", end: "}" },
      itemIndent: ctx.indent || "",
      onChompKeep,
      onComment
    });
  }
};

// node_modules/yaml/browser/dist/schema/common/map.js
var map = {
  collection: "map",
  default: true,
  nodeClass: YAMLMap,
  tag: "tag:yaml.org,2002:map",
  resolve(map2, onError) {
    if (!isMap(map2))
      onError("Expected a mapping for this tag");
    return map2;
  },
  createNode: (schema4, obj, ctx) => YAMLMap.from(schema4, obj, ctx)
};

// node_modules/yaml/browser/dist/nodes/YAMLSeq.js
var YAMLSeq = class extends Collection {
  static get tagName() {
    return "tag:yaml.org,2002:seq";
  }
  constructor(schema4) {
    super(SEQ, schema4);
    this.items = [];
  }
  add(value) {
    this.items.push(value);
  }
  /**
   * Removes a value from the collection.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   *
   * @returns `true` if the item was found and removed.
   */
  delete(key) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      return false;
    const del = this.items.splice(idx, 1);
    return del.length > 0;
  }
  get(key, keepScalar) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      return void 0;
    const it = this.items[idx];
    return !keepScalar && isScalar(it) ? it.value : it;
  }
  /**
   * Checks if the collection includes a value with the key `key`.
   *
   * `key` must contain a representation of an integer for this to succeed.
   * It may be wrapped in a `Scalar`.
   */
  has(key) {
    const idx = asItemIndex(key);
    return typeof idx === "number" && idx < this.items.length;
  }
  /**
   * Sets a value in this collection. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   *
   * If `key` does not contain a representation of an integer, this will throw.
   * It may be wrapped in a `Scalar`.
   */
  set(key, value) {
    const idx = asItemIndex(key);
    if (typeof idx !== "number")
      throw new Error(`Expected a valid index, not ${key}.`);
    const prev = this.items[idx];
    if (isScalar(prev) && isScalarValue(value))
      prev.value = value;
    else
      this.items[idx] = value;
  }
  toJSON(_2, ctx) {
    const seq2 = [];
    if (ctx?.onCreate)
      ctx.onCreate(seq2);
    let i6 = 0;
    for (const item of this.items)
      seq2.push(toJS(item, String(i6++), ctx));
    return seq2;
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    return stringifyCollection(this, ctx, {
      blockItemPrefix: "- ",
      flowChars: { start: "[", end: "]" },
      itemIndent: (ctx.indent || "") + "  ",
      onChompKeep,
      onComment
    });
  }
  static from(schema4, obj, ctx) {
    const { replacer } = ctx;
    const seq2 = new this(schema4);
    if (obj && Symbol.iterator in Object(obj)) {
      let i6 = 0;
      for (let it of obj) {
        if (typeof replacer === "function") {
          const key = obj instanceof Set ? it : String(i6++);
          it = replacer.call(obj, key, it);
        }
        seq2.items.push(createNode(it, void 0, ctx));
      }
    }
    return seq2;
  }
};
function asItemIndex(key) {
  let idx = isScalar(key) ? key.value : key;
  if (idx && typeof idx === "string")
    idx = Number(idx);
  return typeof idx === "number" && Number.isInteger(idx) && idx >= 0 ? idx : null;
}

// node_modules/yaml/browser/dist/schema/common/seq.js
var seq = {
  collection: "seq",
  default: true,
  nodeClass: YAMLSeq,
  tag: "tag:yaml.org,2002:seq",
  resolve(seq2, onError) {
    if (!isSeq(seq2))
      onError("Expected a sequence for this tag");
    return seq2;
  },
  createNode: (schema4, obj, ctx) => YAMLSeq.from(schema4, obj, ctx)
};

// node_modules/yaml/browser/dist/schema/common/string.js
var string = {
  identify: (value) => typeof value === "string",
  default: true,
  tag: "tag:yaml.org,2002:str",
  resolve: (str) => str,
  stringify(item, ctx, onComment, onChompKeep) {
    ctx = Object.assign({ actualString: true }, ctx);
    return stringifyString(item, ctx, onComment, onChompKeep);
  }
};

// node_modules/yaml/browser/dist/schema/common/null.js
var nullTag = {
  identify: (value) => value == null,
  createNode: () => new Scalar(null),
  default: true,
  tag: "tag:yaml.org,2002:null",
  test: /^(?:~|[Nn]ull|NULL)?$/,
  resolve: () => new Scalar(null),
  stringify: ({ source }, ctx) => typeof source === "string" && nullTag.test.test(source) ? source : ctx.options.nullStr
};

// node_modules/yaml/browser/dist/schema/core/bool.js
var boolTag = {
  identify: (value) => typeof value === "boolean",
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:[Tt]rue|TRUE|[Ff]alse|FALSE)$/,
  resolve: (str) => new Scalar(str[0] === "t" || str[0] === "T"),
  stringify({ source, value }, ctx) {
    if (source && boolTag.test.test(source)) {
      const sv = source[0] === "t" || source[0] === "T";
      if (value === sv)
        return source;
    }
    return value ? ctx.options.trueStr : ctx.options.falseStr;
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyNumber.js
function stringifyNumber({ format, minFractionDigits, tag, value }) {
  if (typeof value === "bigint")
    return String(value);
  const num = typeof value === "number" ? value : Number(value);
  if (!isFinite(num))
    return isNaN(num) ? ".nan" : num < 0 ? "-.inf" : ".inf";
  let n6 = Object.is(value, -0) ? "-0" : JSON.stringify(value);
  if (!format && minFractionDigits && (!tag || tag === "tag:yaml.org,2002:float") && /^-?\d/.test(n6) && !n6.includes("e")) {
    let i6 = n6.indexOf(".");
    if (i6 < 0) {
      i6 = n6.length;
      n6 += ".";
    }
    let d3 = minFractionDigits - (n6.length - i6 - 1);
    while (d3-- > 0)
      n6 += "0";
  }
  return n6;
}

// node_modules/yaml/browser/dist/schema/core/float.js
var floatNaN = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: stringifyNumber
};
var floatExp = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+(?:\.[0-9]*)?)[eE][-+]?[0-9]+$/,
  resolve: (str) => parseFloat(str),
  stringify(node) {
    const num = Number(node.value);
    return isFinite(num) ? num.toExponential() : stringifyNumber(node);
  }
};
var float = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:\.[0-9]+|[0-9]+\.[0-9]*)$/,
  resolve(str) {
    const node = new Scalar(parseFloat(str));
    const dot = str.indexOf(".");
    if (dot !== -1 && str[str.length - 1] === "0")
      node.minFractionDigits = str.length - dot - 1;
    return node;
  },
  stringify: stringifyNumber
};

// node_modules/yaml/browser/dist/schema/core/int.js
var intIdentify = (value) => typeof value === "bigint" || Number.isInteger(value);
var intResolve = (str, offset, radix, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str.substring(offset), radix);
function intStringify(node, radix, prefix) {
  const { value } = node;
  if (intIdentify(value) && value >= 0)
    return prefix + value.toString(radix);
  return stringifyNumber(node);
}
var intOct = {
  identify: (value) => intIdentify(value) && value >= 0,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^0o[0-7]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 2, 8, opt),
  stringify: (node) => intStringify(node, 8, "0o")
};
var int = {
  identify: intIdentify,
  default: true,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 0, 10, opt),
  stringify: stringifyNumber
};
var intHex = {
  identify: (value) => intIdentify(value) && value >= 0,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^0x[0-9a-fA-F]+$/,
  resolve: (str, _onError, opt) => intResolve(str, 2, 16, opt),
  stringify: (node) => intStringify(node, 16, "0x")
};

// node_modules/yaml/browser/dist/schema/core/schema.js
var schema = [
  map,
  seq,
  string,
  nullTag,
  boolTag,
  intOct,
  int,
  intHex,
  floatNaN,
  floatExp,
  float
];

// node_modules/yaml/browser/dist/schema/json/schema.js
function intIdentify2(value) {
  return typeof value === "bigint" || Number.isInteger(value);
}
var stringifyJSON = ({ value }) => JSON.stringify(value);
var jsonScalars = [
  {
    identify: (value) => typeof value === "string",
    default: true,
    tag: "tag:yaml.org,2002:str",
    resolve: (str) => str,
    stringify: stringifyJSON
  },
  {
    identify: (value) => value == null,
    createNode: () => new Scalar(null),
    default: true,
    tag: "tag:yaml.org,2002:null",
    test: /^null$/,
    resolve: () => null,
    stringify: stringifyJSON
  },
  {
    identify: (value) => typeof value === "boolean",
    default: true,
    tag: "tag:yaml.org,2002:bool",
    test: /^true$|^false$/,
    resolve: (str) => str === "true",
    stringify: stringifyJSON
  },
  {
    identify: intIdentify2,
    default: true,
    tag: "tag:yaml.org,2002:int",
    test: /^-?(?:0|[1-9][0-9]*)$/,
    resolve: (str, _onError, { intAsBigInt }) => intAsBigInt ? BigInt(str) : parseInt(str, 10),
    stringify: ({ value }) => intIdentify2(value) ? value.toString() : JSON.stringify(value)
  },
  {
    identify: (value) => typeof value === "number",
    default: true,
    tag: "tag:yaml.org,2002:float",
    test: /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$/,
    resolve: (str) => parseFloat(str),
    stringify: stringifyJSON
  }
];
var jsonError = {
  default: true,
  tag: "",
  test: /^/,
  resolve(str, onError) {
    onError(`Unresolved plain scalar ${JSON.stringify(str)}`);
    return str;
  }
};
var schema2 = [map, seq].concat(jsonScalars, jsonError);

// node_modules/yaml/browser/dist/schema/yaml-1.1/binary.js
var binary = {
  identify: (value) => value instanceof Uint8Array,
  // Buffer inherits from Uint8Array
  default: false,
  tag: "tag:yaml.org,2002:binary",
  /**
   * Returns a Buffer in node and an Uint8Array in browsers
   *
   * To use the resulting buffer as an image, you'll want to do something like:
   *
   *   const blob = new Blob([buffer], { type: 'image/jpeg' })
   *   document.querySelector('#photo').src = URL.createObjectURL(blob)
   */
  resolve(src, onError) {
    if (typeof atob === "function") {
      const str = atob(src.replace(/[\n\r]/g, ""));
      const buffer = new Uint8Array(str.length);
      for (let i6 = 0; i6 < str.length; ++i6)
        buffer[i6] = str.charCodeAt(i6);
      return buffer;
    } else {
      onError("This environment does not support reading binary tags; either Buffer or atob is required");
      return src;
    }
  },
  stringify({ comment, type, value }, ctx, onComment, onChompKeep) {
    if (!value)
      return "";
    const buf = value;
    let str;
    if (typeof btoa === "function") {
      let s5 = "";
      for (let i6 = 0; i6 < buf.length; ++i6)
        s5 += String.fromCharCode(buf[i6]);
      str = btoa(s5);
    } else {
      throw new Error("This environment does not support writing binary tags; either Buffer or btoa is required");
    }
    type ?? (type = Scalar.BLOCK_LITERAL);
    if (type !== Scalar.QUOTE_DOUBLE) {
      const lineWidth = Math.max(ctx.options.lineWidth - ctx.indent.length, ctx.options.minContentWidth);
      const n6 = Math.ceil(str.length / lineWidth);
      const lines = new Array(n6);
      for (let i6 = 0, o7 = 0; i6 < n6; ++i6, o7 += lineWidth) {
        lines[i6] = str.substr(o7, lineWidth);
      }
      str = lines.join(type === Scalar.BLOCK_LITERAL ? "\n" : " ");
    }
    return stringifyString({ comment, type, value: str }, ctx, onComment, onChompKeep);
  }
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/pairs.js
function resolvePairs(seq2, onError) {
  if (isSeq(seq2)) {
    for (let i6 = 0; i6 < seq2.items.length; ++i6) {
      let item = seq2.items[i6];
      if (isPair(item))
        continue;
      else if (isMap(item)) {
        if (item.items.length > 1)
          onError("Each pair must have its own sequence indicator");
        const pair = item.items[0] || new Pair(new Scalar(null));
        if (item.commentBefore)
          pair.key.commentBefore = pair.key.commentBefore ? `${item.commentBefore}
${pair.key.commentBefore}` : item.commentBefore;
        if (item.comment) {
          const cn = pair.value ?? pair.key;
          cn.comment = cn.comment ? `${item.comment}
${cn.comment}` : item.comment;
        }
        item = pair;
      }
      seq2.items[i6] = isPair(item) ? item : new Pair(item);
    }
  } else
    onError("Expected a sequence for this tag");
  return seq2;
}
function createPairs(schema4, iterable, ctx) {
  const { replacer } = ctx;
  const pairs2 = new YAMLSeq(schema4);
  pairs2.tag = "tag:yaml.org,2002:pairs";
  let i6 = 0;
  if (iterable && Symbol.iterator in Object(iterable))
    for (let it of iterable) {
      if (typeof replacer === "function")
        it = replacer.call(iterable, String(i6++), it);
      let key, value;
      if (Array.isArray(it)) {
        if (it.length === 2) {
          key = it[0];
          value = it[1];
        } else
          throw new TypeError(`Expected [key, value] tuple: ${it}`);
      } else if (it && it instanceof Object) {
        const keys = Object.keys(it);
        if (keys.length === 1) {
          key = keys[0];
          value = it[key];
        } else {
          throw new TypeError(`Expected tuple with one key, not ${keys.length} keys`);
        }
      } else {
        key = it;
      }
      pairs2.items.push(createPair(key, value, ctx));
    }
  return pairs2;
}
var pairs = {
  collection: "seq",
  default: false,
  tag: "tag:yaml.org,2002:pairs",
  resolve: resolvePairs,
  createNode: createPairs
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/omap.js
var YAMLOMap = class _YAMLOMap extends YAMLSeq {
  constructor() {
    super();
    this.add = YAMLMap.prototype.add.bind(this);
    this.delete = YAMLMap.prototype.delete.bind(this);
    this.get = YAMLMap.prototype.get.bind(this);
    this.has = YAMLMap.prototype.has.bind(this);
    this.set = YAMLMap.prototype.set.bind(this);
    this.tag = _YAMLOMap.tag;
  }
  /**
   * If `ctx` is given, the return type is actually `Map<unknown, unknown>`,
   * but TypeScript won't allow widening the signature of a child method.
   */
  toJSON(_2, ctx) {
    if (!ctx)
      return super.toJSON(_2);
    const map2 = /* @__PURE__ */ new Map();
    if (ctx?.onCreate)
      ctx.onCreate(map2);
    for (const pair of this.items) {
      let key, value;
      if (isPair(pair)) {
        key = toJS(pair.key, "", ctx);
        value = toJS(pair.value, key, ctx);
      } else {
        key = toJS(pair, "", ctx);
      }
      if (map2.has(key))
        throw new Error("Ordered maps must not include duplicate keys");
      map2.set(key, value);
    }
    return map2;
  }
  static from(schema4, iterable, ctx) {
    const pairs2 = createPairs(schema4, iterable, ctx);
    const omap2 = new this();
    omap2.items = pairs2.items;
    return omap2;
  }
};
YAMLOMap.tag = "tag:yaml.org,2002:omap";
var omap = {
  collection: "seq",
  identify: (value) => value instanceof Map,
  nodeClass: YAMLOMap,
  default: false,
  tag: "tag:yaml.org,2002:omap",
  resolve(seq2, onError) {
    const pairs2 = resolvePairs(seq2, onError);
    const seenKeys = [];
    for (const { key } of pairs2.items) {
      if (isScalar(key)) {
        if (seenKeys.includes(key.value)) {
          onError(`Ordered maps must not include duplicate keys: ${key.value}`);
        } else {
          seenKeys.push(key.value);
        }
      }
    }
    return Object.assign(new YAMLOMap(), pairs2);
  },
  createNode: (schema4, iterable, ctx) => YAMLOMap.from(schema4, iterable, ctx)
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/bool.js
function boolStringify({ value, source }, ctx) {
  const boolObj = value ? trueTag : falseTag;
  if (source && boolObj.test.test(source))
    return source;
  return value ? ctx.options.trueStr : ctx.options.falseStr;
}
var trueTag = {
  identify: (value) => value === true,
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:Y|y|[Yy]es|YES|[Tt]rue|TRUE|[Oo]n|ON)$/,
  resolve: () => new Scalar(true),
  stringify: boolStringify
};
var falseTag = {
  identify: (value) => value === false,
  default: true,
  tag: "tag:yaml.org,2002:bool",
  test: /^(?:N|n|[Nn]o|NO|[Ff]alse|FALSE|[Oo]ff|OFF)$/,
  resolve: () => new Scalar(false),
  stringify: boolStringify
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/float.js
var floatNaN2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^(?:[-+]?\.(?:inf|Inf|INF)|\.nan|\.NaN|\.NAN)$/,
  resolve: (str) => str.slice(-3).toLowerCase() === "nan" ? NaN : str[0] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY,
  stringify: stringifyNumber
};
var floatExp2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "EXP",
  test: /^[-+]?(?:[0-9][0-9_]*)?(?:\.[0-9_]*)?[eE][-+]?[0-9]+$/,
  resolve: (str) => parseFloat(str.replace(/_/g, "")),
  stringify(node) {
    const num = Number(node.value);
    return isFinite(num) ? num.toExponential() : stringifyNumber(node);
  }
};
var float2 = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  test: /^[-+]?(?:[0-9][0-9_]*)?\.[0-9_]*$/,
  resolve(str) {
    const node = new Scalar(parseFloat(str.replace(/_/g, "")));
    const dot = str.indexOf(".");
    if (dot !== -1) {
      const f4 = str.substring(dot + 1).replace(/_/g, "");
      if (f4[f4.length - 1] === "0")
        node.minFractionDigits = f4.length;
    }
    return node;
  },
  stringify: stringifyNumber
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/int.js
var intIdentify3 = (value) => typeof value === "bigint" || Number.isInteger(value);
function intResolve2(str, offset, radix, { intAsBigInt }) {
  const sign = str[0];
  if (sign === "-" || sign === "+")
    offset += 1;
  str = str.substring(offset).replace(/_/g, "");
  if (intAsBigInt) {
    switch (radix) {
      case 2:
        str = `0b${str}`;
        break;
      case 8:
        str = `0o${str}`;
        break;
      case 16:
        str = `0x${str}`;
        break;
    }
    const n7 = BigInt(str);
    return sign === "-" ? BigInt(-1) * n7 : n7;
  }
  const n6 = parseInt(str, radix);
  return sign === "-" ? -1 * n6 : n6;
}
function intStringify2(node, radix, prefix) {
  const { value } = node;
  if (intIdentify3(value)) {
    const str = value.toString(radix);
    return value < 0 ? "-" + prefix + str.substr(1) : prefix + str;
  }
  return stringifyNumber(node);
}
var intBin = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "BIN",
  test: /^[-+]?0b[0-1_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 2, 2, opt),
  stringify: (node) => intStringify2(node, 2, "0b")
};
var intOct2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "OCT",
  test: /^[-+]?0[0-7_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 1, 8, opt),
  stringify: (node) => intStringify2(node, 8, "0")
};
var int2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  test: /^[-+]?[0-9][0-9_]*$/,
  resolve: (str, _onError, opt) => intResolve2(str, 0, 10, opt),
  stringify: stringifyNumber
};
var intHex2 = {
  identify: intIdentify3,
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "HEX",
  test: /^[-+]?0x[0-9a-fA-F_]+$/,
  resolve: (str, _onError, opt) => intResolve2(str, 2, 16, opt),
  stringify: (node) => intStringify2(node, 16, "0x")
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/set.js
var YAMLSet = class _YAMLSet extends YAMLMap {
  constructor(schema4) {
    super(schema4);
    this.tag = _YAMLSet.tag;
  }
  add(key) {
    let pair;
    if (isPair(key))
      pair = key;
    else if (key && typeof key === "object" && "key" in key && "value" in key && key.value === null)
      pair = new Pair(key.key, null);
    else
      pair = new Pair(key, null);
    const prev = findPair(this.items, pair.key);
    if (!prev)
      this.items.push(pair);
  }
  /**
   * If `keepPair` is `true`, returns the Pair matching `key`.
   * Otherwise, returns the value of that Pair's key.
   */
  get(key, keepPair) {
    const pair = findPair(this.items, key);
    return !keepPair && isPair(pair) ? isScalar(pair.key) ? pair.key.value : pair.key : pair;
  }
  set(key, value) {
    if (typeof value !== "boolean")
      throw new Error(`Expected boolean value for set(key, value) in a YAML set, not ${typeof value}`);
    const prev = findPair(this.items, key);
    if (prev && !value) {
      this.items.splice(this.items.indexOf(prev), 1);
    } else if (!prev && value) {
      this.items.push(new Pair(key));
    }
  }
  toJSON(_2, ctx) {
    return super.toJSON(_2, ctx, Set);
  }
  toString(ctx, onComment, onChompKeep) {
    if (!ctx)
      return JSON.stringify(this);
    if (this.hasAllNullValues(true))
      return super.toString(Object.assign({}, ctx, { allNullValues: true }), onComment, onChompKeep);
    else
      throw new Error("Set items must all have null values");
  }
  static from(schema4, iterable, ctx) {
    const { replacer } = ctx;
    const set2 = new this(schema4);
    if (iterable && Symbol.iterator in Object(iterable))
      for (let value of iterable) {
        if (typeof replacer === "function")
          value = replacer.call(iterable, value, value);
        set2.items.push(createPair(value, null, ctx));
      }
    return set2;
  }
};
YAMLSet.tag = "tag:yaml.org,2002:set";
var set = {
  collection: "map",
  identify: (value) => value instanceof Set,
  nodeClass: YAMLSet,
  default: false,
  tag: "tag:yaml.org,2002:set",
  createNode: (schema4, iterable, ctx) => YAMLSet.from(schema4, iterable, ctx),
  resolve(map2, onError) {
    if (isMap(map2)) {
      if (map2.hasAllNullValues(true))
        return Object.assign(new YAMLSet(), map2);
      else
        onError("Set items must all have null values");
    } else
      onError("Expected a mapping for this tag");
    return map2;
  }
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/timestamp.js
function parseSexagesimal(str, asBigInt) {
  const sign = str[0];
  const parts = sign === "-" || sign === "+" ? str.substring(1) : str;
  const num = (n6) => asBigInt ? BigInt(n6) : Number(n6);
  const res = parts.replace(/_/g, "").split(":").reduce((res2, p3) => res2 * num(60) + num(p3), num(0));
  return sign === "-" ? num(-1) * res : res;
}
function stringifySexagesimal(node) {
  let { value } = node;
  let num = (n6) => n6;
  if (typeof value === "bigint")
    num = (n6) => BigInt(n6);
  else if (isNaN(value) || !isFinite(value))
    return stringifyNumber(node);
  let sign = "";
  if (value < 0) {
    sign = "-";
    value *= num(-1);
  }
  const _60 = num(60);
  const parts = [value % _60];
  if (value < 60) {
    parts.unshift(0);
  } else {
    value = (value - parts[0]) / _60;
    parts.unshift(value % _60);
    if (value >= 60) {
      value = (value - parts[0]) / _60;
      parts.unshift(value);
    }
  }
  return sign + parts.map((n6) => String(n6).padStart(2, "0")).join(":").replace(/000000\d*$/, "");
}
var intTime = {
  identify: (value) => typeof value === "bigint" || Number.isInteger(value),
  default: true,
  tag: "tag:yaml.org,2002:int",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+$/,
  resolve: (str, _onError, { intAsBigInt }) => parseSexagesimal(str, intAsBigInt),
  stringify: stringifySexagesimal
};
var floatTime = {
  identify: (value) => typeof value === "number",
  default: true,
  tag: "tag:yaml.org,2002:float",
  format: "TIME",
  test: /^[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*$/,
  resolve: (str) => parseSexagesimal(str, false),
  stringify: stringifySexagesimal
};
var timestamp = {
  identify: (value) => value instanceof Date,
  default: true,
  tag: "tag:yaml.org,2002:timestamp",
  // If the time zone is omitted, the timestamp is assumed to be specified in UTC. The time part
  // may be omitted altogether, resulting in a date format. In such a case, the time part is
  // assumed to be 00:00:00Z (start of day, UTC).
  test: RegExp("^([0-9]{4})-([0-9]{1,2})-([0-9]{1,2})(?:(?:t|T|[ \\t]+)([0-9]{1,2}):([0-9]{1,2}):([0-9]{1,2}(\\.[0-9]+)?)(?:[ \\t]*(Z|[-+][012]?[0-9](?::[0-9]{2})?))?)?$"),
  resolve(str) {
    const match = str.match(timestamp.test);
    if (!match)
      throw new Error("!!timestamp expects a date, starting with yyyy-mm-dd");
    const [, year, month, day, hour, minute, second] = match.map(Number);
    const millisec = match[7] ? Number((match[7] + "00").substr(1, 3)) : 0;
    let date = Date.UTC(year, month - 1, day, hour || 0, minute || 0, second || 0, millisec);
    const tz = match[8];
    if (tz && tz !== "Z") {
      let d3 = parseSexagesimal(tz, false);
      if (Math.abs(d3) < 30)
        d3 *= 60;
      date -= 6e4 * d3;
    }
    return new Date(date);
  },
  stringify: ({ value }) => value?.toISOString().replace(/(T00:00:00)?\.000Z$/, "") ?? ""
};

// node_modules/yaml/browser/dist/schema/yaml-1.1/schema.js
var schema3 = [
  map,
  seq,
  string,
  nullTag,
  trueTag,
  falseTag,
  intBin,
  intOct2,
  int2,
  intHex2,
  floatNaN2,
  floatExp2,
  float2,
  binary,
  merge,
  omap,
  pairs,
  set,
  intTime,
  floatTime,
  timestamp
];

// node_modules/yaml/browser/dist/schema/tags.js
var schemas = /* @__PURE__ */ new Map([
  ["core", schema],
  ["failsafe", [map, seq, string]],
  ["json", schema2],
  ["yaml11", schema3],
  ["yaml-1.1", schema3]
]);
var tagsByName = {
  binary,
  bool: boolTag,
  float,
  floatExp,
  floatNaN,
  floatTime,
  int,
  intHex,
  intOct,
  intTime,
  map,
  merge,
  null: nullTag,
  omap,
  pairs,
  seq,
  set,
  timestamp
};
var coreKnownTags = {
  "tag:yaml.org,2002:binary": binary,
  "tag:yaml.org,2002:merge": merge,
  "tag:yaml.org,2002:omap": omap,
  "tag:yaml.org,2002:pairs": pairs,
  "tag:yaml.org,2002:set": set,
  "tag:yaml.org,2002:timestamp": timestamp
};
function getTags(customTags, schemaName, addMergeTag) {
  const schemaTags = schemas.get(schemaName);
  if (schemaTags && !customTags) {
    return addMergeTag && !schemaTags.includes(merge) ? schemaTags.concat(merge) : schemaTags.slice();
  }
  let tags = schemaTags;
  if (!tags) {
    if (Array.isArray(customTags))
      tags = [];
    else {
      const keys = Array.from(schemas.keys()).filter((key) => key !== "yaml11").map((key) => JSON.stringify(key)).join(", ");
      throw new Error(`Unknown schema "${schemaName}"; use one of ${keys} or define customTags array`);
    }
  }
  if (Array.isArray(customTags)) {
    for (const tag of customTags)
      tags = tags.concat(tag);
  } else if (typeof customTags === "function") {
    tags = customTags(tags.slice());
  }
  if (addMergeTag)
    tags = tags.concat(merge);
  return tags.reduce((tags2, tag) => {
    const tagObj = typeof tag === "string" ? tagsByName[tag] : tag;
    if (!tagObj) {
      const tagName = JSON.stringify(tag);
      const keys = Object.keys(tagsByName).map((key) => JSON.stringify(key)).join(", ");
      throw new Error(`Unknown custom tag ${tagName}; use one of ${keys}`);
    }
    if (!tags2.includes(tagObj))
      tags2.push(tagObj);
    return tags2;
  }, []);
}

// node_modules/yaml/browser/dist/schema/Schema.js
var sortMapEntriesByKey = (a3, b3) => a3.key < b3.key ? -1 : a3.key > b3.key ? 1 : 0;
var Schema = class _Schema {
  constructor({ compat, customTags, merge: merge2, resolveKnownTags, schema: schema4, sortMapEntries, toStringDefaults }) {
    this.compat = Array.isArray(compat) ? getTags(compat, "compat") : compat ? getTags(null, compat) : null;
    this.name = typeof schema4 === "string" && schema4 || "core";
    this.knownTags = resolveKnownTags ? coreKnownTags : {};
    this.tags = getTags(customTags, this.name, merge2);
    this.toStringOptions = toStringDefaults ?? null;
    Object.defineProperty(this, MAP, { value: map });
    Object.defineProperty(this, SCALAR, { value: string });
    Object.defineProperty(this, SEQ, { value: seq });
    this.sortMapEntries = typeof sortMapEntries === "function" ? sortMapEntries : sortMapEntries === true ? sortMapEntriesByKey : null;
  }
  clone() {
    const copy = Object.create(_Schema.prototype, Object.getOwnPropertyDescriptors(this));
    copy.tags = this.tags.slice();
    return copy;
  }
};

// node_modules/yaml/browser/dist/stringify/stringifyDocument.js
function stringifyDocument(doc, options) {
  const lines = [];
  let hasDirectives = options.directives === true;
  if (options.directives !== false && doc.directives) {
    const dir = doc.directives.toString(doc);
    if (dir) {
      lines.push(dir);
      hasDirectives = true;
    } else if (doc.directives.docStart)
      hasDirectives = true;
  }
  if (hasDirectives)
    lines.push("---");
  const ctx = createStringifyContext(doc, options);
  const { commentString } = ctx.options;
  if (doc.commentBefore) {
    if (lines.length !== 1)
      lines.unshift("");
    const cs = commentString(doc.commentBefore);
    lines.unshift(indentComment(cs, ""));
  }
  let chompKeep = false;
  let contentComment = null;
  if (doc.contents) {
    if (isNode(doc.contents)) {
      if (doc.contents.spaceBefore && hasDirectives)
        lines.push("");
      if (doc.contents.commentBefore) {
        const cs = commentString(doc.contents.commentBefore);
        lines.push(indentComment(cs, ""));
      }
      ctx.forceBlockIndent = !!doc.comment;
      contentComment = doc.contents.comment;
    }
    const onChompKeep = contentComment ? void 0 : () => chompKeep = true;
    let body = stringify(doc.contents, ctx, () => contentComment = null, onChompKeep);
    if (contentComment)
      body += lineComment(body, "", commentString(contentComment));
    if ((body[0] === "|" || body[0] === ">") && lines[lines.length - 1] === "---") {
      lines[lines.length - 1] = `--- ${body}`;
    } else
      lines.push(body);
  } else {
    lines.push(stringify(doc.contents, ctx));
  }
  if (doc.directives?.docEnd) {
    if (doc.comment) {
      const cs = commentString(doc.comment);
      if (cs.includes("\n")) {
        lines.push("...");
        lines.push(indentComment(cs, ""));
      } else {
        lines.push(`... ${cs}`);
      }
    } else {
      lines.push("...");
    }
  } else {
    let dc = doc.comment;
    if (dc && chompKeep)
      dc = dc.replace(/^\n+/, "");
    if (dc) {
      if ((!chompKeep || contentComment) && lines[lines.length - 1] !== "")
        lines.push("");
      lines.push(indentComment(commentString(dc), ""));
    }
  }
  return lines.join("\n") + "\n";
}

// node_modules/yaml/browser/dist/doc/Document.js
var Document2 = class _Document {
  constructor(value, replacer, options) {
    this.commentBefore = null;
    this.comment = null;
    this.errors = [];
    this.warnings = [];
    Object.defineProperty(this, NODE_TYPE, { value: DOC });
    let _replacer = null;
    if (typeof replacer === "function" || Array.isArray(replacer)) {
      _replacer = replacer;
    } else if (options === void 0 && replacer) {
      options = replacer;
      replacer = void 0;
    }
    const opt = Object.assign({
      intAsBigInt: false,
      keepSourceTokens: false,
      logLevel: "warn",
      prettyErrors: true,
      strict: true,
      stringKeys: false,
      uniqueKeys: true,
      version: "1.2"
    }, options);
    this.options = opt;
    let { version } = opt;
    if (options?._directives) {
      this.directives = options._directives.atDocument();
      if (this.directives.yaml.explicit)
        version = this.directives.yaml.version;
    } else
      this.directives = new Directives({ version });
    this.setSchema(version, options);
    this.contents = value === void 0 ? null : this.createNode(value, _replacer, options);
  }
  /**
   * Create a deep copy of this Document and its contents.
   *
   * Custom Node values that inherit from `Object` still refer to their original instances.
   */
  clone() {
    const copy = Object.create(_Document.prototype, {
      [NODE_TYPE]: { value: DOC }
    });
    copy.commentBefore = this.commentBefore;
    copy.comment = this.comment;
    copy.errors = this.errors.slice();
    copy.warnings = this.warnings.slice();
    copy.options = Object.assign({}, this.options);
    if (this.directives)
      copy.directives = this.directives.clone();
    copy.schema = this.schema.clone();
    copy.contents = isNode(this.contents) ? this.contents.clone(copy.schema) : this.contents;
    if (this.range)
      copy.range = this.range.slice();
    return copy;
  }
  /** Adds a value to the document. */
  add(value) {
    if (assertCollection(this.contents))
      this.contents.add(value);
  }
  /** Adds a value to the document. */
  addIn(path, value) {
    if (assertCollection(this.contents))
      this.contents.addIn(path, value);
  }
  /**
   * Create a new `Alias` node, ensuring that the target `node` has the required anchor.
   *
   * If `node` already has an anchor, `name` is ignored.
   * Otherwise, the `node.anchor` value will be set to `name`,
   * or if an anchor with that name is already present in the document,
   * `name` will be used as a prefix for a new unique anchor.
   * If `name` is undefined, the generated anchor will use 'a' as a prefix.
   */
  createAlias(node, name) {
    if (!node.anchor) {
      const prev = anchorNames(this);
      node.anchor = // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      !name || prev.has(name) ? findNewAnchor(name || "a", prev) : name;
    }
    return new Alias(node.anchor);
  }
  createNode(value, replacer, options) {
    let _replacer = void 0;
    if (typeof replacer === "function") {
      value = replacer.call({ "": value }, "", value);
      _replacer = replacer;
    } else if (Array.isArray(replacer)) {
      const keyToStr = (v2) => typeof v2 === "number" || v2 instanceof String || v2 instanceof Number;
      const asStr = replacer.filter(keyToStr).map(String);
      if (asStr.length > 0)
        replacer = replacer.concat(asStr);
      _replacer = replacer;
    } else if (options === void 0 && replacer) {
      options = replacer;
      replacer = void 0;
    }
    const { aliasDuplicateObjects, anchorPrefix, flow, keepUndefined, onTagObj, tag } = options ?? {};
    const { onAnchor, setAnchors, sourceObjects } = createNodeAnchors(
      this,
      // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      anchorPrefix || "a"
    );
    const ctx = {
      aliasDuplicateObjects: aliasDuplicateObjects ?? true,
      keepUndefined: keepUndefined ?? false,
      onAnchor,
      onTagObj,
      replacer: _replacer,
      schema: this.schema,
      sourceObjects
    };
    const node = createNode(value, tag, ctx);
    if (flow && isCollection(node))
      node.flow = true;
    setAnchors();
    return node;
  }
  /**
   * Convert a key and a value into a `Pair` using the current schema,
   * recursively wrapping all values as `Scalar` or `Collection` nodes.
   */
  createPair(key, value, options = {}) {
    const k2 = this.createNode(key, null, options);
    const v2 = this.createNode(value, null, options);
    return new Pair(k2, v2);
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  delete(key) {
    return assertCollection(this.contents) ? this.contents.delete(key) : false;
  }
  /**
   * Removes a value from the document.
   * @returns `true` if the item was found and removed.
   */
  deleteIn(path) {
    if (isEmptyPath(path)) {
      if (this.contents == null)
        return false;
      this.contents = null;
      return true;
    }
    return assertCollection(this.contents) ? this.contents.deleteIn(path) : false;
  }
  /**
   * Returns item at `key`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  get(key, keepScalar) {
    return isCollection(this.contents) ? this.contents.get(key, keepScalar) : void 0;
  }
  /**
   * Returns item at `path`, or `undefined` if not found. By default unwraps
   * scalar values from their surrounding node; to disable set `keepScalar` to
   * `true` (collections are always returned intact).
   */
  getIn(path, keepScalar) {
    if (isEmptyPath(path))
      return !keepScalar && isScalar(this.contents) ? this.contents.value : this.contents;
    return isCollection(this.contents) ? this.contents.getIn(path, keepScalar) : void 0;
  }
  /**
   * Checks if the document includes a value with the key `key`.
   */
  has(key) {
    return isCollection(this.contents) ? this.contents.has(key) : false;
  }
  /**
   * Checks if the document includes a value at `path`.
   */
  hasIn(path) {
    if (isEmptyPath(path))
      return this.contents !== void 0;
    return isCollection(this.contents) ? this.contents.hasIn(path) : false;
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  set(key, value) {
    if (this.contents == null) {
      this.contents = collectionFromPath(this.schema, [key], value);
    } else if (assertCollection(this.contents)) {
      this.contents.set(key, value);
    }
  }
  /**
   * Sets a value in this document. For `!!set`, `value` needs to be a
   * boolean to add/remove the item from the set.
   */
  setIn(path, value) {
    if (isEmptyPath(path)) {
      this.contents = value;
    } else if (this.contents == null) {
      this.contents = collectionFromPath(this.schema, Array.from(path), value);
    } else if (assertCollection(this.contents)) {
      this.contents.setIn(path, value);
    }
  }
  /**
   * Change the YAML version and schema used by the document.
   * A `null` version disables support for directives, explicit tags, anchors, and aliases.
   * It also requires the `schema` option to be given as a `Schema` instance value.
   *
   * Overrides all previously set schema options.
   */
  setSchema(version, options = {}) {
    if (typeof version === "number")
      version = String(version);
    let opt;
    switch (version) {
      case "1.1":
        if (this.directives)
          this.directives.yaml.version = "1.1";
        else
          this.directives = new Directives({ version: "1.1" });
        opt = { resolveKnownTags: false, schema: "yaml-1.1" };
        break;
      case "1.2":
      case "next":
        if (this.directives)
          this.directives.yaml.version = version;
        else
          this.directives = new Directives({ version });
        opt = { resolveKnownTags: true, schema: "core" };
        break;
      case null:
        if (this.directives)
          delete this.directives;
        opt = null;
        break;
      default: {
        const sv = JSON.stringify(version);
        throw new Error(`Expected '1.1', '1.2' or null as first argument, but found: ${sv}`);
      }
    }
    if (options.schema instanceof Object)
      this.schema = options.schema;
    else if (opt)
      this.schema = new Schema(Object.assign(opt, options));
    else
      throw new Error(`With a null YAML version, the { schema: Schema } option is required`);
  }
  // json & jsonArg are only used from toJSON()
  toJS({ json, jsonArg, mapAsMap, maxAliasCount, onAnchor, reviver } = {}) {
    const ctx = {
      anchors: /* @__PURE__ */ new Map(),
      doc: this,
      keep: !json,
      mapAsMap: mapAsMap === true,
      mapKeyWarned: false,
      maxAliasCount: typeof maxAliasCount === "number" ? maxAliasCount : 100
    };
    const res = toJS(this.contents, jsonArg ?? "", ctx);
    if (typeof onAnchor === "function")
      for (const { count, res: res2 } of ctx.anchors.values())
        onAnchor(res2, count);
    return typeof reviver === "function" ? applyReviver(reviver, { "": res }, "", res) : res;
  }
  /**
   * A JSON representation of the document `contents`.
   *
   * @param jsonArg Used by `JSON.stringify` to indicate the array index or
   *   property name.
   */
  toJSON(jsonArg, onAnchor) {
    return this.toJS({ json: true, jsonArg, mapAsMap: false, onAnchor });
  }
  /** A YAML representation of the document. */
  toString(options = {}) {
    if (this.errors.length > 0)
      throw new Error("Document with errors cannot be stringified");
    if ("indent" in options && (!Number.isInteger(options.indent) || Number(options.indent) <= 0)) {
      const s5 = JSON.stringify(options.indent);
      throw new Error(`"indent" option must be a positive integer, not ${s5}`);
    }
    return stringifyDocument(this, options);
  }
};
function assertCollection(contents) {
  if (isCollection(contents))
    return true;
  throw new Error("Expected a YAML collection as document contents");
}

// node_modules/yaml/browser/dist/errors.js
var YAMLError = class extends Error {
  constructor(name, pos, code, message) {
    super();
    this.name = name;
    this.code = code;
    this.message = message;
    this.pos = pos;
  }
};
var YAMLParseError = class extends YAMLError {
  constructor(pos, code, message) {
    super("YAMLParseError", pos, code, message);
  }
};
var YAMLWarning = class extends YAMLError {
  constructor(pos, code, message) {
    super("YAMLWarning", pos, code, message);
  }
};
var prettifyError = (src, lc) => (error) => {
  if (error.pos[0] === -1)
    return;
  error.linePos = error.pos.map((pos) => lc.linePos(pos));
  const { line, col } = error.linePos[0];
  error.message += ` at line ${line}, column ${col}`;
  let ci = col - 1;
  let lineStr = src.substring(lc.lineStarts[line - 1], lc.lineStarts[line]).replace(/[\n\r]+$/, "");
  if (ci >= 60 && lineStr.length > 80) {
    const trimStart = Math.min(ci - 39, lineStr.length - 79);
    lineStr = "\u2026" + lineStr.substring(trimStart);
    ci -= trimStart - 1;
  }
  if (lineStr.length > 80)
    lineStr = lineStr.substring(0, 79) + "\u2026";
  if (line > 1 && /^ *$/.test(lineStr.substring(0, ci))) {
    let prev = src.substring(lc.lineStarts[line - 2], lc.lineStarts[line - 1]);
    if (prev.length > 80)
      prev = prev.substring(0, 79) + "\u2026\n";
    lineStr = prev + lineStr;
  }
  if (/[^ ]/.test(lineStr)) {
    let count = 1;
    const end = error.linePos[1];
    if (end?.line === line && end.col > col) {
      count = Math.max(1, Math.min(end.col - col, 80 - ci));
    }
    const pointer = " ".repeat(ci) + "^".repeat(count);
    error.message += `:

${lineStr}
${pointer}
`;
  }
};

// node_modules/yaml/browser/dist/compose/resolve-props.js
function resolveProps(tokens, { flow, indicator, next, offset, onError, parentIndent, startOnNewline }) {
  let spaceBefore = false;
  let atNewline = startOnNewline;
  let hasSpace = startOnNewline;
  let comment = "";
  let commentSep = "";
  let hasNewline = false;
  let reqSpace = false;
  let tab = null;
  let anchor = null;
  let tag = null;
  let newlineAfterProp = null;
  let comma = null;
  let found = null;
  let start = null;
  for (const token of tokens) {
    if (reqSpace) {
      if (token.type !== "space" && token.type !== "newline" && token.type !== "comma")
        onError(token.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
      reqSpace = false;
    }
    if (tab) {
      if (atNewline && token.type !== "comment" && token.type !== "newline") {
        onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
      }
      tab = null;
    }
    switch (token.type) {
      case "space":
        if (!flow && (indicator !== "doc-start" || next?.type !== "flow-collection") && token.source.includes("	")) {
          tab = token;
        }
        hasSpace = true;
        break;
      case "comment": {
        if (!hasSpace)
          onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
        const cb = token.source.substring(1) || " ";
        if (!comment)
          comment = cb;
        else
          comment += commentSep + cb;
        commentSep = "";
        atNewline = false;
        break;
      }
      case "newline":
        if (atNewline) {
          if (comment)
            comment += token.source;
          else if (!found || indicator !== "seq-item-ind")
            spaceBefore = true;
        } else
          commentSep += token.source;
        atNewline = true;
        hasNewline = true;
        if (anchor || tag)
          newlineAfterProp = token;
        hasSpace = true;
        break;
      case "anchor":
        if (anchor)
          onError(token, "MULTIPLE_ANCHORS", "A node can have at most one anchor");
        if (token.source.endsWith(":"))
          onError(token.offset + token.source.length - 1, "BAD_ALIAS", "Anchor ending in : is ambiguous", true);
        anchor = token;
        start ?? (start = token.offset);
        atNewline = false;
        hasSpace = false;
        reqSpace = true;
        break;
      case "tag": {
        if (tag)
          onError(token, "MULTIPLE_TAGS", "A node can have at most one tag");
        tag = token;
        start ?? (start = token.offset);
        atNewline = false;
        hasSpace = false;
        reqSpace = true;
        break;
      }
      case indicator:
        if (anchor || tag)
          onError(token, "BAD_PROP_ORDER", `Anchors and tags must be after the ${token.source} indicator`);
        if (found)
          onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.source} in ${flow ?? "collection"}`);
        found = token;
        atNewline = indicator === "seq-item-ind" || indicator === "explicit-key-ind";
        hasSpace = false;
        break;
      case "comma":
        if (flow) {
          if (comma)
            onError(token, "UNEXPECTED_TOKEN", `Unexpected , in ${flow}`);
          comma = token;
          atNewline = false;
          hasSpace = false;
          break;
        }
      // else fallthrough
      default:
        onError(token, "UNEXPECTED_TOKEN", `Unexpected ${token.type} token`);
        atNewline = false;
        hasSpace = false;
    }
  }
  const last = tokens[tokens.length - 1];
  const end = last ? last.offset + last.source.length : offset;
  if (reqSpace && next && next.type !== "space" && next.type !== "newline" && next.type !== "comma" && (next.type !== "scalar" || next.source !== "")) {
    onError(next.offset, "MISSING_CHAR", "Tags and anchors must be separated from the next token by white space");
  }
  if (tab && (atNewline && tab.indent <= parentIndent || next?.type === "block-map" || next?.type === "block-seq"))
    onError(tab, "TAB_AS_INDENT", "Tabs are not allowed as indentation");
  return {
    comma,
    found,
    spaceBefore,
    comment,
    hasNewline,
    anchor,
    tag,
    newlineAfterProp,
    end,
    start: start ?? end
  };
}

// node_modules/yaml/browser/dist/compose/util-contains-newline.js
function containsNewline(key) {
  if (!key)
    return null;
  switch (key.type) {
    case "alias":
    case "scalar":
    case "double-quoted-scalar":
    case "single-quoted-scalar":
      if (key.source.includes("\n"))
        return true;
      if (key.end) {
        for (const st of key.end)
          if (st.type === "newline")
            return true;
      }
      return false;
    case "flow-collection":
      for (const it of key.items) {
        for (const st of it.start)
          if (st.type === "newline")
            return true;
        if (it.sep) {
          for (const st of it.sep)
            if (st.type === "newline")
              return true;
        }
        if (containsNewline(it.key) || containsNewline(it.value))
          return true;
      }
      return false;
    default:
      return true;
  }
}

// node_modules/yaml/browser/dist/compose/util-flow-indent-check.js
function flowIndentCheck(indent, fc, onError) {
  if (fc?.type === "flow-collection") {
    const end = fc.end[0];
    if (end.indent === indent && (end.source === "]" || end.source === "}") && containsNewline(fc)) {
      const msg = "Flow end indicator should be more indented than parent";
      onError(end, "BAD_INDENT", msg, true);
    }
  }
}

// node_modules/yaml/browser/dist/compose/util-map-includes.js
function mapIncludes(ctx, items, search) {
  const { uniqueKeys } = ctx.options;
  if (uniqueKeys === false)
    return false;
  const isEqual = typeof uniqueKeys === "function" ? uniqueKeys : (a3, b3) => a3 === b3 || isScalar(a3) && isScalar(b3) && a3.value === b3.value;
  return items.some((pair) => isEqual(pair.key, search));
}

// node_modules/yaml/browser/dist/compose/resolve-block-map.js
var startColMsg = "All mapping items must start at the same column";
function resolveBlockMap({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, bm, onError, tag) {
  const NodeClass = tag?.nodeClass ?? YAMLMap;
  const map2 = new NodeClass(ctx.schema);
  if (ctx.atRoot)
    ctx.atRoot = false;
  let offset = bm.offset;
  let commentEnd = null;
  for (const collItem of bm.items) {
    const { start, key, sep, value } = collItem;
    const keyProps = resolveProps(start, {
      indicator: "explicit-key-ind",
      next: key ?? sep?.[0],
      offset,
      onError,
      parentIndent: bm.indent,
      startOnNewline: true
    });
    const implicitKey = !keyProps.found;
    if (implicitKey) {
      if (key) {
        if (key.type === "block-seq")
          onError(offset, "BLOCK_AS_IMPLICIT_KEY", "A block sequence may not be used as an implicit map key");
        else if ("indent" in key && key.indent !== bm.indent)
          onError(offset, "BAD_INDENT", startColMsg);
      }
      if (!keyProps.anchor && !keyProps.tag && !sep) {
        commentEnd = keyProps.end;
        if (keyProps.comment) {
          if (map2.comment)
            map2.comment += "\n" + keyProps.comment;
          else
            map2.comment = keyProps.comment;
        }
        continue;
      }
      if (keyProps.newlineAfterProp || containsNewline(key)) {
        onError(key ?? start[start.length - 1], "MULTILINE_IMPLICIT_KEY", "Implicit keys need to be on a single line");
      }
    } else if (keyProps.found?.indent !== bm.indent) {
      onError(offset, "BAD_INDENT", startColMsg);
    }
    ctx.atKey = true;
    const keyStart = keyProps.end;
    const keyNode = key ? composeNode2(ctx, key, keyProps, onError) : composeEmptyNode2(ctx, keyStart, start, null, keyProps, onError);
    if (ctx.schema.compat)
      flowIndentCheck(bm.indent, key, onError);
    ctx.atKey = false;
    if (mapIncludes(ctx, map2.items, keyNode))
      onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
    const valueProps = resolveProps(sep ?? [], {
      indicator: "map-value-ind",
      next: value,
      offset: keyNode.range[2],
      onError,
      parentIndent: bm.indent,
      startOnNewline: !key || key.type === "block-scalar"
    });
    offset = valueProps.end;
    if (valueProps.found) {
      if (implicitKey) {
        if (value?.type === "block-map" && !valueProps.hasNewline)
          onError(offset, "BLOCK_AS_IMPLICIT_KEY", "Nested mappings are not allowed in compact mappings");
        if (ctx.options.strict && keyProps.start < valueProps.found.offset - 1024)
          onError(keyNode.range, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit block mapping key");
      }
      const valueNode = value ? composeNode2(ctx, value, valueProps, onError) : composeEmptyNode2(ctx, offset, sep, null, valueProps, onError);
      if (ctx.schema.compat)
        flowIndentCheck(bm.indent, value, onError);
      offset = valueNode.range[2];
      const pair = new Pair(keyNode, valueNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      map2.items.push(pair);
    } else {
      if (implicitKey)
        onError(keyNode.range, "MISSING_CHAR", "Implicit map keys need to be followed by map values");
      if (valueProps.comment) {
        if (keyNode.comment)
          keyNode.comment += "\n" + valueProps.comment;
        else
          keyNode.comment = valueProps.comment;
      }
      const pair = new Pair(keyNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      map2.items.push(pair);
    }
  }
  if (commentEnd && commentEnd < offset)
    onError(commentEnd, "IMPOSSIBLE", "Map comment with trailing content");
  map2.range = [bm.offset, offset, commentEnd ?? offset];
  return map2;
}

// node_modules/yaml/browser/dist/compose/resolve-block-seq.js
function resolveBlockSeq({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, bs, onError, tag) {
  const NodeClass = tag?.nodeClass ?? YAMLSeq;
  const seq2 = new NodeClass(ctx.schema);
  if (ctx.atRoot)
    ctx.atRoot = false;
  if (ctx.atKey)
    ctx.atKey = false;
  let offset = bs.offset;
  let commentEnd = null;
  for (const { start, value } of bs.items) {
    const props = resolveProps(start, {
      indicator: "seq-item-ind",
      next: value,
      offset,
      onError,
      parentIndent: bs.indent,
      startOnNewline: true
    });
    if (!props.found) {
      if (props.anchor || props.tag || value) {
        if (value?.type === "block-seq")
          onError(props.end, "BAD_INDENT", "All sequence items must start at the same column");
        else
          onError(offset, "MISSING_CHAR", "Sequence item without - indicator");
      } else {
        commentEnd = props.end;
        if (props.comment)
          seq2.comment = props.comment;
        continue;
      }
    }
    const node = value ? composeNode2(ctx, value, props, onError) : composeEmptyNode2(ctx, props.end, start, null, props, onError);
    if (ctx.schema.compat)
      flowIndentCheck(bs.indent, value, onError);
    offset = node.range[2];
    seq2.items.push(node);
  }
  seq2.range = [bs.offset, offset, commentEnd ?? offset];
  return seq2;
}

// node_modules/yaml/browser/dist/compose/resolve-end.js
function resolveEnd(end, offset, reqSpace, onError) {
  let comment = "";
  if (end) {
    let hasSpace = false;
    let sep = "";
    for (const token of end) {
      const { source, type } = token;
      switch (type) {
        case "space":
          hasSpace = true;
          break;
        case "comment": {
          if (reqSpace && !hasSpace)
            onError(token, "MISSING_CHAR", "Comments must be separated from other tokens by white space characters");
          const cb = source.substring(1) || " ";
          if (!comment)
            comment = cb;
          else
            comment += sep + cb;
          sep = "";
          break;
        }
        case "newline":
          if (comment)
            sep += source;
          hasSpace = true;
          break;
        default:
          onError(token, "UNEXPECTED_TOKEN", `Unexpected ${type} at node end`);
      }
      offset += source.length;
    }
  }
  return { comment, offset };
}

// node_modules/yaml/browser/dist/compose/resolve-flow-collection.js
var blockMsg = "Block collections are not allowed within flow collections";
var isBlock = (token) => token && (token.type === "block-map" || token.type === "block-seq");
function resolveFlowCollection({ composeNode: composeNode2, composeEmptyNode: composeEmptyNode2 }, ctx, fc, onError, tag) {
  const isMap2 = fc.start.source === "{";
  const fcName = isMap2 ? "flow map" : "flow sequence";
  const NodeClass = tag?.nodeClass ?? (isMap2 ? YAMLMap : YAMLSeq);
  const coll = new NodeClass(ctx.schema);
  coll.flow = true;
  const atRoot = ctx.atRoot;
  if (atRoot)
    ctx.atRoot = false;
  if (ctx.atKey)
    ctx.atKey = false;
  let offset = fc.offset + fc.start.source.length;
  for (let i6 = 0; i6 < fc.items.length; ++i6) {
    const collItem = fc.items[i6];
    const { start, key, sep, value } = collItem;
    const props = resolveProps(start, {
      flow: fcName,
      indicator: "explicit-key-ind",
      next: key ?? sep?.[0],
      offset,
      onError,
      parentIndent: fc.indent,
      startOnNewline: false
    });
    if (!props.found) {
      if (!props.anchor && !props.tag && !sep && !value) {
        if (i6 === 0 && props.comma)
          onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
        else if (i6 < fc.items.length - 1)
          onError(props.start, "UNEXPECTED_TOKEN", `Unexpected empty item in ${fcName}`);
        if (props.comment) {
          if (coll.comment)
            coll.comment += "\n" + props.comment;
          else
            coll.comment = props.comment;
        }
        offset = props.end;
        continue;
      }
      if (!isMap2 && ctx.options.strict && containsNewline(key))
        onError(
          key,
          // checked by containsNewline()
          "MULTILINE_IMPLICIT_KEY",
          "Implicit keys of flow sequence pairs need to be on a single line"
        );
    }
    if (i6 === 0) {
      if (props.comma)
        onError(props.comma, "UNEXPECTED_TOKEN", `Unexpected , in ${fcName}`);
    } else {
      if (!props.comma)
        onError(props.start, "MISSING_CHAR", `Missing , between ${fcName} items`);
      if (props.comment) {
        let prevItemComment = "";
        loop: for (const st of start) {
          switch (st.type) {
            case "comma":
            case "space":
              break;
            case "comment":
              prevItemComment = st.source.substring(1);
              break loop;
            default:
              break loop;
          }
        }
        if (prevItemComment) {
          let prev = coll.items[coll.items.length - 1];
          if (isPair(prev))
            prev = prev.value ?? prev.key;
          if (prev.comment)
            prev.comment += "\n" + prevItemComment;
          else
            prev.comment = prevItemComment;
          props.comment = props.comment.substring(prevItemComment.length + 1);
        }
      }
    }
    if (!isMap2 && !sep && !props.found) {
      const valueNode = value ? composeNode2(ctx, value, props, onError) : composeEmptyNode2(ctx, props.end, sep, null, props, onError);
      coll.items.push(valueNode);
      offset = valueNode.range[2];
      if (isBlock(value))
        onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
    } else {
      ctx.atKey = true;
      const keyStart = props.end;
      const keyNode = key ? composeNode2(ctx, key, props, onError) : composeEmptyNode2(ctx, keyStart, start, null, props, onError);
      if (isBlock(key))
        onError(keyNode.range, "BLOCK_IN_FLOW", blockMsg);
      ctx.atKey = false;
      const valueProps = resolveProps(sep ?? [], {
        flow: fcName,
        indicator: "map-value-ind",
        next: value,
        offset: keyNode.range[2],
        onError,
        parentIndent: fc.indent,
        startOnNewline: false
      });
      if (valueProps.found) {
        if (!isMap2 && !props.found && ctx.options.strict) {
          if (sep)
            for (const st of sep) {
              if (st === valueProps.found)
                break;
              if (st.type === "newline") {
                onError(st, "MULTILINE_IMPLICIT_KEY", "Implicit keys of flow sequence pairs need to be on a single line");
                break;
              }
            }
          if (props.start < valueProps.found.offset - 1024)
            onError(valueProps.found, "KEY_OVER_1024_CHARS", "The : indicator must be at most 1024 chars after the start of an implicit flow sequence key");
        }
      } else if (value) {
        if ("source" in value && value.source?.[0] === ":")
          onError(value, "MISSING_CHAR", `Missing space after : in ${fcName}`);
        else
          onError(valueProps.start, "MISSING_CHAR", `Missing , or : between ${fcName} items`);
      }
      const valueNode = value ? composeNode2(ctx, value, valueProps, onError) : valueProps.found ? composeEmptyNode2(ctx, valueProps.end, sep, null, valueProps, onError) : null;
      if (valueNode) {
        if (isBlock(value))
          onError(valueNode.range, "BLOCK_IN_FLOW", blockMsg);
      } else if (valueProps.comment) {
        if (keyNode.comment)
          keyNode.comment += "\n" + valueProps.comment;
        else
          keyNode.comment = valueProps.comment;
      }
      const pair = new Pair(keyNode, valueNode);
      if (ctx.options.keepSourceTokens)
        pair.srcToken = collItem;
      if (isMap2) {
        const map2 = coll;
        if (mapIncludes(ctx, map2.items, keyNode))
          onError(keyStart, "DUPLICATE_KEY", "Map keys must be unique");
        map2.items.push(pair);
      } else {
        const map2 = new YAMLMap(ctx.schema);
        map2.flow = true;
        map2.items.push(pair);
        const endRange = (valueNode ?? keyNode).range;
        map2.range = [keyNode.range[0], endRange[1], endRange[2]];
        coll.items.push(map2);
      }
      offset = valueNode ? valueNode.range[2] : valueProps.end;
    }
  }
  const expectedEnd = isMap2 ? "}" : "]";
  const [ce, ...ee] = fc.end;
  let cePos = offset;
  if (ce?.source === expectedEnd)
    cePos = ce.offset + ce.source.length;
  else {
    const name = fcName[0].toUpperCase() + fcName.substring(1);
    const msg = atRoot ? `${name} must end with a ${expectedEnd}` : `${name} in block collection must be sufficiently indented and end with a ${expectedEnd}`;
    onError(offset, atRoot ? "MISSING_CHAR" : "BAD_INDENT", msg);
    if (ce && ce.source.length !== 1)
      ee.unshift(ce);
  }
  if (ee.length > 0) {
    const end = resolveEnd(ee, cePos, ctx.options.strict, onError);
    if (end.comment) {
      if (coll.comment)
        coll.comment += "\n" + end.comment;
      else
        coll.comment = end.comment;
    }
    coll.range = [fc.offset, cePos, end.offset];
  } else {
    coll.range = [fc.offset, cePos, cePos];
  }
  return coll;
}

// node_modules/yaml/browser/dist/compose/compose-collection.js
function resolveCollection(CN2, ctx, token, onError, tagName, tag) {
  const coll = token.type === "block-map" ? resolveBlockMap(CN2, ctx, token, onError, tag) : token.type === "block-seq" ? resolveBlockSeq(CN2, ctx, token, onError, tag) : resolveFlowCollection(CN2, ctx, token, onError, tag);
  const Coll = coll.constructor;
  if (tagName === "!" || tagName === Coll.tagName) {
    coll.tag = Coll.tagName;
    return coll;
  }
  if (tagName)
    coll.tag = tagName;
  return coll;
}
function composeCollection(CN2, ctx, token, props, onError) {
  const tagToken = props.tag;
  const tagName = !tagToken ? null : ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg));
  if (token.type === "block-seq") {
    const { anchor, newlineAfterProp: nl } = props;
    const lastProp = anchor && tagToken ? anchor.offset > tagToken.offset ? anchor : tagToken : anchor ?? tagToken;
    if (lastProp && (!nl || nl.offset < lastProp.offset)) {
      const message = "Missing newline after block sequence props";
      onError(lastProp, "MISSING_CHAR", message);
    }
  }
  const expType = token.type === "block-map" ? "map" : token.type === "block-seq" ? "seq" : token.start.source === "{" ? "map" : "seq";
  if (!tagToken || !tagName || tagName === "!" || tagName === YAMLMap.tagName && expType === "map" || tagName === YAMLSeq.tagName && expType === "seq") {
    return resolveCollection(CN2, ctx, token, onError, tagName);
  }
  let tag = ctx.schema.tags.find((t5) => t5.tag === tagName && t5.collection === expType);
  if (!tag) {
    const kt = ctx.schema.knownTags[tagName];
    if (kt?.collection === expType) {
      ctx.schema.tags.push(Object.assign({}, kt, { default: false }));
      tag = kt;
    } else {
      if (kt) {
        onError(tagToken, "BAD_COLLECTION_TYPE", `${kt.tag} used for ${expType} collection, but expects ${kt.collection ?? "scalar"}`, true);
      } else {
        onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, true);
      }
      return resolveCollection(CN2, ctx, token, onError, tagName);
    }
  }
  const coll = resolveCollection(CN2, ctx, token, onError, tagName, tag);
  const res = tag.resolve?.(coll, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg), ctx.options) ?? coll;
  const node = isNode(res) ? res : new Scalar(res);
  node.range = coll.range;
  node.tag = tagName;
  if (tag?.format)
    node.format = tag.format;
  return node;
}

// node_modules/yaml/browser/dist/compose/resolve-block-scalar.js
function resolveBlockScalar(ctx, scalar, onError) {
  const start = scalar.offset;
  const header = parseBlockScalarHeader(scalar, ctx.options.strict, onError);
  if (!header)
    return { value: "", type: null, comment: "", range: [start, start, start] };
  const type = header.mode === ">" ? Scalar.BLOCK_FOLDED : Scalar.BLOCK_LITERAL;
  const lines = scalar.source ? splitLines(scalar.source) : [];
  let chompStart = lines.length;
  for (let i6 = lines.length - 1; i6 >= 0; --i6) {
    const content = lines[i6][1];
    if (content === "" || content === "\r")
      chompStart = i6;
    else
      break;
  }
  if (chompStart === 0) {
    const value2 = header.chomp === "+" && lines.length > 0 ? "\n".repeat(Math.max(1, lines.length - 1)) : "";
    let end2 = start + header.length;
    if (scalar.source)
      end2 += scalar.source.length;
    return { value: value2, type, comment: header.comment, range: [start, end2, end2] };
  }
  let trimIndent = scalar.indent + header.indent;
  let offset = scalar.offset + header.length;
  let contentStart = 0;
  for (let i6 = 0; i6 < chompStart; ++i6) {
    const [indent, content] = lines[i6];
    if (content === "" || content === "\r") {
      if (header.indent === 0 && indent.length > trimIndent)
        trimIndent = indent.length;
    } else {
      if (indent.length < trimIndent) {
        const message = "Block scalars with more-indented leading empty lines must use an explicit indentation indicator";
        onError(offset + indent.length, "MISSING_CHAR", message);
      }
      if (header.indent === 0)
        trimIndent = indent.length;
      contentStart = i6;
      if (trimIndent === 0 && !ctx.atRoot) {
        const message = "Block scalar values in collections must be indented";
        onError(offset, "BAD_INDENT", message);
      }
      break;
    }
    offset += indent.length + content.length + 1;
  }
  for (let i6 = lines.length - 1; i6 >= chompStart; --i6) {
    if (lines[i6][0].length > trimIndent)
      chompStart = i6 + 1;
  }
  let value = "";
  let sep = "";
  let prevMoreIndented = false;
  for (let i6 = 0; i6 < contentStart; ++i6)
    value += lines[i6][0].slice(trimIndent) + "\n";
  for (let i6 = contentStart; i6 < chompStart; ++i6) {
    let [indent, content] = lines[i6];
    offset += indent.length + content.length + 1;
    const crlf = content[content.length - 1] === "\r";
    if (crlf)
      content = content.slice(0, -1);
    if (content && indent.length < trimIndent) {
      const src = header.indent ? "explicit indentation indicator" : "first line";
      const message = `Block scalar lines must not be less indented than their ${src}`;
      onError(offset - content.length - (crlf ? 2 : 1), "BAD_INDENT", message);
      indent = "";
    }
    if (type === Scalar.BLOCK_LITERAL) {
      value += sep + indent.slice(trimIndent) + content;
      sep = "\n";
    } else if (indent.length > trimIndent || content[0] === "	") {
      if (sep === " ")
        sep = "\n";
      else if (!prevMoreIndented && sep === "\n")
        sep = "\n\n";
      value += sep + indent.slice(trimIndent) + content;
      sep = "\n";
      prevMoreIndented = true;
    } else if (content === "") {
      if (sep === "\n")
        value += "\n";
      else
        sep = "\n";
    } else {
      value += sep + content;
      sep = " ";
      prevMoreIndented = false;
    }
  }
  switch (header.chomp) {
    case "-":
      break;
    case "+":
      for (let i6 = chompStart; i6 < lines.length; ++i6)
        value += "\n" + lines[i6][0].slice(trimIndent);
      if (value[value.length - 1] !== "\n")
        value += "\n";
      break;
    default:
      value += "\n";
  }
  const end = start + header.length + scalar.source.length;
  return { value, type, comment: header.comment, range: [start, end, end] };
}
function parseBlockScalarHeader({ offset, props }, strict, onError) {
  if (props[0].type !== "block-scalar-header") {
    onError(props[0], "IMPOSSIBLE", "Block scalar header not found");
    return null;
  }
  const { source } = props[0];
  const mode = source[0];
  let indent = 0;
  let chomp = "";
  let error = -1;
  for (let i6 = 1; i6 < source.length; ++i6) {
    const ch = source[i6];
    if (!chomp && (ch === "-" || ch === "+"))
      chomp = ch;
    else {
      const n6 = Number(ch);
      if (!indent && n6)
        indent = n6;
      else if (error === -1)
        error = offset + i6;
    }
  }
  if (error !== -1)
    onError(error, "UNEXPECTED_TOKEN", `Block scalar header includes extra characters: ${source}`);
  let hasSpace = false;
  let comment = "";
  let length = source.length;
  for (let i6 = 1; i6 < props.length; ++i6) {
    const token = props[i6];
    switch (token.type) {
      case "space":
        hasSpace = true;
      // fallthrough
      case "newline":
        length += token.source.length;
        break;
      case "comment":
        if (strict && !hasSpace) {
          const message = "Comments must be separated from other tokens by white space characters";
          onError(token, "MISSING_CHAR", message);
        }
        length += token.source.length;
        comment = token.source.substring(1);
        break;
      case "error":
        onError(token, "UNEXPECTED_TOKEN", token.message);
        length += token.source.length;
        break;
      /* istanbul ignore next should not happen */
      default: {
        const message = `Unexpected token in block scalar header: ${token.type}`;
        onError(token, "UNEXPECTED_TOKEN", message);
        const ts = token.source;
        if (ts && typeof ts === "string")
          length += ts.length;
      }
    }
  }
  return { mode, indent, chomp, comment, length };
}
function splitLines(source) {
  const split = source.split(/\n( *)/);
  const first = split[0];
  const m2 = first.match(/^( *)/);
  const line0 = m2?.[1] ? [m2[1], first.slice(m2[1].length)] : ["", first];
  const lines = [line0];
  for (let i6 = 1; i6 < split.length; i6 += 2)
    lines.push([split[i6], split[i6 + 1]]);
  return lines;
}

// node_modules/yaml/browser/dist/compose/resolve-flow-scalar.js
function resolveFlowScalar(scalar, strict, onError) {
  const { offset, type, source, end } = scalar;
  let _type;
  let value;
  const _onError = (rel, code, msg) => onError(offset + rel, code, msg);
  switch (type) {
    case "scalar":
      _type = Scalar.PLAIN;
      value = plainValue(source, _onError);
      break;
    case "single-quoted-scalar":
      _type = Scalar.QUOTE_SINGLE;
      value = singleQuotedValue(source, _onError);
      break;
    case "double-quoted-scalar":
      _type = Scalar.QUOTE_DOUBLE;
      value = doubleQuotedValue(source, _onError);
      break;
    /* istanbul ignore next should not happen */
    default:
      onError(scalar, "UNEXPECTED_TOKEN", `Expected a flow scalar value, but found: ${type}`);
      return {
        value: "",
        type: null,
        comment: "",
        range: [offset, offset + source.length, offset + source.length]
      };
  }
  const valueEnd = offset + source.length;
  const re = resolveEnd(end, valueEnd, strict, onError);
  return {
    value,
    type: _type,
    comment: re.comment,
    range: [offset, valueEnd, re.offset]
  };
}
function plainValue(source, onError) {
  let badChar = "";
  switch (source[0]) {
    /* istanbul ignore next should not happen */
    case "	":
      badChar = "a tab character";
      break;
    case ",":
      badChar = "flow indicator character ,";
      break;
    case "%":
      badChar = "directive indicator character %";
      break;
    case "|":
    case ">": {
      badChar = `block scalar indicator ${source[0]}`;
      break;
    }
    case "@":
    case "`": {
      badChar = `reserved character ${source[0]}`;
      break;
    }
  }
  if (badChar)
    onError(0, "BAD_SCALAR_START", `Plain value cannot start with ${badChar}`);
  return unfoldLines(source);
}
function singleQuotedValue(source, onError) {
  if (source[source.length - 1] !== "'" || source.length === 1)
    onError(source.length, "MISSING_CHAR", "Missing closing 'quote");
  return unfoldLines(source.slice(1, -1)).replace(/''/g, "'");
}
function unfoldLines(source) {
  const line = /(.*?)\r?\n/sy;
  let match = line.exec(source);
  if (!match)
    return source;
  let trimEnd, trimBoth;
  try {
    trimEnd = new RegExp("(?<![ 	])[ 	]+$");
    trimBoth = new RegExp("^[ 	]+|(?<![ 	])[ 	]+$", "g");
  } catch {
    trimEnd = /[ \t]+$/;
    trimBoth = /^[ \t]+|[ \t]+$/g;
  }
  let res = match[1].replace(trimEnd, "");
  let sep = " ";
  let pos = line.lastIndex;
  while (match = line.exec(source)) {
    const lm = match[1].replace(trimBoth, "");
    if (lm === "") {
      if (sep === "\n")
        res += sep;
      else
        sep = "\n";
    } else {
      res += sep + lm;
      sep = " ";
    }
    pos = line.lastIndex;
  }
  const last = /[ \t]*(.*)/sy;
  last.lastIndex = pos;
  match = last.exec(source);
  return res + sep + (match?.[1] ?? "");
}
function doubleQuotedValue(source, onError) {
  let res = "";
  for (let i6 = 1; i6 < source.length - 1; ++i6) {
    const ch = source[i6];
    if (ch === "\r" && source[i6 + 1] === "\n")
      continue;
    if (ch === "\n") {
      const { fold, offset } = foldNewline(source, i6);
      res += fold;
      i6 = offset;
    } else if (ch === "\\") {
      let next = source[++i6];
      const cc = escapeCodes[next];
      if (cc)
        res += cc;
      else if (next === "\n") {
        next = source[i6 + 1];
        while (next === " " || next === "	")
          next = source[++i6 + 1];
      } else if (next === "\r" && source[i6 + 1] === "\n") {
        next = source[++i6 + 1];
        while (next === " " || next === "	")
          next = source[++i6 + 1];
      } else if (next === "x" || next === "u" || next === "U") {
        const length = next === "x" ? 2 : next === "u" ? 4 : 8;
        res += parseCharCode(source, i6 + 1, length, onError);
        i6 += length;
      } else {
        const raw = source.substr(i6 - 1, 2);
        onError(i6 - 1, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
        res += raw;
      }
    } else if (ch === " " || ch === "	") {
      const wsStart = i6;
      let next = source[i6 + 1];
      while (next === " " || next === "	")
        next = source[++i6 + 1];
      if (next !== "\n" && !(next === "\r" && source[i6 + 2] === "\n"))
        res += i6 > wsStart ? source.slice(wsStart, i6 + 1) : ch;
    } else {
      res += ch;
    }
  }
  if (source[source.length - 1] !== '"' || source.length === 1)
    onError(source.length, "MISSING_CHAR", 'Missing closing "quote');
  return res;
}
function foldNewline(source, offset) {
  let fold = "";
  let ch = source[offset + 1];
  while (ch === " " || ch === "	" || ch === "\n" || ch === "\r") {
    if (ch === "\r" && source[offset + 2] !== "\n")
      break;
    if (ch === "\n")
      fold += "\n";
    offset += 1;
    ch = source[offset + 1];
  }
  if (!fold)
    fold = " ";
  return { fold, offset };
}
var escapeCodes = {
  "0": "\0",
  // null character
  a: "\x07",
  // bell character
  b: "\b",
  // backspace
  e: "\x1B",
  // escape character
  f: "\f",
  // form feed
  n: "\n",
  // line feed
  r: "\r",
  // carriage return
  t: "	",
  // horizontal tab
  v: "\v",
  // vertical tab
  N: "\x85",
  // Unicode next line
  _: "\xA0",
  // Unicode non-breaking space
  L: "\u2028",
  // Unicode line separator
  P: "\u2029",
  // Unicode paragraph separator
  " ": " ",
  '"': '"',
  "/": "/",
  "\\": "\\",
  "	": "	"
};
function parseCharCode(source, offset, length, onError) {
  const cc = source.substr(offset, length);
  const ok = cc.length === length && /^[0-9a-fA-F]+$/.test(cc);
  const code = ok ? parseInt(cc, 16) : NaN;
  try {
    return String.fromCodePoint(code);
  } catch {
    const raw = source.substr(offset - 2, length + 2);
    onError(offset - 2, "BAD_DQ_ESCAPE", `Invalid escape sequence ${raw}`);
    return raw;
  }
}

// node_modules/yaml/browser/dist/compose/compose-scalar.js
function composeScalar(ctx, token, tagToken, onError) {
  const { value, type, comment, range } = token.type === "block-scalar" ? resolveBlockScalar(ctx, token, onError) : resolveFlowScalar(token, ctx.options.strict, onError);
  const tagName = tagToken ? ctx.directives.tagName(tagToken.source, (msg) => onError(tagToken, "TAG_RESOLVE_FAILED", msg)) : null;
  let tag;
  if (ctx.options.stringKeys && ctx.atKey) {
    tag = ctx.schema[SCALAR];
  } else if (tagName)
    tag = findScalarTagByName(ctx.schema, value, tagName, tagToken, onError);
  else if (token.type === "scalar")
    tag = findScalarTagByTest(ctx, value, token, onError);
  else
    tag = ctx.schema[SCALAR];
  let scalar;
  try {
    const res = tag.resolve(value, (msg) => onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg), ctx.options);
    scalar = isScalar(res) ? res : new Scalar(res);
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    onError(tagToken ?? token, "TAG_RESOLVE_FAILED", msg);
    scalar = new Scalar(value);
  }
  scalar.range = range;
  scalar.source = value;
  if (type)
    scalar.type = type;
  if (tagName)
    scalar.tag = tagName;
  if (tag.format)
    scalar.format = tag.format;
  if (comment)
    scalar.comment = comment;
  return scalar;
}
function findScalarTagByName(schema4, value, tagName, tagToken, onError) {
  if (tagName === "!")
    return schema4[SCALAR];
  const matchWithTest = [];
  for (const tag of schema4.tags) {
    if (!tag.collection && tag.tag === tagName) {
      if (tag.default && tag.test)
        matchWithTest.push(tag);
      else
        return tag;
    }
  }
  for (const tag of matchWithTest)
    if (tag.test?.test(value))
      return tag;
  const kt = schema4.knownTags[tagName];
  if (kt && !kt.collection) {
    schema4.tags.push(Object.assign({}, kt, { default: false, test: void 0 }));
    return kt;
  }
  onError(tagToken, "TAG_RESOLVE_FAILED", `Unresolved tag: ${tagName}`, tagName !== "tag:yaml.org,2002:str");
  return schema4[SCALAR];
}
function findScalarTagByTest({ atKey, directives, schema: schema4 }, value, token, onError) {
  const tag = schema4.tags.find((tag2) => (tag2.default === true || atKey && tag2.default === "key") && tag2.test?.test(value)) || schema4[SCALAR];
  if (schema4.compat) {
    const compat = schema4.compat.find((tag2) => tag2.default && tag2.test?.test(value)) ?? schema4[SCALAR];
    if (tag.tag !== compat.tag) {
      const ts = directives.tagString(tag.tag);
      const cs = directives.tagString(compat.tag);
      const msg = `Value may be parsed as either ${ts} or ${cs}`;
      onError(token, "TAG_RESOLVE_FAILED", msg, true);
    }
  }
  return tag;
}

// node_modules/yaml/browser/dist/compose/util-empty-scalar-position.js
function emptyScalarPosition(offset, before, pos) {
  if (before) {
    pos ?? (pos = before.length);
    for (let i6 = pos - 1; i6 >= 0; --i6) {
      let st = before[i6];
      switch (st.type) {
        case "space":
        case "comment":
        case "newline":
          offset -= st.source.length;
          continue;
      }
      st = before[++i6];
      while (st?.type === "space") {
        offset += st.source.length;
        st = before[++i6];
      }
      break;
    }
  }
  return offset;
}

// node_modules/yaml/browser/dist/compose/compose-node.js
var CN = { composeNode, composeEmptyNode };
function composeNode(ctx, token, props, onError) {
  const atKey = ctx.atKey;
  const { spaceBefore, comment, anchor, tag } = props;
  let node;
  let isSrcToken = true;
  switch (token.type) {
    case "alias":
      node = composeAlias(ctx, token, onError);
      if (anchor || tag)
        onError(token, "ALIAS_PROPS", "An alias node must not specify any properties");
      break;
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "block-scalar":
      node = composeScalar(ctx, token, tag, onError);
      if (anchor)
        node.anchor = anchor.source.substring(1);
      break;
    case "block-map":
    case "block-seq":
    case "flow-collection":
      try {
        node = composeCollection(CN, ctx, token, props, onError);
        if (anchor)
          node.anchor = anchor.source.substring(1);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        onError(token, "RESOURCE_EXHAUSTION", message);
      }
      break;
    default: {
      const message = token.type === "error" ? token.message : `Unsupported token (type: ${token.type})`;
      onError(token, "UNEXPECTED_TOKEN", message);
      isSrcToken = false;
    }
  }
  node ?? (node = composeEmptyNode(ctx, token.offset, void 0, null, props, onError));
  if (anchor && node.anchor === "")
    onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
  if (atKey && ctx.options.stringKeys && (!isScalar(node) || typeof node.value !== "string" || node.tag && node.tag !== "tag:yaml.org,2002:str")) {
    const msg = "With stringKeys, all keys must be strings";
    onError(tag ?? token, "NON_STRING_KEY", msg);
  }
  if (spaceBefore)
    node.spaceBefore = true;
  if (comment) {
    if (token.type === "scalar" && token.source === "")
      node.comment = comment;
    else
      node.commentBefore = comment;
  }
  if (ctx.options.keepSourceTokens && isSrcToken)
    node.srcToken = token;
  return node;
}
function composeEmptyNode(ctx, offset, before, pos, { spaceBefore, comment, anchor, tag, end }, onError) {
  const token = {
    type: "scalar",
    offset: emptyScalarPosition(offset, before, pos),
    indent: -1,
    source: ""
  };
  const node = composeScalar(ctx, token, tag, onError);
  if (anchor) {
    node.anchor = anchor.source.substring(1);
    if (node.anchor === "")
      onError(anchor, "BAD_ALIAS", "Anchor cannot be an empty string");
  }
  if (spaceBefore)
    node.spaceBefore = true;
  if (comment) {
    node.comment = comment;
    node.range[2] = end;
  }
  return node;
}
function composeAlias({ options }, { offset, source, end }, onError) {
  const alias = new Alias(source.substring(1));
  if (alias.source === "")
    onError(offset, "BAD_ALIAS", "Alias cannot be an empty string");
  if (alias.source.endsWith(":"))
    onError(offset + source.length - 1, "BAD_ALIAS", "Alias ending in : is ambiguous", true);
  const valueEnd = offset + source.length;
  const re = resolveEnd(end, valueEnd, options.strict, onError);
  alias.range = [offset, valueEnd, re.offset];
  if (re.comment)
    alias.comment = re.comment;
  return alias;
}

// node_modules/yaml/browser/dist/compose/compose-doc.js
function composeDoc(options, directives, { offset, start, value, end }, onError) {
  const opts = Object.assign({ _directives: directives }, options);
  const doc = new Document2(void 0, opts);
  const ctx = {
    atKey: false,
    atRoot: true,
    directives: doc.directives,
    options: doc.options,
    schema: doc.schema
  };
  const props = resolveProps(start, {
    indicator: "doc-start",
    next: value ?? end?.[0],
    offset,
    onError,
    parentIndent: 0,
    startOnNewline: true
  });
  if (props.found) {
    doc.directives.docStart = true;
    if (value && (value.type === "block-map" || value.type === "block-seq") && !props.hasNewline)
      onError(props.end, "MISSING_CHAR", "Block collection cannot start on same line with directives-end marker");
  }
  doc.contents = value ? composeNode(ctx, value, props, onError) : composeEmptyNode(ctx, props.end, start, null, props, onError);
  const contentEnd = doc.contents.range[2];
  const re = resolveEnd(end, contentEnd, false, onError);
  if (re.comment)
    doc.comment = re.comment;
  doc.range = [offset, contentEnd, re.offset];
  return doc;
}

// node_modules/yaml/browser/dist/compose/composer.js
function getErrorPos(src) {
  if (typeof src === "number")
    return [src, src + 1];
  if (Array.isArray(src))
    return src.length === 2 ? src : [src[0], src[1]];
  const { offset, source } = src;
  return [offset, offset + (typeof source === "string" ? source.length : 1)];
}
function parsePrelude(prelude) {
  let comment = "";
  let atComment = false;
  let afterEmptyLine = false;
  for (let i6 = 0; i6 < prelude.length; ++i6) {
    const source = prelude[i6];
    switch (source[0]) {
      case "#":
        comment += (comment === "" ? "" : afterEmptyLine ? "\n\n" : "\n") + (source.substring(1) || " ");
        atComment = true;
        afterEmptyLine = false;
        break;
      case "%":
        if (prelude[i6 + 1]?.[0] !== "#")
          i6 += 1;
        atComment = false;
        break;
      default:
        if (!atComment)
          afterEmptyLine = true;
        atComment = false;
    }
  }
  return { comment, afterEmptyLine };
}
var Composer = class {
  constructor(options = {}) {
    this.doc = null;
    this.atDirectives = false;
    this.prelude = [];
    this.errors = [];
    this.warnings = [];
    this.onError = (source, code, message, warning) => {
      const pos = getErrorPos(source);
      if (warning)
        this.warnings.push(new YAMLWarning(pos, code, message));
      else
        this.errors.push(new YAMLParseError(pos, code, message));
    };
    this.directives = new Directives({ version: options.version || "1.2" });
    this.options = options;
  }
  decorate(doc, afterDoc) {
    const { comment, afterEmptyLine } = parsePrelude(this.prelude);
    if (comment) {
      const dc = doc.contents;
      if (afterDoc) {
        doc.comment = doc.comment ? `${doc.comment}
${comment}` : comment;
      } else if (afterEmptyLine || doc.directives.docStart || !dc) {
        doc.commentBefore = comment;
      } else if (isCollection(dc) && !dc.flow && dc.items.length > 0) {
        let it = dc.items[0];
        if (isPair(it))
          it = it.key;
        const cb = it.commentBefore;
        it.commentBefore = cb ? `${comment}
${cb}` : comment;
      } else {
        const cb = dc.commentBefore;
        dc.commentBefore = cb ? `${comment}
${cb}` : comment;
      }
    }
    if (afterDoc) {
      for (let i6 = 0; i6 < this.errors.length; ++i6)
        doc.errors.push(this.errors[i6]);
      for (let i6 = 0; i6 < this.warnings.length; ++i6)
        doc.warnings.push(this.warnings[i6]);
    } else {
      doc.errors = this.errors;
      doc.warnings = this.warnings;
    }
    this.prelude = [];
    this.errors = [];
    this.warnings = [];
  }
  /**
   * Current stream status information.
   *
   * Mostly useful at the end of input for an empty stream.
   */
  streamInfo() {
    return {
      comment: parsePrelude(this.prelude).comment,
      directives: this.directives,
      errors: this.errors,
      warnings: this.warnings
    };
  }
  /**
   * Compose tokens into documents.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *compose(tokens, forceDoc = false, endOffset = -1) {
    for (const token of tokens)
      yield* this.next(token);
    yield* this.end(forceDoc, endOffset);
  }
  /** Advance the composer by one CST token. */
  *next(token) {
    switch (token.type) {
      case "directive":
        this.directives.add(token.source, (offset, message, warning) => {
          const pos = getErrorPos(token);
          pos[0] += offset;
          this.onError(pos, "BAD_DIRECTIVE", message, warning);
        });
        this.prelude.push(token.source);
        this.atDirectives = true;
        break;
      case "document": {
        const doc = composeDoc(this.options, this.directives, token, this.onError);
        if (this.atDirectives && !doc.directives.docStart)
          this.onError(token, "MISSING_CHAR", "Missing directives-end/doc-start indicator line");
        this.decorate(doc, false);
        if (this.doc)
          yield this.doc;
        this.doc = doc;
        this.atDirectives = false;
        break;
      }
      case "byte-order-mark":
      case "space":
        break;
      case "comment":
      case "newline":
        this.prelude.push(token.source);
        break;
      case "error": {
        const msg = token.source ? `${token.message}: ${JSON.stringify(token.source)}` : token.message;
        const error = new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg);
        if (this.atDirectives || !this.doc)
          this.errors.push(error);
        else
          this.doc.errors.push(error);
        break;
      }
      case "doc-end": {
        if (!this.doc) {
          const msg = "Unexpected doc-end without preceding document";
          this.errors.push(new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", msg));
          break;
        }
        this.doc.directives.docEnd = true;
        const end = resolveEnd(token.end, token.offset + token.source.length, this.doc.options.strict, this.onError);
        this.decorate(this.doc, true);
        if (end.comment) {
          const dc = this.doc.comment;
          this.doc.comment = dc ? `${dc}
${end.comment}` : end.comment;
        }
        this.doc.range[2] = end.offset;
        break;
      }
      default:
        this.errors.push(new YAMLParseError(getErrorPos(token), "UNEXPECTED_TOKEN", `Unsupported token ${token.type}`));
    }
  }
  /**
   * Call at end of input to yield any remaining document.
   *
   * @param forceDoc - If the stream contains no document, still emit a final document including any comments and directives that would be applied to a subsequent document.
   * @param endOffset - Should be set if `forceDoc` is also set, to set the document range end and to indicate errors correctly.
   */
  *end(forceDoc = false, endOffset = -1) {
    if (this.doc) {
      this.decorate(this.doc, true);
      yield this.doc;
      this.doc = null;
    } else if (forceDoc) {
      const opts = Object.assign({ _directives: this.directives }, this.options);
      const doc = new Document2(void 0, opts);
      if (this.atDirectives)
        this.onError(endOffset, "MISSING_CHAR", "Missing directives-end indicator line");
      doc.range = [0, endOffset, endOffset];
      this.decorate(doc, false);
      yield doc;
    }
  }
};

// node_modules/yaml/browser/dist/parse/cst-visit.js
var BREAK2 = /* @__PURE__ */ Symbol("break visit");
var SKIP2 = /* @__PURE__ */ Symbol("skip children");
var REMOVE2 = /* @__PURE__ */ Symbol("remove item");
function visit2(cst, visitor) {
  if ("type" in cst && cst.type === "document")
    cst = { start: cst.start, value: cst.value };
  _visit(Object.freeze([]), cst, visitor);
}
visit2.BREAK = BREAK2;
visit2.SKIP = SKIP2;
visit2.REMOVE = REMOVE2;
visit2.itemAtPath = (cst, path) => {
  let item = cst;
  for (const [field2, index] of path) {
    const tok = item?.[field2];
    if (tok && "items" in tok) {
      item = tok.items[index];
    } else
      return void 0;
  }
  return item;
};
visit2.parentCollection = (cst, path) => {
  const parent = visit2.itemAtPath(cst, path.slice(0, -1));
  const field2 = path[path.length - 1][0];
  const coll = parent?.[field2];
  if (coll && "items" in coll)
    return coll;
  throw new Error("Parent collection not found");
};
function _visit(path, item, visitor) {
  let ctrl = visitor(item, path);
  if (typeof ctrl === "symbol")
    return ctrl;
  for (const field2 of ["key", "value"]) {
    const token = item[field2];
    if (token && "items" in token) {
      for (let i6 = 0; i6 < token.items.length; ++i6) {
        const ci = _visit(Object.freeze(path.concat([[field2, i6]])), token.items[i6], visitor);
        if (typeof ci === "number")
          i6 = ci - 1;
        else if (ci === BREAK2)
          return BREAK2;
        else if (ci === REMOVE2) {
          token.items.splice(i6, 1);
          i6 -= 1;
        }
      }
      if (typeof ctrl === "function" && field2 === "key")
        ctrl = ctrl(item, path);
    }
  }
  return typeof ctrl === "function" ? ctrl(item, path) : ctrl;
}

// node_modules/yaml/browser/dist/parse/cst.js
var BOM = "\uFEFF";
var DOCUMENT = "";
var FLOW_END = "";
var SCALAR2 = "";
function tokenType(source) {
  switch (source) {
    case BOM:
      return "byte-order-mark";
    case DOCUMENT:
      return "doc-mode";
    case FLOW_END:
      return "flow-error-end";
    case SCALAR2:
      return "scalar";
    case "---":
      return "doc-start";
    case "...":
      return "doc-end";
    case "":
    case "\n":
    case "\r\n":
      return "newline";
    case "-":
      return "seq-item-ind";
    case "?":
      return "explicit-key-ind";
    case ":":
      return "map-value-ind";
    case "{":
      return "flow-map-start";
    case "}":
      return "flow-map-end";
    case "[":
      return "flow-seq-start";
    case "]":
      return "flow-seq-end";
    case ",":
      return "comma";
  }
  switch (source[0]) {
    case " ":
    case "	":
      return "space";
    case "#":
      return "comment";
    case "%":
      return "directive-line";
    case "*":
      return "alias";
    case "&":
      return "anchor";
    case "!":
      return "tag";
    case "'":
      return "single-quoted-scalar";
    case '"':
      return "double-quoted-scalar";
    case "|":
    case ">":
      return "block-scalar-header";
  }
  return null;
}

// node_modules/yaml/browser/dist/parse/lexer.js
function isEmpty(ch) {
  switch (ch) {
    case void 0:
    case " ":
    case "\n":
    case "\r":
    case "	":
      return true;
    default:
      return false;
  }
}
var hexDigits = new Set("0123456789ABCDEFabcdef");
var tagChars = new Set("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-#;/?:@&=+$_.!~*'()");
var flowIndicatorChars = new Set(",[]{}");
var invalidAnchorChars = new Set(" ,[]{}\n\r	");
var isNotAnchorChar = (ch) => !ch || invalidAnchorChars.has(ch);
var Lexer = class {
  constructor() {
    this.atEnd = false;
    this.blockScalarIndent = -1;
    this.blockScalarKeep = false;
    this.buffer = "";
    this.flowKey = false;
    this.flowLevel = 0;
    this.indentNext = 0;
    this.indentValue = 0;
    this.lineEndPos = null;
    this.next = null;
    this.pos = 0;
  }
  /**
   * Generate YAML tokens from the `source` string. If `incomplete`,
   * a part of the last line may be left as a buffer for the next call.
   *
   * @returns A generator of lexical tokens
   */
  *lex(source, incomplete = false) {
    if (source) {
      if (typeof source !== "string")
        throw TypeError("source is not a string");
      this.buffer = this.buffer ? this.buffer + source : source;
      this.lineEndPos = null;
    }
    this.atEnd = !incomplete;
    let next = this.next ?? "stream";
    while (next && (incomplete || this.hasChars(1)))
      next = yield* this.parseNext(next);
  }
  atLineEnd() {
    let i6 = this.pos;
    let ch = this.buffer[i6];
    while (ch === " " || ch === "	")
      ch = this.buffer[++i6];
    if (!ch || ch === "#" || ch === "\n")
      return true;
    if (ch === "\r")
      return this.buffer[i6 + 1] === "\n";
    return false;
  }
  charAt(n6) {
    return this.buffer[this.pos + n6];
  }
  continueScalar(offset) {
    let ch = this.buffer[offset];
    if (this.indentNext > 0) {
      let indent = 0;
      while (ch === " ")
        ch = this.buffer[++indent + offset];
      if (ch === "\r") {
        const next = this.buffer[indent + offset + 1];
        if (next === "\n" || !next && !this.atEnd)
          return offset + indent + 1;
      }
      return ch === "\n" || indent >= this.indentNext || !ch && !this.atEnd ? offset + indent : -1;
    }
    if (ch === "-" || ch === ".") {
      const dt = this.buffer.substr(offset, 3);
      if ((dt === "---" || dt === "...") && isEmpty(this.buffer[offset + 3]))
        return -1;
    }
    return offset;
  }
  getLine() {
    let end = this.lineEndPos;
    if (typeof end !== "number" || end !== -1 && end < this.pos) {
      end = this.buffer.indexOf("\n", this.pos);
      this.lineEndPos = end;
    }
    if (end === -1)
      return this.atEnd ? this.buffer.substring(this.pos) : null;
    if (this.buffer[end - 1] === "\r")
      end -= 1;
    return this.buffer.substring(this.pos, end);
  }
  hasChars(n6) {
    return this.pos + n6 <= this.buffer.length;
  }
  setNext(state) {
    this.buffer = this.buffer.substring(this.pos);
    this.pos = 0;
    this.lineEndPos = null;
    this.next = state;
    return null;
  }
  peek(n6) {
    return this.buffer.substr(this.pos, n6);
  }
  *parseNext(next) {
    switch (next) {
      case "stream":
        return yield* this.parseStream();
      case "line-start":
        return yield* this.parseLineStart();
      case "block-start":
        return yield* this.parseBlockStart();
      case "doc":
        return yield* this.parseDocument();
      case "flow":
        return yield* this.parseFlowCollection();
      case "quoted-scalar":
        return yield* this.parseQuotedScalar();
      case "block-scalar":
        return yield* this.parseBlockScalar();
      case "plain-scalar":
        return yield* this.parsePlainScalar();
    }
  }
  *parseStream() {
    let line = this.getLine();
    if (line === null)
      return this.setNext("stream");
    if (line[0] === BOM) {
      yield* this.pushCount(1);
      line = line.substring(1);
    }
    if (line[0] === "%") {
      let dirEnd = line.length;
      let cs = line.indexOf("#");
      while (cs !== -1) {
        const ch = line[cs - 1];
        if (ch === " " || ch === "	") {
          dirEnd = cs - 1;
          break;
        } else {
          cs = line.indexOf("#", cs + 1);
        }
      }
      while (true) {
        const ch = line[dirEnd - 1];
        if (ch === " " || ch === "	")
          dirEnd -= 1;
        else
          break;
      }
      const n6 = (yield* this.pushCount(dirEnd)) + (yield* this.pushSpaces(true));
      yield* this.pushCount(line.length - n6);
      this.pushNewline();
      return "stream";
    }
    if (this.atLineEnd()) {
      const sp = yield* this.pushSpaces(true);
      yield* this.pushCount(line.length - sp);
      yield* this.pushNewline();
      return "stream";
    }
    yield DOCUMENT;
    return yield* this.parseLineStart();
  }
  *parseLineStart() {
    const ch = this.charAt(0);
    if (!ch && !this.atEnd)
      return this.setNext("line-start");
    if (ch === "-" || ch === ".") {
      if (!this.atEnd && !this.hasChars(4))
        return this.setNext("line-start");
      const s5 = this.peek(3);
      if ((s5 === "---" || s5 === "...") && isEmpty(this.charAt(3))) {
        yield* this.pushCount(3);
        this.indentValue = 0;
        this.indentNext = 0;
        return s5 === "---" ? "doc" : "stream";
      }
    }
    this.indentValue = yield* this.pushSpaces(false);
    if (this.indentNext > this.indentValue && !isEmpty(this.charAt(1)))
      this.indentNext = this.indentValue;
    return yield* this.parseBlockStart();
  }
  *parseBlockStart() {
    const [ch0, ch1] = this.peek(2);
    if (!ch1 && !this.atEnd)
      return this.setNext("block-start");
    if ((ch0 === "-" || ch0 === "?" || ch0 === ":") && isEmpty(ch1)) {
      const n6 = (yield* this.pushCount(1)) + (yield* this.pushSpaces(true));
      this.indentNext = this.indentValue + 1;
      this.indentValue += n6;
      return "block-start";
    }
    return "doc";
  }
  *parseDocument() {
    yield* this.pushSpaces(true);
    const line = this.getLine();
    if (line === null)
      return this.setNext("doc");
    let n6 = yield* this.pushIndicators();
    switch (line[n6]) {
      case "#":
        yield* this.pushCount(line.length - n6);
      // fallthrough
      case void 0:
        yield* this.pushNewline();
        return yield* this.parseLineStart();
      case "{":
      case "[":
        yield* this.pushCount(1);
        this.flowKey = false;
        this.flowLevel = 1;
        return "flow";
      case "}":
      case "]":
        yield* this.pushCount(1);
        return "doc";
      case "*":
        yield* this.pushUntil(isNotAnchorChar);
        return "doc";
      case '"':
      case "'":
        return yield* this.parseQuotedScalar();
      case "|":
      case ">":
        n6 += yield* this.parseBlockScalarHeader();
        n6 += yield* this.pushSpaces(true);
        yield* this.pushCount(line.length - n6);
        yield* this.pushNewline();
        return yield* this.parseBlockScalar();
      default:
        return yield* this.parsePlainScalar();
    }
  }
  *parseFlowCollection() {
    let nl, sp;
    let indent = -1;
    do {
      nl = yield* this.pushNewline();
      if (nl > 0) {
        sp = yield* this.pushSpaces(false);
        this.indentValue = indent = sp;
      } else {
        sp = 0;
      }
      sp += yield* this.pushSpaces(true);
    } while (nl + sp > 0);
    const line = this.getLine();
    if (line === null)
      return this.setNext("flow");
    if (indent !== -1 && indent < this.indentNext && line[0] !== "#" || indent === 0 && (line.startsWith("---") || line.startsWith("...")) && isEmpty(line[3])) {
      const atFlowEndMarker = indent === this.indentNext - 1 && this.flowLevel === 1 && (line[0] === "]" || line[0] === "}");
      if (!atFlowEndMarker) {
        this.flowLevel = 0;
        yield FLOW_END;
        return yield* this.parseLineStart();
      }
    }
    let n6 = 0;
    while (line[n6] === ",") {
      n6 += yield* this.pushCount(1);
      n6 += yield* this.pushSpaces(true);
      this.flowKey = false;
    }
    n6 += yield* this.pushIndicators();
    switch (line[n6]) {
      case void 0:
        return "flow";
      case "#":
        yield* this.pushCount(line.length - n6);
        return "flow";
      case "{":
      case "[":
        yield* this.pushCount(1);
        this.flowKey = false;
        this.flowLevel += 1;
        return "flow";
      case "}":
      case "]":
        yield* this.pushCount(1);
        this.flowKey = true;
        this.flowLevel -= 1;
        return this.flowLevel ? "flow" : "doc";
      case "*":
        yield* this.pushUntil(isNotAnchorChar);
        return "flow";
      case '"':
      case "'":
        this.flowKey = true;
        return yield* this.parseQuotedScalar();
      case ":": {
        const next = this.charAt(1);
        if (this.flowKey || isEmpty(next) || next === ",") {
          this.flowKey = false;
          yield* this.pushCount(1);
          yield* this.pushSpaces(true);
          return "flow";
        }
      }
      // fallthrough
      default:
        this.flowKey = false;
        return yield* this.parsePlainScalar();
    }
  }
  *parseQuotedScalar() {
    const quote = this.charAt(0);
    let end = this.buffer.indexOf(quote, this.pos + 1);
    if (quote === "'") {
      while (end !== -1 && this.buffer[end + 1] === "'")
        end = this.buffer.indexOf("'", end + 2);
    } else {
      while (end !== -1) {
        let n6 = 0;
        while (this.buffer[end - 1 - n6] === "\\")
          n6 += 1;
        if (n6 % 2 === 0)
          break;
        end = this.buffer.indexOf('"', end + 1);
      }
    }
    const qb = this.buffer.substring(0, end);
    let nl = qb.indexOf("\n", this.pos);
    if (nl !== -1) {
      while (nl !== -1) {
        const cs = this.continueScalar(nl + 1);
        if (cs === -1)
          break;
        nl = qb.indexOf("\n", cs);
      }
      if (nl !== -1) {
        end = nl - (qb[nl - 1] === "\r" ? 2 : 1);
      }
    }
    if (end === -1) {
      if (!this.atEnd)
        return this.setNext("quoted-scalar");
      end = this.buffer.length;
    }
    yield* this.pushToIndex(end + 1, false);
    return this.flowLevel ? "flow" : "doc";
  }
  *parseBlockScalarHeader() {
    this.blockScalarIndent = -1;
    this.blockScalarKeep = false;
    let i6 = this.pos;
    while (true) {
      const ch = this.buffer[++i6];
      if (ch === "+")
        this.blockScalarKeep = true;
      else if (ch > "0" && ch <= "9")
        this.blockScalarIndent = Number(ch) - 1;
      else if (ch !== "-")
        break;
    }
    return yield* this.pushUntil((ch) => isEmpty(ch) || ch === "#");
  }
  *parseBlockScalar() {
    let nl = this.pos - 1;
    let indent = 0;
    let ch;
    loop: for (let i7 = this.pos; ch = this.buffer[i7]; ++i7) {
      switch (ch) {
        case " ":
          indent += 1;
          break;
        case "\n":
          nl = i7;
          indent = 0;
          break;
        case "\r": {
          const next = this.buffer[i7 + 1];
          if (!next && !this.atEnd)
            return this.setNext("block-scalar");
          if (next === "\n")
            break;
        }
        // fallthrough
        default:
          break loop;
      }
    }
    if (!ch && !this.atEnd)
      return this.setNext("block-scalar");
    if (indent >= this.indentNext) {
      if (this.blockScalarIndent === -1)
        this.indentNext = indent;
      else {
        this.indentNext = this.blockScalarIndent + (this.indentNext === 0 ? 1 : this.indentNext);
      }
      do {
        const cs = this.continueScalar(nl + 1);
        if (cs === -1)
          break;
        nl = this.buffer.indexOf("\n", cs);
      } while (nl !== -1);
      if (nl === -1) {
        if (!this.atEnd)
          return this.setNext("block-scalar");
        nl = this.buffer.length;
      }
    }
    let i6 = nl + 1;
    ch = this.buffer[i6];
    while (ch === " ")
      ch = this.buffer[++i6];
    if (ch === "	") {
      while (ch === "	" || ch === " " || ch === "\r" || ch === "\n")
        ch = this.buffer[++i6];
      nl = i6 - 1;
    } else if (!this.blockScalarKeep) {
      do {
        let i7 = nl - 1;
        let ch2 = this.buffer[i7];
        if (ch2 === "\r")
          ch2 = this.buffer[--i7];
        const lastChar = i7;
        while (ch2 === " ")
          ch2 = this.buffer[--i7];
        if (ch2 === "\n" && i7 >= this.pos && i7 + 1 + indent > lastChar)
          nl = i7;
        else
          break;
      } while (true);
    }
    yield SCALAR2;
    yield* this.pushToIndex(nl + 1, true);
    return yield* this.parseLineStart();
  }
  *parsePlainScalar() {
    const inFlow = this.flowLevel > 0;
    let end = this.pos - 1;
    let i6 = this.pos - 1;
    let ch;
    while (ch = this.buffer[++i6]) {
      if (ch === ":") {
        const next = this.buffer[i6 + 1];
        if (isEmpty(next) || inFlow && flowIndicatorChars.has(next))
          break;
        end = i6;
      } else if (isEmpty(ch)) {
        let next = this.buffer[i6 + 1];
        if (ch === "\r") {
          if (next === "\n") {
            i6 += 1;
            ch = "\n";
            next = this.buffer[i6 + 1];
          } else
            end = i6;
        }
        if (next === "#" || inFlow && flowIndicatorChars.has(next))
          break;
        if (ch === "\n") {
          const cs = this.continueScalar(i6 + 1);
          if (cs === -1)
            break;
          i6 = Math.max(i6, cs - 2);
        }
      } else {
        if (inFlow && flowIndicatorChars.has(ch))
          break;
        end = i6;
      }
    }
    if (!ch && !this.atEnd)
      return this.setNext("plain-scalar");
    yield SCALAR2;
    yield* this.pushToIndex(end + 1, true);
    return inFlow ? "flow" : "doc";
  }
  *pushCount(n6) {
    if (n6 > 0) {
      yield this.buffer.substr(this.pos, n6);
      this.pos += n6;
      return n6;
    }
    return 0;
  }
  *pushToIndex(i6, allowEmpty) {
    const s5 = this.buffer.slice(this.pos, i6);
    if (s5) {
      yield s5;
      this.pos += s5.length;
      return s5.length;
    } else if (allowEmpty)
      yield "";
    return 0;
  }
  *pushIndicators() {
    let n6 = 0;
    loop: while (true) {
      switch (this.charAt(0)) {
        case "!":
          n6 += yield* this.pushTag();
          n6 += yield* this.pushSpaces(true);
          continue loop;
        case "&":
          n6 += yield* this.pushUntil(isNotAnchorChar);
          n6 += yield* this.pushSpaces(true);
          continue loop;
        case "-":
        // this is an error
        case "?":
        // this is an error outside flow collections
        case ":": {
          const inFlow = this.flowLevel > 0;
          const ch1 = this.charAt(1);
          if (isEmpty(ch1) || inFlow && flowIndicatorChars.has(ch1)) {
            if (!inFlow)
              this.indentNext = this.indentValue + 1;
            else if (this.flowKey)
              this.flowKey = false;
            n6 += yield* this.pushCount(1);
            n6 += yield* this.pushSpaces(true);
            continue loop;
          }
        }
      }
      break loop;
    }
    return n6;
  }
  *pushTag() {
    if (this.charAt(1) === "<") {
      let i6 = this.pos + 2;
      let ch = this.buffer[i6];
      while (!isEmpty(ch) && ch !== ">")
        ch = this.buffer[++i6];
      return yield* this.pushToIndex(ch === ">" ? i6 + 1 : i6, false);
    } else {
      let i6 = this.pos + 1;
      let ch = this.buffer[i6];
      while (ch) {
        if (tagChars.has(ch))
          ch = this.buffer[++i6];
        else if (ch === "%" && hexDigits.has(this.buffer[i6 + 1]) && hexDigits.has(this.buffer[i6 + 2])) {
          ch = this.buffer[i6 += 3];
        } else
          break;
      }
      return yield* this.pushToIndex(i6, false);
    }
  }
  *pushNewline() {
    const ch = this.buffer[this.pos];
    if (ch === "\n")
      return yield* this.pushCount(1);
    else if (ch === "\r" && this.charAt(1) === "\n")
      return yield* this.pushCount(2);
    else
      return 0;
  }
  *pushSpaces(allowTabs) {
    let i6 = this.pos - 1;
    let ch;
    do {
      ch = this.buffer[++i6];
    } while (ch === " " || allowTabs && ch === "	");
    const n6 = i6 - this.pos;
    if (n6 > 0) {
      yield this.buffer.substr(this.pos, n6);
      this.pos = i6;
    }
    return n6;
  }
  *pushUntil(test) {
    let i6 = this.pos;
    let ch = this.buffer[i6];
    while (!test(ch))
      ch = this.buffer[++i6];
    return yield* this.pushToIndex(i6, false);
  }
};

// node_modules/yaml/browser/dist/parse/line-counter.js
var LineCounter = class {
  constructor() {
    this.lineStarts = [];
    this.addNewLine = (offset) => this.lineStarts.push(offset);
    this.linePos = (offset) => {
      let low = 0;
      let high = this.lineStarts.length;
      while (low < high) {
        const mid = low + high >> 1;
        if (this.lineStarts[mid] < offset)
          low = mid + 1;
        else
          high = mid;
      }
      if (this.lineStarts[low] === offset)
        return { line: low + 1, col: 1 };
      if (low === 0)
        return { line: 0, col: offset };
      const start = this.lineStarts[low - 1];
      return { line: low, col: offset - start + 1 };
    };
  }
};

// node_modules/yaml/browser/dist/parse/parser.js
function includesToken(list, type) {
  for (let i6 = 0; i6 < list.length; ++i6)
    if (list[i6].type === type)
      return true;
  return false;
}
function findNonEmptyIndex(list) {
  for (let i6 = 0; i6 < list.length; ++i6) {
    switch (list[i6].type) {
      case "space":
      case "comment":
      case "newline":
        break;
      default:
        return i6;
    }
  }
  return -1;
}
function isFlowToken(token) {
  switch (token?.type) {
    case "alias":
    case "scalar":
    case "single-quoted-scalar":
    case "double-quoted-scalar":
    case "flow-collection":
      return true;
    default:
      return false;
  }
}
function getPrevProps(parent) {
  switch (parent.type) {
    case "document":
      return parent.start;
    case "block-map": {
      const it = parent.items[parent.items.length - 1];
      return it.sep ?? it.start;
    }
    case "block-seq":
      return parent.items[parent.items.length - 1].start;
    /* istanbul ignore next should not happen */
    default:
      return [];
  }
}
function getFirstKeyStartProps(prev) {
  if (prev.length === 0)
    return [];
  let i6 = prev.length;
  loop: while (--i6 >= 0) {
    switch (prev[i6].type) {
      case "doc-start":
      case "explicit-key-ind":
      case "map-value-ind":
      case "seq-item-ind":
      case "newline":
        break loop;
    }
  }
  while (prev[++i6]?.type === "space") {
  }
  return prev.splice(i6, prev.length);
}
function arrayPushArray(target, source) {
  if (source.length < 1e5)
    Array.prototype.push.apply(target, source);
  else
    for (let i6 = 0; i6 < source.length; ++i6)
      target.push(source[i6]);
}
function fixFlowSeqItems(fc) {
  if (fc.start.type === "flow-seq-start") {
    for (const it of fc.items) {
      if (it.sep && !it.value && !includesToken(it.start, "explicit-key-ind") && !includesToken(it.sep, "map-value-ind")) {
        if (it.key)
          it.value = it.key;
        delete it.key;
        if (isFlowToken(it.value)) {
          if (it.value.end)
            arrayPushArray(it.value.end, it.sep);
          else
            it.value.end = it.sep;
        } else
          arrayPushArray(it.start, it.sep);
        delete it.sep;
      }
    }
  }
}
var Parser = class {
  /**
   * @param onNewLine - If defined, called separately with the start position of
   *   each new line (in `parse()`, including the start of input).
   */
  constructor(onNewLine) {
    this.atNewLine = true;
    this.atScalar = false;
    this.indent = 0;
    this.offset = 0;
    this.onKeyLine = false;
    this.stack = [];
    this.source = "";
    this.type = "";
    this.lexer = new Lexer();
    this.onNewLine = onNewLine;
  }
  /**
   * Parse `source` as a YAML stream.
   * If `incomplete`, a part of the last line may be left as a buffer for the next call.
   *
   * Errors are not thrown, but yielded as `{ type: 'error', message }` tokens.
   *
   * @returns A generator of tokens representing each directive, document, and other structure.
   */
  *parse(source, incomplete = false) {
    if (this.onNewLine && this.offset === 0)
      this.onNewLine(0);
    for (const lexeme of this.lexer.lex(source, incomplete))
      yield* this.next(lexeme);
    if (!incomplete)
      yield* this.end();
  }
  /**
   * Advance the parser by the `source` of one lexical token.
   */
  *next(source) {
    this.source = source;
    if (this.atScalar) {
      this.atScalar = false;
      yield* this.step();
      this.offset += source.length;
      return;
    }
    const type = tokenType(source);
    if (!type) {
      const message = `Not a YAML token: ${source}`;
      yield* this.pop({ type: "error", offset: this.offset, message, source });
      this.offset += source.length;
    } else if (type === "scalar") {
      this.atNewLine = false;
      this.atScalar = true;
      this.type = "scalar";
    } else {
      this.type = type;
      yield* this.step();
      switch (type) {
        case "newline":
          this.atNewLine = true;
          this.indent = 0;
          if (this.onNewLine)
            this.onNewLine(this.offset + source.length);
          break;
        case "space":
          if (this.atNewLine && source[0] === " ")
            this.indent += source.length;
          break;
        case "explicit-key-ind":
        case "map-value-ind":
        case "seq-item-ind":
          if (this.atNewLine)
            this.indent += source.length;
          break;
        case "doc-mode":
        case "flow-error-end":
          return;
        default:
          this.atNewLine = false;
      }
      this.offset += source.length;
    }
  }
  /** Call at end of input to push out any remaining constructions */
  *end() {
    while (this.stack.length > 0)
      yield* this.pop();
  }
  get sourceToken() {
    const st = {
      type: this.type,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
    return st;
  }
  *step() {
    const top = this.peek(1);
    if (this.type === "doc-end" && top?.type !== "doc-end") {
      while (this.stack.length > 0)
        yield* this.pop();
      this.stack.push({
        type: "doc-end",
        offset: this.offset,
        source: this.source
      });
      return;
    }
    if (!top)
      return yield* this.stream();
    switch (top.type) {
      case "document":
        return yield* this.document(top);
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return yield* this.scalar(top);
      case "block-scalar":
        return yield* this.blockScalar(top);
      case "block-map":
        return yield* this.blockMap(top);
      case "block-seq":
        return yield* this.blockSequence(top);
      case "flow-collection":
        return yield* this.flowCollection(top);
      case "doc-end":
        return yield* this.documentEnd(top);
    }
    yield* this.pop();
  }
  peek(n6) {
    return this.stack[this.stack.length - n6];
  }
  *pop(error) {
    const token = error ?? this.stack.pop();
    if (!token) {
      const message = "Tried to pop an empty stack";
      yield { type: "error", offset: this.offset, source: "", message };
    } else if (this.stack.length === 0) {
      yield token;
    } else {
      const top = this.peek(1);
      if (token.type === "block-scalar") {
        token.indent = "indent" in top ? top.indent : 0;
      } else if (token.type === "flow-collection" && top.type === "document") {
        token.indent = 0;
      }
      if (token.type === "flow-collection")
        fixFlowSeqItems(token);
      switch (top.type) {
        case "document":
          top.value = token;
          break;
        case "block-scalar":
          top.props.push(token);
          break;
        case "block-map": {
          const it = top.items[top.items.length - 1];
          if (it.value) {
            top.items.push({ start: [], key: token, sep: [] });
            this.onKeyLine = true;
            return;
          } else if (it.sep) {
            it.value = token;
          } else {
            Object.assign(it, { key: token, sep: [] });
            this.onKeyLine = !it.explicitKey;
            return;
          }
          break;
        }
        case "block-seq": {
          const it = top.items[top.items.length - 1];
          if (it.value)
            top.items.push({ start: [], value: token });
          else
            it.value = token;
          break;
        }
        case "flow-collection": {
          const it = top.items[top.items.length - 1];
          if (!it || it.value)
            top.items.push({ start: [], key: token, sep: [] });
          else if (it.sep)
            it.value = token;
          else
            Object.assign(it, { key: token, sep: [] });
          return;
        }
        /* istanbul ignore next should not happen */
        default:
          yield* this.pop();
          yield* this.pop(token);
      }
      if ((top.type === "document" || top.type === "block-map" || top.type === "block-seq") && (token.type === "block-map" || token.type === "block-seq")) {
        const last = token.items[token.items.length - 1];
        if (last && !last.sep && !last.value && last.start.length > 0 && findNonEmptyIndex(last.start) === -1 && (token.indent === 0 || last.start.every((st) => st.type !== "comment" || st.indent < token.indent))) {
          if (top.type === "document")
            top.end = last.start;
          else
            top.items.push({ start: last.start });
          token.items.splice(-1, 1);
        }
      }
    }
  }
  *stream() {
    switch (this.type) {
      case "directive-line":
        yield { type: "directive", offset: this.offset, source: this.source };
        return;
      case "byte-order-mark":
      case "space":
      case "comment":
      case "newline":
        yield this.sourceToken;
        return;
      case "doc-mode":
      case "doc-start": {
        const doc = {
          type: "document",
          offset: this.offset,
          start: []
        };
        if (this.type === "doc-start")
          doc.start.push(this.sourceToken);
        this.stack.push(doc);
        return;
      }
    }
    yield {
      type: "error",
      offset: this.offset,
      message: `Unexpected ${this.type} token in YAML stream`,
      source: this.source
    };
  }
  *document(doc) {
    if (doc.value)
      return yield* this.lineEnd(doc);
    switch (this.type) {
      case "doc-start": {
        if (findNonEmptyIndex(doc.start) !== -1) {
          yield* this.pop();
          yield* this.step();
        } else
          doc.start.push(this.sourceToken);
        return;
      }
      case "anchor":
      case "tag":
      case "space":
      case "comment":
      case "newline":
        doc.start.push(this.sourceToken);
        return;
    }
    const bv = this.startBlockValue(doc);
    if (bv)
      this.stack.push(bv);
    else {
      yield {
        type: "error",
        offset: this.offset,
        message: `Unexpected ${this.type} token in YAML document`,
        source: this.source
      };
    }
  }
  *scalar(scalar) {
    if (this.type === "map-value-ind") {
      const prev = getPrevProps(this.peek(2));
      const start = getFirstKeyStartProps(prev);
      let sep;
      if (scalar.end) {
        sep = scalar.end;
        sep.push(this.sourceToken);
        delete scalar.end;
      } else
        sep = [this.sourceToken];
      const map2 = {
        type: "block-map",
        offset: scalar.offset,
        indent: scalar.indent,
        items: [{ start, key: scalar, sep }]
      };
      this.onKeyLine = true;
      this.stack[this.stack.length - 1] = map2;
    } else
      yield* this.lineEnd(scalar);
  }
  *blockScalar(scalar) {
    switch (this.type) {
      case "space":
      case "comment":
      case "newline":
        scalar.props.push(this.sourceToken);
        return;
      case "scalar":
        scalar.source = this.source;
        this.atNewLine = true;
        this.indent = 0;
        if (this.onNewLine) {
          let nl = this.source.indexOf("\n") + 1;
          while (nl !== 0) {
            this.onNewLine(this.offset + nl);
            nl = this.source.indexOf("\n", nl) + 1;
          }
        }
        yield* this.pop();
        break;
      /* istanbul ignore next should not happen */
      default:
        yield* this.pop();
        yield* this.step();
    }
  }
  *blockMap(map2) {
    const it = map2.items[map2.items.length - 1];
    switch (this.type) {
      case "newline":
        this.onKeyLine = false;
        if (it.value) {
          const end = "end" in it.value ? it.value.end : void 0;
          const last = Array.isArray(end) ? end[end.length - 1] : void 0;
          if (last?.type === "comment")
            end?.push(this.sourceToken);
          else
            map2.items.push({ start: [this.sourceToken] });
        } else if (it.sep) {
          it.sep.push(this.sourceToken);
        } else {
          it.start.push(this.sourceToken);
        }
        return;
      case "space":
      case "comment":
        if (it.value) {
          map2.items.push({ start: [this.sourceToken] });
        } else if (it.sep) {
          it.sep.push(this.sourceToken);
        } else {
          if (this.atIndentedComment(it.start, map2.indent)) {
            const prev = map2.items[map2.items.length - 2];
            const end = prev?.value?.end;
            if (Array.isArray(end)) {
              arrayPushArray(end, it.start);
              end.push(this.sourceToken);
              map2.items.pop();
              return;
            }
          }
          it.start.push(this.sourceToken);
        }
        return;
    }
    if (this.indent >= map2.indent) {
      const atMapIndent = !this.onKeyLine && this.indent === map2.indent;
      const atNextItem = atMapIndent && (it.sep || it.explicitKey) && this.type !== "seq-item-ind";
      let start = [];
      if (atNextItem && it.sep && !it.value) {
        const nl = [];
        for (let i6 = 0; i6 < it.sep.length; ++i6) {
          const st = it.sep[i6];
          switch (st.type) {
            case "newline":
              nl.push(i6);
              break;
            case "space":
              break;
            case "comment":
              if (st.indent > map2.indent)
                nl.length = 0;
              break;
            default:
              nl.length = 0;
          }
        }
        if (nl.length >= 2)
          start = it.sep.splice(nl[1]);
      }
      switch (this.type) {
        case "anchor":
        case "tag":
          if (atNextItem || it.value) {
            start.push(this.sourceToken);
            map2.items.push({ start });
            this.onKeyLine = true;
          } else if (it.sep) {
            it.sep.push(this.sourceToken);
          } else {
            it.start.push(this.sourceToken);
          }
          return;
        case "explicit-key-ind":
          if (!it.sep && !it.explicitKey) {
            it.start.push(this.sourceToken);
            it.explicitKey = true;
          } else if (atNextItem || it.value) {
            start.push(this.sourceToken);
            map2.items.push({ start, explicitKey: true });
          } else {
            this.stack.push({
              type: "block-map",
              offset: this.offset,
              indent: this.indent,
              items: [{ start: [this.sourceToken], explicitKey: true }]
            });
          }
          this.onKeyLine = true;
          return;
        case "map-value-ind":
          if (it.explicitKey) {
            if (!it.sep) {
              if (includesToken(it.start, "newline")) {
                Object.assign(it, { key: null, sep: [this.sourceToken] });
              } else {
                const start2 = getFirstKeyStartProps(it.start);
                this.stack.push({
                  type: "block-map",
                  offset: this.offset,
                  indent: this.indent,
                  items: [{ start: start2, key: null, sep: [this.sourceToken] }]
                });
              }
            } else if (it.value) {
              map2.items.push({ start: [], key: null, sep: [this.sourceToken] });
            } else if (includesToken(it.sep, "map-value-ind")) {
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start, key: null, sep: [this.sourceToken] }]
              });
            } else if (isFlowToken(it.key) && !includesToken(it.sep, "newline")) {
              const start2 = getFirstKeyStartProps(it.start);
              const key = it.key;
              const sep = it.sep;
              sep.push(this.sourceToken);
              delete it.key;
              delete it.sep;
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start: start2, key, sep }]
              });
            } else if (start.length > 0) {
              it.sep = it.sep.concat(start, this.sourceToken);
            } else {
              it.sep.push(this.sourceToken);
            }
          } else {
            if (!it.sep) {
              Object.assign(it, { key: null, sep: [this.sourceToken] });
            } else if (it.value || atNextItem) {
              map2.items.push({ start, key: null, sep: [this.sourceToken] });
            } else if (includesToken(it.sep, "map-value-ind")) {
              this.stack.push({
                type: "block-map",
                offset: this.offset,
                indent: this.indent,
                items: [{ start: [], key: null, sep: [this.sourceToken] }]
              });
            } else {
              it.sep.push(this.sourceToken);
            }
          }
          this.onKeyLine = true;
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const fs = this.flowScalar(this.type);
          if (atNextItem || it.value) {
            map2.items.push({ start, key: fs, sep: [] });
            this.onKeyLine = true;
          } else if (it.sep) {
            this.stack.push(fs);
          } else {
            Object.assign(it, { key: fs, sep: [] });
            this.onKeyLine = true;
          }
          return;
        }
        default: {
          const bv = this.startBlockValue(map2);
          if (bv) {
            if (bv.type === "block-seq") {
              if (!it.explicitKey && it.sep && !includesToken(it.sep, "newline")) {
                yield* this.pop({
                  type: "error",
                  offset: this.offset,
                  message: "Unexpected block-seq-ind on same line with key",
                  source: this.source
                });
                return;
              }
            } else if (atMapIndent) {
              map2.items.push({ start });
            }
            this.stack.push(bv);
            return;
          }
        }
      }
    }
    yield* this.pop();
    yield* this.step();
  }
  *blockSequence(seq2) {
    const it = seq2.items[seq2.items.length - 1];
    switch (this.type) {
      case "newline":
        if (it.value) {
          const end = "end" in it.value ? it.value.end : void 0;
          const last = Array.isArray(end) ? end[end.length - 1] : void 0;
          if (last?.type === "comment")
            end?.push(this.sourceToken);
          else
            seq2.items.push({ start: [this.sourceToken] });
        } else
          it.start.push(this.sourceToken);
        return;
      case "space":
      case "comment":
        if (it.value)
          seq2.items.push({ start: [this.sourceToken] });
        else {
          if (this.atIndentedComment(it.start, seq2.indent)) {
            const prev = seq2.items[seq2.items.length - 2];
            const end = prev?.value?.end;
            if (Array.isArray(end)) {
              arrayPushArray(end, it.start);
              end.push(this.sourceToken);
              seq2.items.pop();
              return;
            }
          }
          it.start.push(this.sourceToken);
        }
        return;
      case "anchor":
      case "tag":
        if (it.value || this.indent <= seq2.indent)
          break;
        it.start.push(this.sourceToken);
        return;
      case "seq-item-ind":
        if (this.indent !== seq2.indent)
          break;
        if (it.value || includesToken(it.start, "seq-item-ind"))
          seq2.items.push({ start: [this.sourceToken] });
        else
          it.start.push(this.sourceToken);
        return;
    }
    if (this.indent > seq2.indent) {
      const bv = this.startBlockValue(seq2);
      if (bv) {
        this.stack.push(bv);
        return;
      }
    }
    yield* this.pop();
    yield* this.step();
  }
  *flowCollection(fc) {
    const it = fc.items[fc.items.length - 1];
    if (this.type === "flow-error-end") {
      let top;
      do {
        yield* this.pop();
        top = this.peek(1);
      } while (top?.type === "flow-collection");
    } else if (fc.end.length === 0) {
      switch (this.type) {
        case "comma":
        case "explicit-key-ind":
          if (!it || it.sep)
            fc.items.push({ start: [this.sourceToken] });
          else
            it.start.push(this.sourceToken);
          return;
        case "map-value-ind":
          if (!it || it.value)
            fc.items.push({ start: [], key: null, sep: [this.sourceToken] });
          else if (it.sep)
            it.sep.push(this.sourceToken);
          else
            Object.assign(it, { key: null, sep: [this.sourceToken] });
          return;
        case "space":
        case "comment":
        case "newline":
        case "anchor":
        case "tag":
          if (!it || it.value)
            fc.items.push({ start: [this.sourceToken] });
          else if (it.sep)
            it.sep.push(this.sourceToken);
          else
            it.start.push(this.sourceToken);
          return;
        case "alias":
        case "scalar":
        case "single-quoted-scalar":
        case "double-quoted-scalar": {
          const fs = this.flowScalar(this.type);
          if (!it || it.value)
            fc.items.push({ start: [], key: fs, sep: [] });
          else if (it.sep)
            this.stack.push(fs);
          else
            Object.assign(it, { key: fs, sep: [] });
          return;
        }
        case "flow-map-end":
        case "flow-seq-end":
          fc.end.push(this.sourceToken);
          return;
      }
      const bv = this.startBlockValue(fc);
      if (bv)
        this.stack.push(bv);
      else {
        yield* this.pop();
        yield* this.step();
      }
    } else {
      const parent = this.peek(2);
      if (parent.type === "block-map" && (this.type === "map-value-ind" && parent.indent === fc.indent || this.type === "newline" && !parent.items[parent.items.length - 1].sep)) {
        yield* this.pop();
        yield* this.step();
      } else if (this.type === "map-value-ind" && parent.type !== "flow-collection") {
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        fixFlowSeqItems(fc);
        const sep = fc.end.splice(1, fc.end.length);
        sep.push(this.sourceToken);
        const map2 = {
          type: "block-map",
          offset: fc.offset,
          indent: fc.indent,
          items: [{ start, key: fc, sep }]
        };
        this.onKeyLine = true;
        this.stack[this.stack.length - 1] = map2;
      } else {
        yield* this.lineEnd(fc);
      }
    }
  }
  flowScalar(type) {
    if (this.onNewLine) {
      let nl = this.source.indexOf("\n") + 1;
      while (nl !== 0) {
        this.onNewLine(this.offset + nl);
        nl = this.source.indexOf("\n", nl) + 1;
      }
    }
    return {
      type,
      offset: this.offset,
      indent: this.indent,
      source: this.source
    };
  }
  startBlockValue(parent) {
    switch (this.type) {
      case "alias":
      case "scalar":
      case "single-quoted-scalar":
      case "double-quoted-scalar":
        return this.flowScalar(this.type);
      case "block-scalar-header":
        return {
          type: "block-scalar",
          offset: this.offset,
          indent: this.indent,
          props: [this.sourceToken],
          source: ""
        };
      case "flow-map-start":
      case "flow-seq-start":
        return {
          type: "flow-collection",
          offset: this.offset,
          indent: this.indent,
          start: this.sourceToken,
          items: [],
          end: []
        };
      case "seq-item-ind":
        return {
          type: "block-seq",
          offset: this.offset,
          indent: this.indent,
          items: [{ start: [this.sourceToken] }]
        };
      case "explicit-key-ind": {
        this.onKeyLine = true;
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        start.push(this.sourceToken);
        return {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start, explicitKey: true }]
        };
      }
      case "map-value-ind": {
        this.onKeyLine = true;
        const prev = getPrevProps(parent);
        const start = getFirstKeyStartProps(prev);
        return {
          type: "block-map",
          offset: this.offset,
          indent: this.indent,
          items: [{ start, key: null, sep: [this.sourceToken] }]
        };
      }
    }
    return null;
  }
  atIndentedComment(start, indent) {
    if (this.type !== "comment")
      return false;
    if (this.indent <= indent)
      return false;
    return start.every((st) => st.type === "newline" || st.type === "space");
  }
  *documentEnd(docEnd) {
    if (this.type !== "doc-mode") {
      if (docEnd.end)
        docEnd.end.push(this.sourceToken);
      else
        docEnd.end = [this.sourceToken];
      if (this.type === "newline")
        yield* this.pop();
    }
  }
  *lineEnd(token) {
    switch (this.type) {
      case "comma":
      case "doc-start":
      case "doc-end":
      case "flow-seq-end":
      case "flow-map-end":
      case "map-value-ind":
        yield* this.pop();
        yield* this.step();
        break;
      case "newline":
        this.onKeyLine = false;
      // fallthrough
      case "space":
      case "comment":
      default:
        if (token.end)
          token.end.push(this.sourceToken);
        else
          token.end = [this.sourceToken];
        if (this.type === "newline")
          yield* this.pop();
    }
  }
};

// node_modules/yaml/browser/dist/public-api.js
function parseOptions(options) {
  const prettyErrors = options.prettyErrors !== false;
  const lineCounter = options.lineCounter || prettyErrors && new LineCounter() || null;
  return { lineCounter, prettyErrors };
}
function parseDocument(source, options = {}) {
  const { lineCounter, prettyErrors } = parseOptions(options);
  const parser = new Parser(lineCounter?.addNewLine);
  const composer = new Composer(options);
  let doc = null;
  for (const _doc of composer.compose(parser.parse(source), true, source.length)) {
    if (!doc)
      doc = _doc;
    else if (doc.options.logLevel !== "silent") {
      doc.errors.push(new YAMLParseError(_doc.range.slice(0, 2), "MULTIPLE_DOCS", "Source contains multiple documents; please use YAML.parseAllDocuments()"));
      break;
    }
  }
  if (prettyErrors && lineCounter) {
    doc.errors.forEach(prettifyError(source, lineCounter));
    doc.warnings.forEach(prettifyError(source, lineCounter));
  }
  return doc;
}
function parse(src, reviver, options) {
  let _reviver = void 0;
  if (typeof reviver === "function") {
    _reviver = reviver;
  } else if (options === void 0 && reviver && typeof reviver === "object") {
    options = reviver;
  }
  const doc = parseDocument(src, options);
  if (!doc)
    return null;
  doc.warnings.forEach((warning) => warn(doc.options.logLevel, warning));
  if (doc.errors.length > 0) {
    if (doc.options.logLevel !== "silent")
      throw doc.errors[0];
    else
      doc.errors = [];
  }
  return doc.toJS(Object.assign({ reviver: _reviver }, options));
}
function stringify3(value, replacer, options) {
  let _replacer = null;
  if (typeof replacer === "function" || Array.isArray(replacer)) {
    _replacer = replacer;
  } else if (options === void 0 && replacer) {
    options = replacer;
  }
  if (typeof options === "string")
    options = options.length;
  if (typeof options === "number") {
    const indent = Math.round(options);
    options = indent < 1 ? void 0 : indent > 8 ? { indent: 8 } : { indent };
  }
  if (value === void 0) {
    const { keepUndefined } = options ?? replacer ?? {};
    if (!keepUndefined)
      return void 0;
  }
  if (isDocument(value) && !_replacer)
    return value.toString(options);
  return new Document2(value, _replacer, options).toString(options);
}

// node_modules/lit-html/directive-helpers.js
var { I: t3 } = j;
var r4 = (o7) => void 0 === o7.strings;

// node_modules/lit-html/directive.js
var t4 = { ATTRIBUTE: 1, CHILD: 2, PROPERTY: 3, BOOLEAN_ATTRIBUTE: 4, EVENT: 5, ELEMENT: 6 };
var e4 = (t5) => (...e5) => ({ _$litDirective$: t5, values: e5 });
var i5 = class {
  constructor(t5) {
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AT(t5, e5, i6) {
    this._$Ct = t5, this._$AM = e5, this._$Ci = i6;
  }
  _$AS(t5, e5) {
    return this.update(t5, e5);
  }
  update(t5, e5) {
    return this.render(...e5);
  }
};

// node_modules/lit-html/async-directive.js
var s4 = (i6, t5) => {
  const e5 = i6._$AN;
  if (void 0 === e5) return false;
  for (const i7 of e5) i7._$AO?.(t5, false), s4(i7, t5);
  return true;
};
var o5 = (i6) => {
  let t5, e5;
  do {
    if (void 0 === (t5 = i6._$AM)) break;
    e5 = t5._$AN, e5.delete(i6), i6 = t5;
  } while (0 === e5?.size);
};
var r5 = (i6) => {
  for (let t5; t5 = i6._$AM; i6 = t5) {
    let e5 = t5._$AN;
    if (void 0 === e5) t5._$AN = e5 = /* @__PURE__ */ new Set();
    else if (e5.has(i6)) break;
    e5.add(i6), c4(t5);
  }
};
function h3(i6) {
  void 0 !== this._$AN ? (o5(this), this._$AM = i6, r5(this)) : this._$AM = i6;
}
function n4(i6, t5 = false, e5 = 0) {
  const r6 = this._$AH, h4 = this._$AN;
  if (void 0 !== h4 && 0 !== h4.size) if (t5) if (Array.isArray(r6)) for (let i7 = e5; i7 < r6.length; i7++) s4(r6[i7], false), o5(r6[i7]);
  else null != r6 && (s4(r6, false), o5(r6));
  else s4(this, i6);
}
var c4 = (i6) => {
  i6.type == t4.CHILD && (i6._$AP ??= n4, i6._$AQ ??= h3);
};
var f3 = class extends i5 {
  constructor() {
    super(...arguments), this._$AN = void 0;
  }
  _$AT(i6, t5, e5) {
    super._$AT(i6, t5, e5), r5(this), this.isConnected = i6._$AU;
  }
  _$AO(i6, t5 = true) {
    i6 !== this.isConnected && (this.isConnected = i6, i6 ? this.reconnected?.() : this.disconnected?.()), t5 && (s4(this, i6), o5(this));
  }
  setValue(t5) {
    if (r4(this._$Ct)) this._$Ct._$AI(t5, this);
    else {
      const i6 = [...this._$Ct._$AH];
      i6[this._$Ci] = t5, this._$Ct._$AI(i6, this, 0);
    }
  }
  disconnected() {
  }
  reconnected() {
  }
};

// node_modules/lit-html/directives/ref.js
var o6 = /* @__PURE__ */ new WeakMap();
var n5 = e4(class extends f3 {
  render(i6) {
    return A;
  }
  update(i6, [s5]) {
    const e5 = s5 !== this.G;
    return e5 && this.rt(void 0), (e5 || this.lt !== this.ct) && (this.G = s5, this.ht = i6.options?.host, this.rt(this.ct = i6.element)), A;
  }
  rt(t5) {
    if (void 0 !== this.G) if (this.isConnected || (t5 = void 0), "function" == typeof this.G) {
      const i6 = this.ht ?? globalThis;
      let s5 = o6.get(i6);
      void 0 === s5 && (s5 = /* @__PURE__ */ new WeakMap(), o6.set(i6, s5)), void 0 !== s5.get(this.G) && this.G.call(this.ht, void 0), s5.set(this.G, t5), void 0 !== t5 && this.G.call(this.ht, t5);
    } else this.G.value = t5;
  }
  get lt() {
    return "function" == typeof this.G ? o6.get(this.ht ?? globalThis)?.get(this.G) : this.G?.value;
  }
  disconnected() {
    this.lt === this.ct && this.rt(void 0);
  }
  reconnected() {
    this.rt(this.ct);
  }
});

// frontend/editor/helpers.ts
function editorModeFor(value) {
  return "yaml";
}
function isSectionVisible(setting, settings) {
  return !setting || settings[setting];
}
function defaultAlert() {
  return {
    id: `alert_${Date.now()}`,
    name: "",
    enabled: true,
    description: "",
    icon: "mdi:bell-outline",
    conditions: [{ condition: "template", value_template: "{{ true }}" }],
    monitor: {
      on_change: true,
      startup: true,
      clear_on_inactive: false
    },
    notification: {
      target: {},
      data: { title: "", message: "" }
    },
    confirmation: {
      enabled: false,
      buttons: [{ id: "confirm", label: "Done" }],
      notification: {
        data: { message: "" }
      },
      reminders: {
        enabled: false,
        interval: "00:30:00",
        max_attempts: 5,
        show_attempts: false,
        forget_after_enabled: false,
        timeout: "00:15:00"
      },
      actions: []
    }
  };
}
function conditionYaml(condition) {
  return stringify3(condition);
}
function actionsYaml(actions) {
  if (actions?.length) {
    return stringify3(actions);
  }
  return "";
}
function parseConditionYaml(value) {
  const parsed = parse(value);
  if (Array.isArray(parsed) && parsed.every((item) => item && typeof item === "object" && !Array.isArray(item))) {
    return parsed;
  }
  throw new Error("Conditions YAML must be a list of mappings.");
}
function valueOf(event) {
  return event.currentTarget.value;
}
function checkedOf(event) {
  return event.currentTarget.checked;
}
function showEditorToast(root, message, duration = 6e3) {
  root.dispatchEvent(
    new CustomEvent("nc-editor-toast", { detail: { message, duration } })
  );
}
function durationInputValue(value, fallback) {
  if (typeof value === "number" && Number.isFinite(value)) {
    const totalSeconds2 = Math.max(0, Math.floor(value));
    const hours2 = Math.floor(totalSeconds2 / 3600);
    const minutes2 = Math.floor(totalSeconds2 % 3600 / 60);
    const seconds2 = totalSeconds2 % 60;
    return [hours2, minutes2, seconds2].map((part) => String(part).padStart(2, "0")).join(":");
  }
  if (typeof value === "string") {
    const parts = value.split(":");
    if (parts.length === 2) return `${value}:00`;
    return value;
  }
  if (!value || typeof value !== "object") return fallback;
  const totalSeconds = Math.max(
    0,
    Math.floor(
      (Number(value.days) || 0) * 86400 + (Number(value.hours) || 0) * 3600 + (Number(value.minutes) || 0) * 60 + (Number(value.seconds) || 0)
    )
  );
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor(totalSeconds % 3600 / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((part) => String(part).padStart(2, "0")).join(":");
}
function durationInput(value, onChange, hass, label) {
  if (hass) {
    return b2`<ha-selector
      class="nc-duration-input"
      .hass=${hass}
      .selector=${{ duration: { enable_day: true, enable_second: true } }}
      .value=${value}
      .label=${label || void 0}
      aria-label=${localize(hass, "editor.common.duration")}
      @value-changed=${(event) => {
      onChange(
        durationInputValue(
          event.detail.value,
          value
        )
      );
    }}
    ></ha-selector>`;
  }
  const normalize = (raw) => {
    const parts = raw.replace(/[^\d:]/g, "").split(":");
    const seconds = Number(parts.pop() || 0);
    const minutes = Number(parts.pop() || 0);
    const hours = Number(parts.join("") || 0);
    return `${hours}:${String(Math.min(minutes, 59)).padStart(2, "0")}:${String(
      Math.min(seconds, 59)
    ).padStart(2, "0")}`;
  };
  const update = (event) => {
    const input = event.currentTarget;
    onChange(input.value);
  };
  const commit = (event) => {
    const input = event.currentTarget;
    onChange(normalize(input.value));
  };
  return b2`<ha-input
    class="nc-duration-input"
    type="text"
    inputmode="numeric"
    placeholder="HH:MM:SS"
    aria-label=${localize(hass, "editor.common.duration_format")}
    .value=${value}
    @input=${update}
    @blur=${commit}
    @change=${commit}
  ></ha-input>`;
}
async function fillActionEditors(host) {
  await customElements.whenDefined("ha-code-editor");
  const editors = Array.from(
    host.querySelectorAll("ha-code-editor.nc-action-editor")
  );
  for (const editor of editors) {
    await editor.updateComplete;
    constrainCodeEditor(editor, "280px");
  }
}
function constrainCodeEditor(editor, height = "var(--nc-code-editor-height)") {
  const codeMirror = editor.codemirror?.dom;
  if (!codeMirror || !editor.isConnected) return;
  if (height) editor.style.height = height;
  codeMirror.style.height = "100%";
  const scroller = codeMirror.querySelector(
    ".cm-scroller"
  );
  if (scroller) scroller.style.height = "100%";
}
function field(label, content = b2``, full = false) {
  let className = "nc-field";
  if (full) {
    className = "nc-field full";
  }
  return b2`<div class=${className}><label>${label}</label>${content}</div>`;
}
function codeEditor({
  role,
  value,
  placeholder = "",
  mode,
  language,
  label,
  className = "nc-action-editor",
  readOnly = false,
  onInput,
  onReady
}) {
  return b2`<ha-code-editor
    data-role=${role || A}
    .value=${value}
    placeholder=${placeholder || A}
    class=${`nc-code-editor ${className}`}
    mode=${mode}
    language=${language}
    aria-label=${label}
    ?read-only=${readOnly}
    @input=${onInput || A}
    @value-changed=${onInput || A}
    ${n5((element) => {
    if (element) onReady?.(element);
  })}
  ></ha-code-editor>`;
}
function actionSection({
  context,
  title,
  help,
  role,
  actions
}) {
  return section(
    title,
    b2`<div class="nc-help">${help}</div>
      ${codeEditor({
      role,
      value: actionsYaml(actions),
      placeholder: ACTIONS_PLACEHOLDER,
      mode: "yaml",
      language: "yaml",
      label: title,
      onInput: () => context.markDirty(),
      onReady: (editor) => context.setEditorControl(role, editor)
    })}`,
    "",
    context.activeSection === title
  );
}
function section(title, content, className = "", active = false) {
  return b2`<section
    class="nc-section ${className}${active ? " active" : ""}"
    data-title=${title}
  >
    <div class="nc-section-content">${content}</div>
  </section>`;
}
function optionalControls(context, enabled, label, onToggle, disabled = false) {
  const title = enabled ? `${context.localize("alert.disable")} ${label}` : `${context.localize("alert.enable")} ${label}`;
  return b2`<div class="nc-setting-controls">
    <ha-switch
      .checked=${enabled}
      ?disabled=${disabled}
      aria-label=${title}
      title=${title}
      @change=${(event) => onToggle(checkedOf(event))}
    ></ha-switch>
  </div>`;
}
function editorSectionControl(setting, content, visible = false) {
  return b2`<div
    data-role="editor-section-control"
    data-setting=${setting}
    ?hidden=${!visible}
  >
    ${content}
  </div>`;
}
function enabledLabel(enabled) {
  return enabled ? "Enabled" : "Disabled";
}
function showYaml(root, alert) {
  root.dispatchEvent(
    new CustomEvent("nc-editor-modal", {
      detail: { kind: "yaml", alert }
    })
  );
}
function showTemplateHelp(event, title, content) {
  const trigger = event.currentTarget;
  const root = trigger?.getRootNode();
  if (!(root instanceof ShadowRoot)) return;
  root.dispatchEvent(
    new CustomEvent("nc-editor-modal", {
      detail: {
        kind: "template-help",
        title,
        content,
        modalClass: "nc-template-help-modal",
        closeLabel: "Close template help"
      }
    })
  );
}
function actionArrayValue(editor, label) {
  let parsed;
  try {
    parsed = parse(editor?.value || "[]");
  } catch {
    throw new Error(
      `${label} must be a valid YAML list of action objects. Example: - action: switch.turn_on`
    );
  }
  if (!Array.isArray(parsed) || !parsed.every((item) => item && typeof item === "object")) {
    throw new Error(`${label} must be a YAML list of action objects.`);
  }
  return parsed;
}

// frontend/toast.ts
var nextToastId = 0;
function showToast(host, message, error = false, duration = 3500) {
  const toast = { id: ++nextToastId, message, error };
  host.toasts = [...host.toasts, toast];
  host.requestUpdate();
  window.setTimeout(() => {
    host.toasts = host.toasts.filter((item) => item.id !== toast.id);
    host.requestUpdate();
  }, duration);
}
function toastListTemplate(toasts) {
  return b2`<div class="nc-toast-list">
    ${toasts.map(
    (toast) => b2`<div class=${toast.error ? "nc-toast error" : "nc-toast"}>
          ${toast.message}
        </div>`
  )}
  </div>`;
}

// frontend/editor/payload.ts
function buildEditorPayload(input) {
  const {
    alert,
    condition,
    recipients,
    evaluateInterval,
    confirmationActions,
    postSendActions,
    postSendActionsEnabled,
    postConfirmationActionsEnabled,
    validate = true
  } = input;
  const confirmation = alert.confirmation;
  const values = {
    identity: {
      name: alert.name,
      description: alert.description || "",
      icon: alert.icon
    },
    evaluate: {
      condition,
      onChange: alert.monitor?.on_change !== false,
      startup: alert.monitor?.startup !== false,
      interval: evaluateInterval,
      clearOnInactive: alert.monitor?.clear_on_inactive === true
    },
    notification: {
      target: recipients,
      title: String(alert.notification.data.title || ""),
      message: String(alert.notification.data.message || "")
    },
    confirmation: {
      enabled: Boolean(confirmation.enabled),
      buttons: confirmation.buttons,
      notification: {
        enabled: Boolean(confirmation.notification),
        message: String(confirmation.notification.data.message || ""),
        clear: true
      },
      reminders: {
        enabled: confirmation.reminders.enabled,
        interval: durationInputValue(
          confirmation.reminders.interval,
          "00:30:00"
        ),
        max_attempts: confirmation.reminders.max_attempts,
        show_attempts: confirmation.reminders.show_attempts === true,
        forget_after_enabled: confirmation.reminders.forget_after_enabled === true,
        timeout: durationInputValue(confirmation.reminders.timeout, "00:15:00")
      },
      actions: {
        enabled: postConfirmationActionsEnabled,
        items: confirmationActions
      }
    },
    post_send_actions: {
      postSendActionsEnabled,
      actions: postSendActions
    }
  };
  return buildAlertPayload(alert, values, validate);
}

// frontend/editor/navigation.ts
function statusEnabled(alert, status) {
  if (status === "postSendActions") {
    return Boolean(alert.post_send_actions?.enabled);
  }
  if (status === "confirmation") {
    return Boolean(alert.confirmation?.enabled);
  }
  if (status === "postConfirmationActions") {
    return Boolean(
      alert.confirmation?.enabled && alert.confirmation.actions.length > 0
    );
  }
  if (status === "confirmationReminder") {
    return Boolean(
      alert.confirmation?.enabled && alert.confirmation.reminders.enabled
    );
  }
  return Boolean(
    alert.confirmation?.enabled && Boolean(alert.confirmation.notification)
  );
}
function statusTemplate(alert, status) {
  if (!status) {
    return A;
  }
  const enabled = statusEnabled(alert, status);
  return b2`<span
    class=${`nc-section-status${enabled ? " active" : ""}`}
    data-status=${status}
    aria-label=${enabledLabel(enabled)}
    >${enabled ? "\u2713" : "\xD7"}</span
  >`;
}
function buttonClass(setting, parent, index, activeIndex) {
  const classes = ["nc-section-nav-button"];
  if (setting) {
    classes.push("nc-optional-setting");
  }
  if (parent) {
    classes.push("nc-section-nav-child");
  }
  if (index === activeIndex) {
    classes.push("active");
  }
  return classes.join(" ");
}
function collapseButton(hasChildren, title, collapsedParents, onToggleChildren) {
  if (!hasChildren) {
    return A;
  }
  const collapsed = collapsedParents.has(title);
  const action = collapsed ? "Expand" : "Collapse";
  const icon = collapsed ? "mdi:chevron-right" : "mdi:chevron-down";
  const label = `${action} ${title} subpanels`;
  return b2`<button
    class="nc-section-collapse-button"
    type="button"
    aria-label=${label}
    title=${label}
    aria-expanded=${String(!collapsed)}
    data-collapse-parent=${title}
    @click=${() => onToggleChildren(title)}
  >
    <ha-icon icon=${icon}></ha-icon>
  </button>`;
}
function renderEditorNavigation({
  localize: localize2,
  alert,
  className,
  optionalSettings,
  activeIndex,
  mobileOpen,
  collapsedParents,
  onMobileMenuReady,
  onSelect,
  onToggleChildren
}) {
  const isMobile = className.includes("mobile");
  return b2`<nav
    ${isMobile ? n5((element) => {
    if (element) onMobileMenuReady(element);
  }) : A}
    class=${`${className}${mobileOpen ? " mobile-open" : ""}`}
    aria-label=${localize2("editor.common.alert_sections")}
  >
    ${editorSections.map((section2, index) => {
    const { title, setting, parent, status } = section2;
    const hasChildren = editorSections.some(
      (candidate) => candidate.parent === title
    );
    return b2`<div
        class="nc-section-nav-row"
        data-setting=${setting || A}
        data-parent=${parent || A}
        ?hidden=${!isSectionVisible(setting, optionalSettings) || parent === "Confirmation" && !optionalSettings.confirmation}
      >
        <button
          class=${buttonClass(setting, parent, index, activeIndex)}
          aria-current=${index === activeIndex ? "step" : A}
          @click=${() => onSelect(index)}
        >
          ${statusTemplate(alert, status)}
          <span>${localizeEditorTitle(localize2, title)}</span>
        </button>
        ${collapseButton(
      hasChildren,
      title,
      collapsedParents,
      onToggleChildren
    )}
      </div>`;
  })}
  </nav>`;
}

// frontend/sections/basic.ts
function renderBasicSection(context) {
  const { value } = context;
  return section(
    context.localize("editor.basic.section"),
    b2`<div class="nc-grid">
      ${field(
      context.localize("editor.basic.name"),
      b2`<ha-input
          type="text"
          .value=${value.name}
          placeholder=${context.localize("editor.basic.alert_name")}
          @input=${(event) => {
        value.name = valueOf(event);
        context.markDirty();
        context.refreshStatuses();
      }}
        ></ha-input>`
    )}
      ${field(
      context.localize("editor.basic.description"),
      b2`<ha-selector
          class="nc-description-input"
          .hass=${context.hass}
          .selector=${{ text: { multiline: true } }}
          aria-label=${context.localize("editor.basic.description")}
          .value=${value.description}
          @value-changed=${(event) => {
        value.description = event.detail.value || "";
        context.markDirty();
        context.refreshStatuses();
      }}
        ></ha-selector>`,
      true
    )}
      ${field(
      context.localize("editor.basic.icon"),
      b2`<ha-icon-picker
          .value=${value.icon || "mdi:bell-outline"}
          aria-label=${context.localize("editor.basic.icon")}
          @value-changed=${(event) => {
        value.icon = event.detail.value;
        context.markDirty();
      }}
        ></ha-icon-picker>`
    )}
    </div>`,
    "",
    context.activeSection === "Basic"
  );
}

// frontend/sections/condition.ts
function renderConditionSection(context) {
  return section(
    context.localize("editor.condition.section"),
    b2`<div ${n5((element) => element && context.setEditorElement("conditions-yaml", element))} data-role="conditions-yaml">
        ${field(
      context.localize("editor.condition.conditions_yaml"),
      codeEditor({
        role: "conditions-yaml-editor",
        value: conditionYaml(context.value.conditions),
        mode: "yaml",
        language: "yaml",
        label: context.localize("editor.condition.conditions_yaml"),
        onInput: () => context.markDirty(),
        onReady: (editor) => context.setEditorControl("conditions-yaml", editor)
      }),
      true
    )}
        <div class="nc-help">
          ${context.localize("editor.condition.conditions_help")}
        </div>
      </div>
      `,
    "",
    context.activeSection === "Condition"
  );
}

// frontend/sections/confirmation.ts
function renderConfirmationSection(context) {
  const confirmation = context.value.confirmation;
  const buttons = confirmation.buttons;
  const updateButtons = (next) => {
    confirmation.buttons = next;
    context.markDirty();
    context.refreshStatuses();
  };
  return section(
    context.localize("editor.confirmation.section"),
    b2`<div class="nc-grid">
        ${buttons.map(
      (button, index) => b2`<div class="nc-confirmation-button-row">
            ${field(
        context.localize("editor.confirmation.button_id_optional"),
        b2`<ha-input
                type="text"
                .value=${button.id || ""}
                placeholder="acknowledge"
                @input=${(event) => {
          const value = valueOf(event).trim();
          button.id = value || void 0;
          context.markDirty();
        }}
              ></ha-input>`
      )}
            ${field(
        context.localize("editor.confirmation.button_label"),
        b2`<ha-input
                type="text"
                .value=${button.label}
                placeholder="Activity completed"
                @input=${(event) => {
          button.label = valueOf(event);
          context.markDirty();
        }}
              ></ha-input>`
      )}
            ${index > 0 ? b2`<button
                  class="nc-button danger"
                  type="button"
                  @click=${() => updateButtons(buttons.filter((_2, itemIndex) => itemIndex !== index))}
                >${context.localize("editor.confirmation.remove_button")}</button>` : ""}
          </div>`
    )}
        <button
          class="nc-button secondary nc-confirmation-add-button"
          type="button"
          @click=${() => updateButtons([
      ...buttons,
      { label: "" }
    ])}
        >${context.localize("editor.confirmation.add_response")}</button>
      </div>
      <label class="nc-switch-label nc-confirmation-clear">
        <ha-switch
          .checked=${true}
          @change=${(event) => {
      confirmation.notification.data.clear = checkedOf(event);
      context.markDirty();
    }}
        ></ha-switch>
        <span>${context.localize("editor.confirmation.clear_on_acknowledge")}</span>
      </label>`,
    "",
    context.activeSection === "Confirmation"
  );
}

// frontend/sections/confirmation-notification.ts
function renderConfirmationNotificationSection(context) {
  const confirmation = context.value.confirmation;
  return section(
    context.localize("editor.confirmation.notification.section"),
    b2`${codeEditor({
      value: String(confirmation.notification.data.message || ""),
      placeholder: "",
      mode: "jinja2",
      language: "jinja",
      label: context.localize("editor.confirmation.message"),
      onInput: (event) => {
        confirmation.notification.data.message = event.currentTarget.value;
        context.markDirty();
      }
    })}
      <div class="nc-help">
        ${context.localize("editor.confirmation.notification.follow_up_help")}
      </div>
      <div class="nc-help">
        ${context.localize("editor.confirmation.notification.example")} <code>Confirmed by {{confirmed_by}}</code>
      </div>
      <div class="nc-template-help-trigger">
        <span>${context.localize("editor.notification.template_help")}</span>
        <button
          class="nc-icon-button"
          type="button"
          aria-label=${context.localize("editor.notification.show_template_help")}
          title=${context.localize("editor.notification.show_template_help")}
          @click=${(event) => showTemplateHelp(
      event,
      context.localize("editor.notification.template_help"),
      b2`<div class="nc-help">
          <code>confirmed_by</code>, <code>confirmation_response_id</code>,
          <code>confirmation_response</code>, <code>alert_id</code>,
          <code>alert_name</code>, <code>alert_active</code>,
          <code>trigger</code>, <code>attempt</code>, and <code>now</code> are
          available. Home
          Assistant helpers also work, for example
          <code>states('sensor.temperature')</code>,
          <code>state_attr('light.kitchen', 'brightness')</code>, and
          <code>is_state('binary_sensor.door', 'on')</code>.
        </div>`
    )}
        >
          <ha-icon icon="mdi:information-outline"></ha-icon>
        </button>
      </div>
      `,
    "",
    context.activeSection === "Notify recipients when confirmed"
  );
}

// frontend/sections/confirmation-reminder.ts
function renderConfirmationReminderSection(context) {
  const confirmation = context.value.confirmation;
  return section(
    context.localize("editor.confirmation.reminder.section"),
    b2`<div class="nc-grid">
        ${field(
      context.localize("editor.confirmation.reminder.remind_every"),
      durationInput(
        durationInputValue(confirmation.reminders.interval, "00:30:00"),
        (next) => {
          confirmation.reminders.interval = next;
          context.markDirty();
        },
        context.hass
      )
    )}
        ${field(
      context.localize("editor.confirmation.reminder.maximum"),
      b2`<ha-input
            class="nc-number-field"
            type="number"
            min="1"
            max="20"
            .value=${String(confirmation.reminders.max_attempts || 5)}
            @input=${(event) => {
        confirmation.reminders.max_attempts = Math.min(
          20,
          Math.max(1, Number(valueOf(event)) || 5)
        );
        context.markDirty();
      }}
          ></ha-input>`
    )}
        ${field(
      context.localize("editor.confirmation.reminder.forget_after"),
      durationInput(
        durationInputValue(confirmation.reminders.timeout, "00:15:00"),
        (next) => {
          confirmation.reminders.timeout = next;
          context.markDirty();
        },
        context.hass
      )
    )}
      </div>
      <div class="nc-help">${context.localize("editor.confirmation.reminder.keep_until")}</div>
      <div class="nc-reminder-options">
        <label class="nc-switch-label">
          <ha-switch
            .checked=${confirmation.reminders.forget_after_enabled === true}
            @change=${(event) => {
      confirmation.reminders.forget_after_enabled = checkedOf(event);
      context.markDirty();
    }}
          ></ha-switch>
          <span>${context.localize("editor.confirmation.reminder.enable_forget_after")}</span>
        </label>
        <label class="nc-switch-label">
          <ha-switch
            .checked=${confirmation.reminders.show_attempts === true}
            @change=${(event) => {
      confirmation.reminders.show_attempts = checkedOf(event);
      context.markDirty();
    }}
          ></ha-switch>
          <span>${context.localize("editor.confirmation.reminder.show_attempt_count")}</span>
        </label>
      </div>
      </div>`,
    "",
    context.activeSection === "Reminder policy"
  );
}

// frontend/sections/evaluate.ts
function renderEvaluateSection(context) {
  const monitor = context.value.monitor || (context.value.monitor = {});
  return section(
    context.localize("editor.evaluate.section"),
    b2`<div class="nc-evaluate-settings">
      <div class="nc-evaluate-toggles">
        <label class="nc-evaluate-toggle">
          <ha-switch
            .checked=${monitor.on_change !== false}
            @change=${(event) => {
      monitor.on_change = checkedOf(event);
      context.markDirty();
      context.refreshStatuses();
    }}
          ></ha-switch>
          <span
            >${context.localize("editor.evaluate.when_condition_changes")}</span
          >
        </label>
        <label class="nc-evaluate-toggle">
          <ha-switch
            .checked=${monitor.clear_on_inactive === true}
            @change=${(event) => {
      monitor.clear_on_inactive = checkedOf(event);
      context.markDirty();
      context.refreshStatuses();
    }}
          ></ha-switch>
          <span
            >${context.localize("editor.evaluate.clear_when_inactive")}</span
          >
        </label>
        <label class="nc-evaluate-toggle">
          <ha-switch
            .checked=${monitor.startup !== false}
            @change=${(event) => {
      monitor.startup = checkedOf(event);
      context.markDirty();
      context.refreshStatuses();
    }}
          ></ha-switch>
          <span>${context.localize("editor.evaluate.check_startup")}</span>
        </label>
      </div>
        <div class="nc-help nc-evaluate-help">
          ${context.localize("editor.evaluate.condition_change_help")}
        </div>
      ${field(
      b2`<span class="nc-field-heading">
          <ha-switch
            data-role="interval-toggle"
            .checked=${Boolean(monitor.interval)}
            @change=${(event) => {
        const currentInterval = monitor.interval;
        monitor.interval = void 0;
        if (checkedOf(event)) {
          monitor.interval = currentInterval || "12:00:00";
        }
        context.markDirty();
        context.refreshStatuses();
      }}
          ></ha-switch>
          ${context.localize("editor.evaluate.re_evaluate_every")}
        </span>`,
      b2`<div class="nc-help nc-evaluate-help">
            ${context.localize("editor.evaluate.interval_help")}
          </div>
          ${durationInput(
        durationInputValue(monitor.interval, "12:00:00"),
        (next) => {
          monitor.interval = next;
          context.markDirty();
        },
        context.hass
      )}`
    )}
    </div>`,
    "",
    context.activeSection === "When to check"
  );
}

// frontend/sections/notification.ts
function renderNotificationSection(context) {
  const notification = context.value.notification;
  return section(
    context.localize("editor.notification.section"),
    b2`<div class="nc-grid">
        ${field(
      context.localize("editor.notification.title"),
      b2`<ha-input
            type="text"
            .value=${String(notification.data.title || "")}
            placeholder=${context.localize("editor.notification.title_placeholder")}
            @input=${(event) => {
        notification.data.title = valueOf(event);
        context.markDirty();
        context.refreshStatuses();
      }}
          ></ha-input>`
    )}
        ${field(
      context.localize("editor.notification.message"),
      codeEditor({
        value: String(notification.data.message || ""),
        placeholder: context.localize("editor.notification.message_placeholder"),
        mode: "jinja2",
        language: "jinja",
        label: context.localize("editor.notification.message_placeholder"),
        onInput: (event) => {
          notification.data.message = event.currentTarget.value;
          context.markDirty();
          context.refreshStatuses();
        }
      }),
      true
    )}
      </div>
      <div class="nc-template-help-trigger">
        <span>${context.localize("editor.notification.template_help")}</span>
        <button
          class="nc-icon-button"
          type="button"
          aria-label=${context.localize("editor.notification.show_template_help")}
          title=${context.localize("editor.notification.show_template_help")}
          @click=${(event) => showTemplateHelp(
      event,
      context.localize("editor.notification.templates_help"),
      b2`<div class="nc-help">
          Recipients on selected devices, areas, floors, and labels receive
          direct notifications through Home Assistant's standard Notify
          service. Give conditions an ID in the Condition view, then use that
          ID in the message or title to choose text. For example:
          <code>{% if condition.front_door %}Door open{% elif
            condition.garage %}Garage open{% else %}All clear{% endif %}</code>.
        </div>
        <div class="nc-help">
          <code>alert_id</code>, <code>alert_name</code>,
          <code>alert_active</code>, <code>attempt</code>,
          <code>trigger</code>, <code>now</code>, and
          <code>condition.&lt;id&gt;</code> are available here. Home Assistant
          helpers are also available, such as
          <code>states('sensor.temperature')</code>,
          <code>state_attr('light.kitchen', 'brightness')</code>, and
          <code>is_state('binary_sensor.door', 'on')</code>.
        </div>`
    )}
        >
          <ha-icon icon="mdi:information-outline"></ha-icon>
        </button>
      </div>`,
    "",
    context.activeSection === "Notification"
  );
}

// frontend/sections/post-confirmation-actions.ts
function renderPostConfirmationActionsSection(context) {
  return actionSection({
    context,
    title: context.localize("editor.confirmation.actions.section"),
    help: context.localize("editor.confirmation.actions.help"),
    role: "post-confirmation-actions",
    actions: context.value.confirmation?.actions
  });
}

// frontend/sections/post-send-actions.ts
function renderPostSendActionsSection(context) {
  const postSendActions = context.value.post_send_actions;
  return actionSection({
    context,
    title: context.localize("editor.notification.post_send_actions"),
    help: context.localize("editor.notification.post_send_help"),
    role: "post-send-actions",
    actions: postSendActions?.actions
  });
}

// frontend/sections/recipients.ts
function renderRecipientSection(context) {
  return section(
    context.localize("editor.recipients.section"),
    b2`<div ${n5((element) => context.setEditorElement("recipients", element))} data-role="recipients"></div>
      <div class="nc-help">
        ${context.localize("editor.recipients.help")}
      </div>
      <div class="nc-help">
        ${context.localize("editor.recipients.service_help")}
      </div>`,
    "nc-section-recipient",
    context.activeSection === "Recipients"
  );
}

// frontend/editor/sections.ts
function renderEditorSections(context, optionalSettings) {
  return b2`${renderBasicSection(context)}${renderEvaluateSection(
    context
  )}${renderConditionSection(context)}${renderRecipientSection(
    context
  )}${renderNotificationSection(context)}
    <div
      class="nc-optional-setting"
      data-setting="postSendActions"
      ?hidden=${!optionalSettings.postSendActions}
    >
      ${renderPostSendActionsSection(context)}
    </div>
    <div
      class="nc-optional-setting"
      data-setting="confirmation"
      ?hidden=${!optionalSettings.confirmation}
    >
      ${renderConfirmationSection(context)}
    </div>
    <div
      class="nc-optional-setting"
      data-setting="confirmationReminder"
      ?hidden=${!optionalSettings.confirmationReminder || !optionalSettings.confirmation}
    >
      ${renderConfirmationReminderSection(context)}
    </div>
    <div
      class="nc-optional-setting"
      data-setting="confirmationNotification"
      ?hidden=${!optionalSettings.confirmationNotification || !optionalSettings.confirmation}
    >
      ${renderConfirmationNotificationSection(context)}
    </div>
    <div
      class="nc-optional-setting"
      data-setting="postConfirmationActions"
      ?hidden=${!optionalSettings.postConfirmationActions}
    >
      ${renderPostConfirmationActionsSection(context)}
    </div>`;
}

// frontend/editor/footer.ts
function renderEditorFooter({
  onYamlView,
  onClose,
  validationLabel,
  onValidate,
  onSave,
  localize: localize2
}) {
  return b2`<footer class="nc-modal-footer">
    <span class="nc-editor-state" aria-live="polite"></span>
    <button
      class="nc-icon-button"
      type="button"
      aria-label=${localize2("editor.common.view_yaml")}
      title=${localize2("editor.common.view_yaml")}
      aria-expanded="false"
      @click=${onYamlView}
    >
      <ha-icon icon="mdi:code-braces"></ha-icon>
    </button>
    <button class="nc-button secondary" @click=${onClose}>
      ${localize2("editor.common.cancel")}
    </button>
    <button
      class="nc-button secondary"
      data-role="editor-validate"
      @click=${onValidate}
      ?hidden=${!validationLabel}
      aria-label=${validationLabel}
    >${validationLabel}</button>
    <button class="nc-button" @click=${onSave}>${localize2("editor.common.save_alert")}</button>
  </footer>`;
}

// frontend/editor/header.ts
function renderEditorHeader({
  alert,
  context,
  optionalSettings,
  postConfirmationActionsEnabled,
  activeSectionIndex,
  sectionTitle,
  mobileSectionsOpen,
  onToggleSetting,
  onToggleMobileSections,
  onSectionManageButton,
  renderNavigation
}) {
  return b2`<header class="nc-editor-header">
    <div class="nc-editor-identity">
      <div class="nc-editor-title-row">
        <h1 data-role="editor-alert-name">${alert.name.trim() || context.localize("editor.common.new_alert")}</h1>
        <span class="nc-editor-title-separator" aria-hidden="true">/</span>
        <h2 data-role="editor-section-title">${localizeEditorTitle(context.localize, sectionTitle)}</h2>
      </div>
    </div>
    <div class="nc-editor-section-controls">
      ${editorSectionControl(
    "postSendActions",
    optionalControls(
      context,
      Boolean(alert.post_send_actions?.enabled),
      context.localize("editor.notification.post_send_actions"),
      (enabled) => onToggleSetting("postSendActions", enabled)
    ),
    activeSectionIndex === 5
  )}
      ${editorSectionControl(
    "confirmation",
    optionalControls(
      context,
      Boolean(alert.confirmation?.enabled),
      context.localize("editor.confirmation.toggle"),
      (enabled) => onToggleSetting("confirmation", enabled)
    ),
    activeSectionIndex === 6
  )}
      ${editorSectionControl(
    "confirmationReminder",
    optionalControls(
      context,
      alert.confirmation?.reminders.enabled !== false,
      context.localize("editor.confirmation.reminder.section"),
      (enabled) => onToggleSetting("confirmationReminder", enabled)
    ),
    activeSectionIndex === 7
  )}
      ${editorSectionControl(
    "confirmationNotification",
    optionalControls(
      context,
      Boolean(alert.confirmation?.notification),
      context.localize("editor.confirmation.notification.section"),
      (enabled) => onToggleSetting("confirmationNotification", enabled)
    ),
    activeSectionIndex === 8
  )}
      ${editorSectionControl(
    "postConfirmationActions",
    optionalControls(
      context,
      postConfirmationActionsEnabled,
      context.localize("editor.confirmation.actions.section"),
      (enabled) => onToggleSetting("postConfirmationActions", enabled)
    ),
    activeSectionIndex === 9
  )}
    </div>
    <button
      ${n5((element) => {
    if (element) onSectionManageButton(element);
  })}
      class="nc-button secondary nc-section-manage-button"
      data-role="section-manage"
      type="button"
      aria-expanded=${String(mobileSectionsOpen)}
        aria-label=${mobileSectionsOpen ? context.localize("editor.common.close_sections") : context.localize("editor.common.manage_sections")}
      title=${mobileSectionsOpen ? context.localize("editor.common.close_sections") : context.localize("editor.common.manage_sections")}
      @click=${onToggleMobileSections}
    >
      <ha-icon icon="mdi:menu"></ha-icon>
    </button>
    ${renderNavigation("nc-section-header nc-mobile-section-menu")}
  </header>`;
}

// frontend/editor/modals.ts
function renderEditorModal(modal, onClose) {
  if (!modal) return A;
  return b2`<div
      class="nc-modal-backdrop"
      @click=${(event) => {
    if (event.target === event.currentTarget) onClose();
  }}
    >
      <section class=${`nc-modal ${modal.modalClass}`} role="dialog" aria-modal="true">
        <header class="nc-modal-header">
          <h2>${modal.title}</h2>
          <button class="nc-icon-button" @click=${onClose} aria-label=${modal.closeLabel} title=${modal.closeLabel}>
            <ha-icon icon="mdi:close"></ha-icon>
          </button>
        </header>
        <main class="nc-modal-body">${modal.content}</main>
      </section>
    </div>`;
}
function renderDiscardDialog(open, localize2, onClose, onDiscard) {
  if (!open) return A;
  return b2`<div
      class="nc-modal-backdrop"
      role="presentation"
      @click=${(event) => {
    if (event.target === event.currentTarget) onClose();
  }}
    >
      <section
        class="nc-modal nc-discard-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="nc-discard-title"
      >
        <header class="nc-modal-header">
          <h2 id="nc-discard-title">${localize2("editor.common.discard_title")}</h2>
        </header>
        <main class="nc-modal-body">
          <p>${localize2("editor.common.discard_message")}</p>
        </main>
        <footer class="nc-modal-footer">
          <button class="nc-button secondary" @click=${onClose}>
            ${localize2("editor.common.stay")}
          </button>
          <button class="nc-button" @click=${onDiscard}>
            ${localize2("editor.common.discard")}
          </button>
        </footer>
      </section>
    </div>`;
}

// frontend/editor/state.ts
function createEditorState() {
  return {
    dirty: false,
    discardDialogOpen: false,
    activeSectionIndex: 0,
    mobileSectionsOpen: false,
    toasts: [],
    modal: null
  };
}

// frontend/editor/context.ts
function createEditorContext({
  hass,
  value,
  elements,
  markDirty,
  refreshStatuses,
  setMode,
  validateCondition,
  validateActions
}) {
  return {
    hass,
    localize: createLocalizer(hass),
    value,
    mode: editorModeFor(value),
    activeSection: editorSections[0].title,
    setEditorElement: (role, element) => {
      if (role === "conditions-yaml") elements.conditionsYamlView = element;
      if (role === "recipients") elements.recipientMount = element;
    },
    setEditorControl: (role, element) => {
      if (role === "conditions-yaml") elements.conditionsYamlEditor = element;
      if (role === "post-confirmation-actions") {
        elements.postConfirmationActionsEditor = element;
      }
      if (role === "post-send-actions") {
        elements.postSendActionsEditor = element;
      }
    },
    markDirty,
    refreshStatuses,
    setMode,
    validateCondition,
    validateActions
  };
}

// frontend/editor/index.ts
var AlertEditorController = class {
  root;
  registries;
  onSave;
  onSaved;
  onClosed;
  onValidateCondition;
  value;
  host = document.createElement("div");
  context;
  optionalSettings;
  collapsedParents = /* @__PURE__ */ new Set();
  elements = {};
  state = createEditorState();
  postConfirmationActionsEnabled = false;
  handleOutsideSectionPointer = (event) => {
    if (!this.state.mobileSectionsOpen) return;
    const path = event.composedPath();
    if (this.elements.mobileMenu && path.includes(this.elements.mobileMenu)) return;
    if (this.elements.sectionManageButton && path.includes(this.elements.sectionManageButton)) return;
    this.closeMobileSections();
  };
  recipients;
  constructor(options) {
    this.root = options.root;
    this.registries = options.registries;
    this.onSave = options.onSave;
    this.onSaved = options.onSaved;
    this.onClosed = options.onClosed;
    this.onValidateCondition = options.onValidateCondition;
    this.value = clone(options.alert || defaultAlert());
    this.value.confirmation = {
      enabled: false,
      buttons: [{ id: "confirm", label: "Done" }],
      notification: { enabled: false, message: "", clear: true },
      reminders: {
        enabled: true,
        interval: "00:30:00",
        max_attempts: 5,
        show_attempts: false,
        forget_after_enabled: false,
        timeout: "00:15:00"
      },
      actions: { enabled: false, items: [] },
      ...this.value.confirmation
    };
    this.postConfirmationActionsEnabled = Boolean(
      this.value.confirmation.actions.length
    );
    this.root.addEventListener("nc-editor-toast", this.handleToastEvent);
    this.root.addEventListener("nc-editor-modal", this.handleModalEvent);
    this.context = createEditorContext({
      hass: options.hass,
      value: this.value,
      elements: this.elements,
      markDirty: this.markDirty,
      refreshStatuses: this.refreshStatuses,
      setMode: this.setMode,
      validateCondition: this.validateCondition,
      validateActions: this.validateActions
    });
    this.optionalSettings = {
      confirmation: true,
      confirmationReminder: true,
      confirmationNotification: true,
      postSendActions: true,
      postConfirmationActions: true
    };
    this.renderEditor();
    this.root.append(this.host);
    document.addEventListener("pointerdown", this.handleOutsideSectionPointer);
    void fillActionEditors(this.host);
    this.recipients = createRecipientPicker(
      this.registries,
      this.value.notification.target,
      this.context.markDirty,
      this.context.hass
    );
    D(b2`${this.recipients.element}`, this.elements.recipientMount);
    this.showSection(0);
  }
  handleToastEvent = (event) => {
    const detail = event.detail;
    const toast = { id: Date.now(), message: detail.message, error: false };
    this.state.toasts = [...this.state.toasts, toast];
    this.renderEditor();
    window.setTimeout(() => {
      this.state.toasts = this.state.toasts.filter((item) => item.id !== toast.id);
      this.renderEditor();
    }, detail.duration);
  };
  handleModalEvent = (event) => {
    const detail = event.detail;
    if (detail.kind === "yaml" && detail.alert) {
      this.state.modal = {
        title: localize(this.context.hass, "editor.common.alert_yaml"),
        content: b2`<ha-code-editor
          class="nc-code-editor nc-alert-yaml-editor"
          mode="yaml"
          language="yaml"
            aria-label=${localize(this.context.hass, "editor.common.alert_yaml")}
          .value=${""}
          ${n5((element) => {
          if (element) this.elements.yamlModalEditor = element;
        })}
        ></ha-code-editor>`,
        modalClass: "nc-alert-yaml-modal",
        closeLabel: localize(this.context.hass, "editor.common.close_yaml"),
        yaml: detail.alert
      };
    } else if (detail.title && detail.content) {
      this.state.modal = {
        title: detail.title,
        content: detail.content,
        modalClass: detail.modalClass || "",
        closeLabel: detail.closeLabel || localize(this.context.hass, "editor.common.close")
      };
    }
    this.renderEditor();
    if (this.state.modal?.yaml) void this.prepareYamlModal(this.state.modal.yaml);
  };
  async prepareYamlModal(alert) {
    await customElements.whenDefined("ha-code-editor");
    await this.elements.yamlModalEditor?.updateComplete;
    if (!this.elements.yamlModalEditor) return;
    constrainCodeEditor(this.elements.yamlModalEditor);
    this.elements.yamlModalEditor.value = stringify3(alert);
  }
  closeModal = () => {
    this.state.modal = null;
    this.elements.yamlModalEditor = void 0;
    this.renderEditor();
  };
  renderEditor = () => {
    const optionalSettings = this.optionalSettings;
    const context = this.context;
    D(
      b2`<div class="nc-editor-view">
        <section class="nc-editor-shell">
          ${renderEditorHeader({
        alert: this.value,
        context,
        optionalSettings,
        postConfirmationActionsEnabled: this.postConfirmationActionsEnabled,
        activeSectionIndex: this.state.activeSectionIndex,
        sectionTitle: this.sectionLabel(
          editorSections[this.state.activeSectionIndex]?.parent,
          editorSections[this.state.activeSectionIndex]?.title || ""
        ),
        mobileSectionsOpen: this.state.mobileSectionsOpen,
        onToggleSetting: this.toggleOptionalSetting,
        onToggleMobileSections: this.toggleMobileSections,
        onSectionManageButton: (element) => {
          this.elements.sectionManageButton = element;
        },
        renderNavigation: this.renderNavigation
      })}
          <main class="nc-modal-body">
            <div class="nc-editor-layout">
              ${this.renderNavigation()}
              <div class="nc-editor-sections">
                ${renderEditorSections(context, optionalSettings)}
              </div>
            </div>
          </main>
          ${renderEditorFooter({
        localize: this.context.localize,
        onYamlView: this.yamlView,
        onClose: this.close,
        validationLabel: this.validationLabel(),
        onValidate: this.validateCurrentSection,
        onSave: this.save
      })}
        </section>
        ${renderDiscardDialog(
        this.state.discardDialogOpen,
        this.context.localize,
        this.closeDiscardDialog,
        this.discardChanges
      )}${renderEditorModal(this.state.modal, this.closeModal)}${toastListTemplate(
        this.state.toasts
      )}
      </div>`,
      this.host
    );
    this.updateDirtyIndicator();
  };
  markDirty = () => {
    if (this.state.dirty) return;
    this.state.dirty = true;
    this.updateDirtyIndicator();
  };
  updateDirtyIndicator = () => {
    const state = this.host.querySelector(".nc-editor-state");
    if (state) {
      state.textContent = this.state.dirty ? "Unsaved changes" : "All changes saved";
    }
  };
  setMode = (mode) => {
    if (this.context.mode === mode) return;
    this.context.mode = mode;
    this.state.dirty = true;
    this.renderEditor();
  };
  refreshStatuses = () => {
    this.renderEditor();
  };
  toggleOptionalSetting = (setting, enabled) => {
    if (setting === "postSendActions") {
      this.value.post_send_actions = {
        enabled,
        actions: this.value.post_send_actions?.actions
      };
    } else if (setting === "confirmation") {
      this.value.confirmation.enabled = enabled;
    } else if (setting === "confirmationReminder") {
      this.value.confirmation.reminders.enabled = enabled;
    } else if (setting === "confirmationNotification") {
      this.value.confirmation.enabled = enabled;
    } else {
      this.postConfirmationActionsEnabled = enabled;
      this.value.confirmation.actions = enabled ? this.value.confirmation.actions : [];
    }
    this.markDirty();
    this.refreshStatuses();
  };
  renderNavigation = (className = "nc-section-header") => renderEditorNavigation({
    localize: this.context.localize,
    alert: this.value,
    className,
    optionalSettings: this.optionalSettings,
    activeIndex: this.state.activeSectionIndex,
    mobileOpen: this.state.mobileSectionsOpen,
    collapsedParents: this.collapsedParents,
    onMobileMenuReady: (element) => {
      this.elements.mobileMenu = element;
    },
    onSelect: this.showSection,
    onToggleChildren: this.toggleSidebarChildren
  });
  showSection = (index) => {
    this.state.activeSectionIndex = index;
    this.context.activeSection = editorSections[index]?.title || "Basic";
    this.closeMobileSections();
    this.renderEditor();
  };
  validationLabel = () => {
    const sectionTitle = editorSections[this.state.activeSectionIndex]?.title;
    if (sectionTitle === "Condition") {
      return "Validate condition";
    }
    if (sectionTitle === "Post-send actions" || sectionTitle === "Post-confirmation actions") {
      return "Validate actions";
    }
    return "";
  };
  toggleSidebarChildren = (parent) => {
    const collapsed = !this.collapsedParents.has(parent);
    if (collapsed) this.collapsedParents.add(parent);
    else this.collapsedParents.delete(parent);
    this.renderEditor();
  };
  toggleMobileSections = () => {
    this.setMobileSectionsOpen(!this.state.mobileSectionsOpen);
  };
  closeMobileSections = () => {
    this.setMobileSectionsOpen(false);
  };
  setMobileSectionsOpen = (open) => {
    if (this.state.mobileSectionsOpen === open) return;
    this.state.mobileSectionsOpen = open;
    this.renderEditor();
  };
  sectionLabel(parent, title) {
    if (parent) {
      return `${parent} / ${title}`;
    }
    return title;
  }
  showDiscardDialog = () => {
    if (this.state.discardDialogOpen) return;
    this.state.discardDialogOpen = true;
    this.renderEditor();
  };
  closeDiscardDialog = () => {
    this.state.discardDialogOpen = false;
    this.renderEditor();
  };
  discardChanges = () => {
    this.state.discardDialogOpen = false;
    this.close({ force: true });
  };
  close = ({ force = false } = {}) => {
    if (!force && this.state.dirty) {
      this.showDiscardDialog();
      return false;
    }
    this.state.discardDialogOpen = false;
    document.removeEventListener("pointerdown", this.handleOutsideSectionPointer);
    this.host.remove();
    this.onClosed?.();
    this.root.removeEventListener("nc-editor-toast", this.handleToastEvent);
    this.root.removeEventListener("nc-editor-modal", this.handleModalEvent);
    return true;
  };
  formPayload = (validate = true) => {
    const value = this.value;
    let confirmationActions = [];
    if (this.optionalSettings.postConfirmationActions) {
      confirmationActions = actionArrayValue(
        this.elements.postConfirmationActionsEditor || null,
        "Post-confirmation actions"
      );
    }
    let postSendActions = [];
    if (this.optionalSettings.postSendActions) {
      postSendActions = actionArrayValue(
        this.elements.postSendActionsEditor || null,
        "Post-send actions"
      );
    }
    return buildEditorPayload({
      alert: value,
      condition: this.conditionForCurrentMode(),
      recipients: this.recipients.target(),
      evaluateInterval: this.evaluateIntervalPayload(),
      confirmationActions,
      postSendActions,
      postSendActionsEnabled: Boolean(value.post_send_actions?.enabled),
      postConfirmationActionsEnabled: this.postConfirmationActionsEnabled,
      validate
    });
  };
  yamlView = () => {
    try {
      showYaml(this.root, this.formPayload(false));
    } catch (error) {
      showEditorToast(this.root, errorMessage(error));
    }
  };
  conditionPayload = () => {
    const value = this.value;
    return {
      ...value,
      conditions: this.conditionForCurrentMode()
    };
  };
  conditionForCurrentMode() {
    return parseConditionYaml(this.conditionsYamlValue());
  }
  conditionsYamlValue() {
    return this.elements.conditionsYamlEditor?.value || "[]";
  }
  evaluateIntervalPayload() {
    if (!this.value.monitor?.interval) {
      return void 0;
    }
    return durationInputValue(this.value.monitor.interval, "12:00:00");
  }
  hasRequiredCondition = () => {
    try {
      const condition = parseConditionYaml(this.conditionsYamlValue());
      return condition.length > 0;
    } catch {
      return true;
    }
  };
  validateCondition = async () => {
    try {
      if (!this.hasRequiredCondition())
        throw new Error("Condition is required.");
      await this.onValidateCondition(this.conditionPayload());
    } catch (error) {
      showEditorToast(this.root, errorMessage(error));
    }
  };
  validateCurrentSection = async () => {
    const sectionTitle = editorSections[this.state.activeSectionIndex]?.title;
    if (sectionTitle === "Condition") {
      await this.validateCondition();
      return;
    }
    if (sectionTitle === "Post-send actions") {
      this.validateActions("post-send-actions", "Post-send actions");
      return;
    }
    if (sectionTitle === "Post-confirmation actions") {
      this.validateActions(
        "post-confirmation-actions",
        "Post-confirmation actions"
      );
    }
  };
  validateActions = (role, label) => {
    try {
      actionArrayValue(
        role === "post-confirmation-actions" ? this.elements.postConfirmationActionsEditor || null : this.elements.postSendActionsEditor || null,
        label
      );
      showEditorToast(this.root, `${label} are valid.`, 4e3);
    } catch (error) {
      showEditorToast(this.root, errorMessage(error));
    }
  };
  save = async (event) => {
    const button = event.currentTarget;
    try {
      if (!this.value.name.trim()) throw new Error("Name is required.");
      if (!this.hasRequiredCondition())
        throw new Error("Condition is required.");
      if (!this.value.monitor?.on_change && !this.value.monitor?.interval)
        throw new Error("Enable condition changes, an interval, or both.");
      const result = this.formPayload();
      button.disabled = true;
      const saved = await this.onSave(result);
      const savedAlert = saved || result;
      Object.assign(this.value, savedAlert);
      this.state.dirty = false;
      this.close({ force: true });
      await this.onSaved?.(savedAlert);
    } catch (error) {
      showEditorToast(this.root, errorMessage(error));
    } finally {
      button.disabled = false;
    }
  };
};
function openEditor(options) {
  if (options.root.querySelector(".nc-editor-view")) return;
  new AlertEditorController(options);
}

// frontend/date-time.ts
function formatLocalDateTime(value, includeSeconds = false, locale) {
  if (!value) {
    return "\u2014";
  }
  try {
    const date = new Date(value);
    const dateLocale = locale?.date_format === "system" ? void 0 : locale?.language;
    const timeLocale = locale?.time_format === "system" ? void 0 : locale?.language;
    let hour12;
    if (locale?.time_format === "12") {
      hour12 = true;
    } else if (locale?.time_format === "24") {
      hour12 = false;
    }
    const dateFormatter = new Intl.DateTimeFormat(dateLocale, {
      day: "2-digit",
      month: "2-digit",
      year: "numeric"
    });
    const datePart = formatDatePart(dateFormatter, date, locale?.date_format);
    const timePart = new Intl.DateTimeFormat(timeLocale, {
      hour: "numeric",
      minute: "2-digit",
      hour12,
      ...includeSeconds ? { second: "2-digit" } : {}
    }).format(date);
    return `${datePart}, ${timePart}`;
  } catch (_err) {
    return value;
  }
}
function formatDatePart(formatter, date, format) {
  const order = {
    DMY: ["day", "month", "year"],
    MDY: ["month", "day", "year"],
    YMD: ["year", "month", "day"]
  }[format || ""];
  if (!order) {
    return formatter.format(date);
  }
  const parts = Object.fromEntries(
    formatter.formatToParts(date).filter((part) => part.type !== "literal").map((part) => [part.type, part.value])
  );
  return order.map((part) => parts[part]).join("/");
}

// frontend/panel/alert-card.ts
function runtimeStatus(automationStatus, hass) {
  if (!automationStatus) {
    return void 0;
  }
  if (automationStatus.active_runs > 0 || automationStatus.active_runs_uncertain) {
    return {
      className: "nc-status active",
      icon: "mdi:progress-clock",
      label: localize(hass, "alert.automation_active")
    };
  }
  if (automationStatus.last_triggered) {
    return {
      className: "nc-status ok",
      icon: "mdi:play-circle-outline",
      label: localize(hass, "alert.automation_triggered")
    };
  }
  return {
    className: "nc-status idle",
    icon: "mdi:pause-circle-outline",
    label: localize(hass, "alert.automation_idle")
  };
}
function alertStatus(alert, hass) {
  let enabledStatus = {
    className: "nc-status disabled",
    icon: "mdi:pause-circle-outline",
    label: localize(hass, "alert.disabled")
  };
  if (alert.enabled) {
    enabledStatus = {
      className: "nc-status ok",
      icon: "mdi:check-circle",
      label: localize(hass, "alert.enabled")
    };
  }
  return { enabled: enabledStatus };
}
function toggleAlertLabel(alert, hass) {
  return alert.enabled ? localize(hass, "alert.disable") : localize(hass, "alert.enable");
}
function renderAlertCard(alert, hass, actions, automationStatus) {
  const status = alertStatus(alert, hass);
  const automation = runtimeStatus(automationStatus, hass);
  return b2`<div class="nc-card nc-alert">
    <div class="nc-alert-icon">
      <ha-icon icon=${alert.icon || "mdi:bell-outline"}></ha-icon>
    </div>
    <div class="nc-alert-main">
      <div class="nc-alert-heading">
        <div class="nc-alert-name">${alert.name}</div>
        <div class="nc-alert-statuses">
          <span
            class=${status.enabled.className}
            role="img"
            title=${status.enabled.label}
            aria-label=${status.enabled.label}
            ><ha-icon
              icon=${status.enabled.icon}
              aria-hidden="true"
            ></ha-icon
            >${status.enabled.label}
          </span>
            ${automation ? b2`<span
                  class=${automation.className}
                  role="img"
                  title=${localize(hass, automation.label)}
                  aria-label=${localize(hass, automation.label)}
                  ><ha-icon icon=${automation.icon} aria-hidden="true"></ha-icon
                  >${localize(hass, automation.label)}</span
                >` : ""}
        </div>
      </div>
    </div>
    <div class="nc-alert-actions">
      <button
        class="nc-button"
        title=${localize(hass, "alert.test")}
        aria-label=${localize(hass, "alert.test")}
        @click=${() => actions.onTest(alert)}
      >
        <ha-icon icon="mdi:play-circle-outline"></ha-icon
        ><span class="nc-button-label">${localize(hass, "alert.test")}</span></button
      ><button
        class="nc-button"
        title=${toggleAlertLabel(alert, hass)}
        aria-label=${toggleAlertLabel(alert, hass)}
        @click=${() => actions.onToggle(alert)}
      >
        <ha-icon
          icon=${alert.enabled ? "mdi:pause-circle-outline" : "mdi:play-circle-outline"}
        ></ha-icon
        ><span class="nc-button-label">${toggleAlertLabel(alert, hass)}</span></button
      ><button
        class="nc-button"
        title=${localize(hass, "alert.edit")}
        aria-label=${localize(hass, "alert.edit")}
        @click=${() => actions.onEdit(alert)}
      >
        <ha-icon icon="mdi:pencil-outline"></ha-icon
        ><span class="nc-button-label">${localize(hass, "alert.edit")}</span></button
      ><button
        class="nc-button"
        title=${localize(hass, "alert.history")}
        aria-label=${localize(hass, "alert.history")}
        @click=${() => actions.onShowHistory(alert)}
      >
        <ha-icon icon="mdi:history"></ha-icon
        ><span class="nc-button-label">${localize(hass, "alert.history")}</span></button
      ><button
        class="nc-button danger"
        title=${localize(hass, "alert.delete")}
        aria-label=${localize(hass, "alert.delete")}
        @click=${() => actions.onDelete(alert)}
      >
        <ha-icon icon="mdi:delete-outline"></ha-icon
        ><span class="nc-button-label">${localize(hass, "alert.delete")}</span>
      </button>
    </div>
  </div>`;
}

// frontend/history/logic.ts
function historySeverity(type) {
  if (!type) return "info";
  if (type.includes("failed") || type.includes("error")) return "error";
  if (type.includes("confirmed") || type.includes("sent")) return "success";
  if (type.includes("inactive")) return "muted";
  return "info";
}
function formatType(value) {
  return String(value || "event").replaceAll("_", " ");
}
function shortFlowId(value) {
  if (!value) return "";
  if (value.length > 18) return value.slice(-12);
  return value;
}
function historyDetailSummary(details) {
  if (!details || !Object.keys(details).length) return "";
  if (typeof details.error === "string") return details.error;
  if (typeof details.source === "string") return `Source: ${details.source}`;
  if (Object.keys(details).every((key) => key === "attempt")) return "";
  return JSON.stringify(details);
}
function filterHistoryEntries(history, filters) {
  const search = filters.search.trim().toLowerCase();
  return history.filter((item) => {
    if (filters.alertId && item.config?.id !== filters.alertId) return false;
    if (filters.type && item.event?.type !== filters.type) return false;
    if (filters.severity && historySeverity(item.event?.type) !== filters.severity) {
      return false;
    }
    if (!search) return true;
    const searchable = [
      item.config?.name,
      item.event?.message,
      item.event?.type,
      item.event?.flow_id,
      historyDetailSummary(item.event?.details)
    ].filter(Boolean).join(" ").toLowerCase();
    return searchable.includes(search);
  });
}
function groupHistoryEntries(history) {
  const groups = [];
  const byFlow = /* @__PURE__ */ new Map();
  for (const entry of history) {
    const flowId = entry.event?.flow_id;
    if (!flowId) {
      groups.push({ entries: [entry] });
      continue;
    }
    let group = byFlow.get(flowId);
    if (!group) {
      group = { flowId, entries: [] };
      byFlow.set(flowId, group);
      groups.push(group);
    }
    group.entries.push(entry);
  }
  return groups;
}

// frontend/history.ts
var HistoryViewElement = class extends i4 {
  expandedDetails = /* @__PURE__ */ new Set();
  static properties = {
    history: { attribute: false },
    options: { attribute: false }
  };
  createRenderRoot() {
    return this;
  }
  renderImmediately() {
    D(this.render(), this);
  }
  render() {
    const filters = this.options.filters || defaultHistoryFilters();
    const filteredHistory = filterHistoryEntries(this.history, filters);
    if (!this.history.length) {
      return emptyHistoryTemplate(this.options);
    }
    return historyTemplate(
      filteredHistory,
      this.history.length,
      this.options,
      this.expandedDetails,
      (index) => {
        if (this.expandedDetails.has(index)) {
          this.expandedDetails.delete(index);
        } else {
          this.expandedDetails.add(index);
        }
        this.renderImmediately();
      }
    );
  }
};
customElements.define("ha-notifications-history-view", HistoryViewElement);
function historyTemplate(history, totalCount, options, expandedDetails, toggleDetails) {
  return b2`<div class="nc-card nc-history">
    ${historyFilterTemplate(options)}
    ${historyItemsTemplate(history, options, expandedDetails, toggleDetails)}
    ${historyCountTemplate(history.length, totalCount, options)}
  </div>`;
}
function historyItemsTemplate(history, options, expandedDetails, toggleDetails) {
  if (!history.length) {
    return b2`<div class="nc-history-no-results">
      ${localize(options.hass, "history.no_matches")}
    </div>`;
  }
  if (!options.groupByFlow) {
    return history.map(
      (item, index2) => historyItemTemplate(
        item,
        options,
        expandedDetails.has(index2),
        () => toggleDetails(index2)
      )
    );
  }
  let index = 0;
  return groupHistoryEntries(history).map((group) => {
    const startIndex = index;
    index += group.entries.length;
    return historyFlowGroupTemplate(
      group,
      options,
      expandedDetails,
      startIndex,
      toggleDetails
    );
  });
}
function historyFlowGroupTemplate(group, options, expandedDetails, startIndex, toggleDetails) {
  if (!group.flowId) {
    return historyItemTemplate(
      group.entries[0],
      options,
      expandedDetails.has(startIndex),
      () => toggleDetails(startIndex)
    );
  }
  return b2`<details class="nc-history-flow-group" open>
    <summary class="nc-history-flow-heading">
      <span class="nc-history-flow-name">
        <ha-icon icon="mdi:chevron-down"></ha-icon>
        <span>${localize(options.hass, "history.flow")} ${shortFlowId(group.flowId)}</span>
      </span>
      <span class="nc-history-flow-count">${localize(options.hass, "history.flow_events", { count: group.entries.length })}</span>
    </summary>
    <div class="nc-history-flow-events">
      ${group.entries.map(
    (item, offset) => historyItemTemplate(
      item,
      options,
      expandedDetails.has(startIndex + offset),
      () => toggleDetails(startIndex + offset),
      false
    )
  )}
    </div>
  </details>`;
}
function historyCountTemplate(count, totalCount, options) {
  if (!count || count === totalCount) return "";
  return b2`<div class="nc-history-count">
    ${localize(options.hass, "history.showing", { count, total: totalCount })}
  </div>`;
}
function historyFilterTemplate(options) {
  const filters = options.filters || defaultHistoryFilters();
  const activeFilterCount = countSecondaryHistoryFilters(filters);
  return b2`<div class="nc-history-filter">
    <div class="nc-history-filter-heading">
      ${historyHeadingTemplate(options, filters, activeFilterCount)}
    </div>
    <div class="nc-history-controls">
      <ha-input
        class="nc-history-search"
        type="search"
        label=${localize(options.hass, "history.search")}
        aria-label=${localize(options.hass, "history.search")}
        .value=${filters.search}
        @input=${(event) => updateHistoryFilter(
    options,
    "search",
    event.currentTarget.value
  )}
      ></ha-input>
    </div>
  </div>`;
}
function historyHeadingTemplate(options, filters, activeFilterCount) {
  if (options.alertName) {
    return b2`<div>
        <div class="nc-history-filter-title">${localize(options.hass, "history.for_alert", { name: options.alertName })}</div>
        <div class="nc-history-filter-subtitle">
          ${localize(options.hass, "history.alert_only")}
        </div>
      </div>
      ${showAllButton(options.onShowAll, localize(options.hass, "panel.show_all"))}`;
  }
  return b2`<div class="nc-history-filter-main">
      <div class="nc-history-filter-row">
        <div class="nc-history-filter-label">
          <ha-icon icon="mdi:filter-variant"></ha-icon>
          <span>${localize(options.hass, "history.filter")}</span>
        </div>
        <details class="nc-history-filter-details" ?open=${activeFilterCount > 0}>
          <summary>
            <ha-icon icon="mdi:filter-variant"></ha-icon>
            <span>${localize(options.hass, "history.more_filters")}</span>
            ${historyFilterCountTemplate(activeFilterCount)}
            <ha-icon
              class="nc-history-filter-chevron"
              icon="mdi:chevron-down"
            ></ha-icon>
          </summary>
        </details>
        ${historyGroupToggleTemplate(options)}
      </div>
      ${historySecondaryFiltersTemplate(options, filters)}
    </div>
    ${historyClearButtonTemplate(options, filters)}`;
}
function historyGroupToggleTemplate(options) {
  return b2`<label class="nc-history-group-toggle">
    <ha-switch
      .checked=${options.groupByFlow === true}
      @change=${(event) => options.onGroupByFlowChanged?.(event.currentTarget.checked)}
    ></ha-switch>
    <span>${localize(options.hass, "history.group_by_flow")}</span>
  </label>`;
}
function historyFilterCountTemplate(count) {
  if (!count) return "";
  return b2`<span class="nc-history-filter-count">${count}</span>`;
}
function historyClearButtonTemplate(options, filters) {
  if (!hasHistoryFilters(filters)) return "";
  return b2`<button
    class="nc-button secondary nc-history-clear"
    @click=${() => options.onFiltersChanged?.(defaultHistoryFilters())}
  >
    ${localize(options.hass, "history.clear")}
  </button>`;
}
function historySecondaryFiltersTemplate(options, filters) {
  return b2`<div class="nc-history-secondary-controls">
    ${alertFilterTemplate(options, filters)}
    <ha-selector
      .hass=${options.hass}
      .selector=${{
    select: {
      mode: "dropdown",
      options: [
        { value: "", label: localize(options.hass, "history.all_event_types") },
        ...(options.types || []).map((type) => ({
          value: type,
          label: localize(options.hass, `event.${type}`, {}, formatType(type))
        }))
      ]
    }
  }}
      .value=${filters.type}
      label=${localize(options.hass, "history.event_type")}
      aria-label=${localize(options.hass, "history.filter_event_type")}
      @value-changed=${(event) => updateHistoryFilter(options, "type", event.detail.value || "")}
    ></ha-selector>
    <ha-selector
      .hass=${options.hass}
      .selector=${{
    select: {
      mode: "dropdown",
      options: [
        { value: "", label: localize(options.hass, "history.all_severities") },
        { value: "error", label: localize(options.hass, "history.error") },
        { value: "success", label: localize(options.hass, "history.success") },
        { value: "info", label: localize(options.hass, "history.info") },
        { value: "muted", label: localize(options.hass, "history.muted") }
      ]
    }
  }}
      .value=${filters.severity}
      label=${localize(options.hass, "history.severity")}
      aria-label=${localize(options.hass, "history.filter_severity")}
      @value-changed=${(event) => updateHistoryFilter(options, "severity", event.detail.value || "")}
    ></ha-selector>
  </div>`;
}
function alertFilterTemplate(options, filters) {
  if (!options.alerts?.length) return "";
  return b2`<ha-selector
    .hass=${options.hass}
    .selector=${{
    select: {
      mode: "dropdown",
      options: [
        { value: "", label: localize(options.hass, "history.all_alerts") },
        ...options.alerts.map((alert) => ({
          value: alert.id,
          label: alert.name
        }))
      ]
    }
  }}
    .value=${filters.alertId}
    label=${localize(options.hass, "history.alert")}
    aria-label=${localize(options.hass, "history.filter_alert")}
    @value-changed=${(event) => updateHistoryFilter(options, "alertId", event.detail.value || "")}
  ></ha-selector>`;
}
function defaultHistoryFilters() {
  return { search: "", alertId: "", type: "", severity: "" };
}
function updateHistoryFilter(options, key, value) {
  const filters = options.filters || defaultHistoryFilters();
  options.onFiltersChanged?.({ ...filters, [key]: value });
}
function hasHistoryFilters(filters) {
  return countHistoryFilters(filters) > 0;
}
function countHistoryFilters(filters) {
  return [filters.search, filters.alertId, filters.type, filters.severity].filter(
    Boolean
  ).length;
}
function countSecondaryHistoryFilters(filters) {
  return [filters.alertId, filters.type, filters.severity].filter(Boolean).length;
}
function historyItemTemplate(item, options, detailsOpen, toggleDetails, showFlow = true) {
  const details = item.event?.details;
  const hasDetails = Boolean(details && Object.keys(details).length);
  return b2`<div
    class=${`nc-history-item${hasDetails ? " clickable" : ""}`}
    ?tabindex=${hasDetails}
    role=${hasDetails ? "button" : "none"}
    @click=${hasDetails ? toggleDetails : void 0}
    @keydown=${hasDetails ? (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    toggleDetails();
  } : void 0}
  >
    <div class="nc-history-time">
      ${formatLocalDateTime(item.event?.timestamp, true, options.locale)}
    </div>
    <div class="nc-history-main">
      <div class="nc-history-title">
        ${historyAlertTemplate(item, options)}
        <span class=${`nc-history-badge ${historySeverity(item.event?.type)}`}
          >${formatType(item.event?.type)}</span
        >
            ${showFlow && item.event?.flow_id ? b2`<span class="nc-history-flow"
              >${localize(options.hass, "history.flow")} ${shortFlowId(item.event.flow_id)}</span
            >` : ""}
      </div>
      ${historyDetailsTemplate(details, hasDetails, detailsOpen)}
    </div>
  </div>`;
}
function historyDetailsTemplate(details, hasDetails, detailsOpen) {
  if (!hasDetails) return "";
  return b2`<details
    class="nc-details nc-history-details"
    ?open=${detailsOpen}
    @click=${(event) => event.stopPropagation()}
  >
    <summary>${localize(void 0, "history.details")}</summary>
    <pre>${JSON.stringify(details, null, 2)}</pre>
  </details>`;
}
function historyAlertTemplate(item, options) {
  const alertName = item.config?.name || localize(options.hass, "history.unknown_alert");
  if (!item.config?.id) {
    return b2`<span>${alertName}</span>`;
  }
  return b2`<button
    class="nc-history-alert-link"
    @click=${(event) => {
    event.stopPropagation();
    options.onAlertSelected?.(item.config.id, alertName);
  }}
  >
    ${alertName}
  </button>`;
}
function emptyHistoryTemplate(options) {
  let title = localize(options.hass, "history.no_activity");
  if (options.alertName) {
    title = localize(options.hass, "history.no_activity_for", { name: options.alertName });
  }
  return b2`<div class="nc-card nc-empty">
    <h2>${title}</h2>
    <p>${localize(options.hass, "history.activity_help")}</p>
    ${options.alertName ? showAllButton(options.onShowAll, localize(options.hass, "history.show_all")) : ""}
  </div>`;
}
function showAllButton(onShowAll, label) {
  return b2`<button class="nc-button secondary" @click=${onShowAll}>
    ${label}
  </button>`;
}

// frontend/styles.ts
var styles = `
:host {
  display: block;
  color: var(--primary-text-color);
  background: var(--primary-background-color);
  min-height: 100%;
  box-sizing: border-box;
}

:host(ha-notifications-card) {
  container-type: inline-size;
}

* {
  box-sizing: border-box;
}

[hidden] {
  display: none !important;
}

button,
input,
textarea,
select {
  font: inherit;
}

.nc-page {
  padding: 24px;
  max-width: 1400px;
  margin: 0 auto;
}

.nc-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 20px;
}

.nc-back-button {
  display: none;
  flex: 0 0 auto;
  width: 40px;
  height: 40px;
  place-items: center;
  border-radius: 50%;
  color: var(--primary-text-color);
  background: var(--secondary-background-color);
  text-decoration: none;
}

.nc-back-button:hover {
  background: var(--divider-color);
}

:host(ha-notifications-card) .nc-back-button {
  display: none;
}

.nc-title {
  display: flex;
  align-items: center;
  gap: 14px;
}

.nc-title-icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: var(--primary-color);
  color: var(--text-primary-color);
  display: grid;
  place-items: center;
  font-size: 24px;
}

.nc-title-icon img {
  width: 32px;
  height: 32px;
  object-fit: contain;
}

.nc-title h1 {
  margin: 0;
  font-size: 28px;
}

.nc-title p {
  margin: 4px 0 0;
  color: var(--secondary-text-color);
}

.nc-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.nc-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  border: 0;
  border-radius: var(--ha-border-radius-m, 8px);
  padding: 8px 12px;
  cursor: pointer;
  background: var(--primary-color);
  color: white;
  font-weight: 600;
  text-decoration: none;
}

.nc-button.secondary {
  background: var(--secondary-background-color);
  color: var(--primary-text-color);
}

.nc-confirmation-add-button {
  justify-self: start;
  border: 1px solid var(--divider-color);
}

.nc-confirmation-add-button:hover {
  border-color: var(--primary-color);
  background: color-mix(
    in srgb,
    var(--primary-color) 10%,
    var(--secondary-background-color)
  );
}

.nc-button.danger {
  background: var(--error-color);
  color: white;
}

.nc-button:disabled {
  opacity: 0.5;
  cursor: default;
}

.nc-tabs {
  display: flex;
  gap: 4px;
  padding: 4px;
  background: var(--secondary-background-color);
  border-radius: var(--ha-border-radius-m, 8px);
  margin-bottom: 18px;
}

.nc-tab {
  flex: 1;
  border: 0;
  background: transparent;
  padding: 8px 10px;
  border-radius: var(--ha-border-radius-s, 4px);
  cursor: pointer;
  color: var(--secondary-text-color);
  font-weight: 600;
}

.nc-tab.active {
  background: var(--card-background-color);
  color: var(--primary-text-color);
  box-shadow: var(--ha-box-shadow);
}

.nc-alerts {
  display: grid;
  gap: 12px;
}

.nc-debug-list {
  display: grid;
  gap: 12px;
}

.nc-debug-alert,
.nc-debug-section {
  background: var(--card-background-color);
  border-radius: var(--ha-card-border-radius, 12px);
  box-shadow: var(--ha-box-shadow);
}

.nc-debug-alert > summary,
.nc-debug-section > summary {
  cursor: pointer;
  list-style: none;
}

.nc-debug-alert > summary::-webkit-details-marker,
.nc-debug-section > summary::-webkit-details-marker {
  display: none;
}

.nc-debug-alert > summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 14px 16px;
  font-weight: 600;
}

.nc-debug-alert > summary::before,
.nc-debug-section > summary::before {
  content: ">";
  color: var(--secondary-text-color);
  margin-right: 8px;
}

.nc-debug-alert[open] > summary::before,
.nc-debug-section[open] > summary::before {
  content: "v";
}

.nc-debug-alert > summary code {
  color: var(--secondary-text-color);
  font: var(--code-font, 14px monospace);
  font-weight: 400;
}

.nc-debug-sections {
  display: grid;
  gap: 8px;
  padding: 0 8px 8px;
}

.nc-debug-section {
  box-shadow: none;
  background: var(--primary-background-color);
}

.nc-debug-section > summary {
  padding: 10px 12px;
  color: var(--secondary-text-color);
  font-size: 0.9rem;
  font-weight: 600;
}

.nc-debug-section pre {
  margin: 0;
  padding: 0 12px 12px;
  overflow: auto;
  color: var(--primary-text-color);
  font: var(--code-font, 14px monospace);
  white-space: pre-wrap;
}

.nc-card {
  background: var(--card-background-color);
  border-radius: var(--ha-card-border-radius, 12px);
  padding: 16px;
  box-shadow: var(--ha-box-shadow);
}

.nc-section {
  background: transparent;
}

.nc-section-content {
  padding: 0 16px 16px;
}

.nc-reminder-options {
  display: grid;
  gap: 12px;
  margin-top: 16px;
}

.nc-section-status {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: rgba(244, 67, 54, 0.12);
  color: var(--error-color);
  font-size: 12px;
  font-weight: 800;
  line-height: 1;
}

.nc-section-status.active {
  background: rgba(76, 175, 80, 0.14);
  color: var(--success-color, #4caf50);
}

.nc-alert {
  display: grid;
  grid-template-columns: auto 1fr auto;
  gap: 12px;
  align-items: center;
  padding: 14px;
}

.nc-alert-icon {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  background: var(--secondary-background-color);
  display: grid;
  place-items: center;
  font-size: 21px;
}

.nc-alert-icon ha-icon {
  --mdc-icon-size: 24px;
}

.nc-alert-main {
  min-width: 0;
}

.nc-alert-name {
  font-weight: 700;
  font-size: 17px;
}

.nc-alert-heading {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}

.nc-alert-meta {
  margin-top: 5px;
  color: var(--secondary-text-color);
  font-size: 13px;
}

.nc-alert-actions {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.nc-alert-actions .nc-button {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 7px 9px;
}

.nc-alert-actions ha-icon {
  --mdc-icon-size: 16px;
}

.nc-alert-statuses {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
}

.nc-status {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 8px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
}

.nc-status ha-icon {
  --mdc-icon-size: 14px;
}

.nc-status.active {
  background: rgba(244, 67, 54, 0.14);
  color: var(--error-color);
}

.nc-status.ok {
  background: rgba(76, 175, 80, 0.14);
  color: var(--success-color, #4caf50);
}

.nc-status.idle {
  background: rgba(33, 150, 243, 0.12);
  color: var(--info-color, #2196f3);
}

.nc-status.disabled {
  background: var(--secondary-background-color);
  color: var(--secondary-text-color);
}

.nc-empty {
  text-align: center;
  padding: 55px 20px;
  color: var(--secondary-text-color);
}

.nc-empty h2 {
  color: var(--primary-text-color);
}

.nc-toolbar {
  display: flex;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.nc-toolbar select,
.nc-toolbar input,
.nc-yaml textarea,
.nc-code-editor {
  box-sizing: border-box;
  max-width: 100%;
  min-width: 0;
  background: var(--card-background-color);
  color: var(--primary-text-color);
  border: 1px solid var(--divider-color);
  border-radius: 10px;
  padding: 10px;
}

ha-code-editor.nc-code-editor {
  display: block;
  max-width: 100%;
  min-width: 0;
  --nc-code-editor-height: min(650px, 70vh);
  overflow: hidden;
}

ha-code-editor.nc-code-editor .cm-editor,
ha-code-editor.nc-code-editor .cm-scroller,
ha-code-editor.nc-code-editor .cm-content {
  max-width: 100%;
}

ha-code-editor.nc-code-editor .cm-scroller {
  overflow-x: auto;
}

.nc-history {
  display: grid;
  gap: 8px;
}

.nc-history-filter {
  display: grid;
  gap: 12px;
  position: sticky;
  top: 0;
  z-index: 1;
  padding: 4px 0 12px;
  background: var(--card-background-color);
  border-bottom: 1px solid var(--divider-color);
}

.nc-history-filter-heading,
.nc-history-controls {
  display: flex;
  align-items: flex-end;
  flex-wrap: wrap;
  gap: 8px;
}

.nc-history-filter-details {
  min-width: 0;
}

.nc-history-filter-main {
  display: grid;
  gap: 10px;
  min-width: 0;
}

.nc-history-filter-row {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  min-width: 0;
}

.nc-history-filter-details summary {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 36px;
  padding: 0 10px;
  border: 1px solid var(--divider-color);
  border-radius: var(--ha-border-radius-s, 4px);
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 13px;
  list-style: none;
  white-space: nowrap;
}

.nc-history-filter-details summary:hover {
  background: var(--secondary-background-color);
}

.nc-history-filter-details[open] summary {
  border-color: var(--primary-color);
  background: color-mix(
    in srgb,
    var(--primary-color) 10%,
    var(--card-background-color)
  );
  color: var(--primary-text-color);
}

.nc-history-filter-details summary::-webkit-details-marker {
  display: none;
}

.nc-history-filter-details summary ha-icon {
  --mdc-icon-size: 18px;
}

.nc-history-filter-chevron {
  transition: transform 160ms ease;
}

.nc-history-filter-details[open] .nc-history-filter-chevron {
  transform: rotate(180deg);
}

.nc-history-filter-count {
  display: inline-grid;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  place-items: center;
  border-radius: 9px;
  background: var(--primary-color);
  color: var(--text-primary-color);
  font-size: 11px;
  font-weight: 700;
}

.nc-history-secondary-controls {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  margin-top: 10px;
  padding: 0;
}

.nc-history-filter-main:not(:has(.nc-history-filter-details[open]))
  .nc-history-secondary-controls {
  display: none;
}

.nc-history-filter-heading {
  align-items: center;
  justify-content: space-between;
}

.nc-history-filter-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-height: 36px;
  color: var(--secondary-text-color);
  font-size: 13px;
  font-weight: 700;
}

.nc-history-filter-label ha-icon {
  --mdc-icon-size: 18px;
  color: var(--primary-color);
}

.nc-history-filter-heading .nc-history-clear {
  min-height: 0;
  padding: 0;
  background: transparent;
  color: var(--secondary-text-color);
  font-size: 13px;
  line-height: 18px;
}

.nc-history-controls ha-input {
  --ha-input-padding-bottom: 0px;
  min-height: 36px;
  box-sizing: border-box;
}

.nc-history-controls ha-selector {
  flex: 0 1 180px;
  min-width: 150px;
  min-height: 36px;
  box-sizing: border-box;
}

.nc-history-group-toggle {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-height: 36px;
  margin-left: auto;
  color: var(--secondary-text-color);
  font-size: 13px;
  white-space: nowrap;
}

.nc-history-group-toggle ha-switch {
  --mdc-switch-scale: 0.8;
}

.nc-history-secondary-controls ha-selector {
  min-width: 0;
}

.nc-history-search {
  flex: 1 1 220px;
  min-width: 180px;
}

.nc-history-flow-group {
  border-bottom: 1px solid var(--divider-color);
}

.nc-history-flow-group:last-child {
  border-bottom: 0;
}

.nc-history-flow-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 0 6px;
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 12px;
  font-weight: 700;
  list-style: none;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.nc-history-flow-heading::-webkit-details-marker {
  display: none;
}

.nc-history-flow-name,
.nc-history-flow-count {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.nc-history-flow-name ha-icon {
  --mdc-icon-size: 18px;
  transition: transform 160ms ease;
}

.nc-history-flow-group:not([open]) .nc-history-flow-name ha-icon {
  transform: rotate(-90deg);
}

.nc-history-flow-heading:hover {
  color: var(--primary-text-color);
}

.nc-history-flow-events .nc-history-item {
  padding-left: 8px;
}

.nc-history-no-results,
.nc-history-count {
  padding: 16px 0;
  color: var(--secondary-text-color);
}

.nc-history-count {
  padding-top: 4px;
  font-size: 12px;
}

.nc-history-filter-title {
  font-weight: 700;
}

.nc-history-filter-subtitle {
  color: var(--secondary-text-color);
  font-size: 12px;
}

.nc-history-item {
  display: grid;
  grid-template-columns: 150px minmax(0, 1fr);
  gap: 10px;
  align-items: start;
  padding: 9px 6px;
  border-bottom: 1px solid var(--divider-color);
}

.nc-history-item.clickable {
  cursor: pointer;
}

.nc-history-item.clickable:focus-visible {
  outline: 2px solid var(--primary-color);
  outline-offset: -2px;
}

.nc-history-time {
  color: var(--secondary-text-color);
  font-size: 12px;
}

.nc-history-main {
  display: grid;
  gap: 2px;
  min-width: 0;
}

.nc-history-title {
  display: flex;
  align-items: center;
  flex-wrap: nowrap;
  min-width: 0;
  gap: 6px;
  font-weight: 700;
}

.nc-history-alert-link {
  border: 0;
  padding: 0;
  background: transparent;
  color: var(--primary-color);
  cursor: pointer;
  font: inherit;
  text-align: left;
}

.nc-history-alert-link:hover {
  text-decoration: underline;
}

.nc-history-title .nc-history-alert-link {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.nc-history-title .nc-history-badge,
.nc-history-title .nc-history-flow {
  flex: 0 0 auto;
}

.nc-history-badge {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: 2px 7px;
  font-size: 11px;
  font-weight: 700;
}

.nc-history-badge.error {
  background: rgba(244, 67, 54, 0.14);
  color: var(--error-color);
}

.nc-history-badge.success {
  background: rgba(76, 175, 80, 0.14);
  color: var(--success-color, #4caf50);
}

.nc-history-badge.info {
  background: rgba(33, 150, 243, 0.12);
  color: var(--info-color, #2196f3);
}

.nc-history-badge.muted {
  background: var(--secondary-background-color);
  color: var(--secondary-text-color);
}

.nc-history-flow {
  display: inline-flex;
  align-items: center;
  max-width: 180px;
  overflow: hidden;
  border: 1px solid var(--divider-color);
  border-radius: 999px;
  padding: 2px 7px;
  color: var(--secondary-text-color);
  font-family: monospace;
  font-size: 11px;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.nc-details {
  margin-top: 6px;
  color: var(--secondary-text-color);
  font-size: 12px;
}

.nc-details summary {
  cursor: pointer;
}

.nc-history-details {
  margin-top: 0;
}

.nc-details pre {
  margin: 6px 0 0;
  padding: 8px;
  border-radius: 6px;
  background: var(--secondary-background-color);
  white-space: pre-wrap;
}

.nc-yaml {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: calc(100vh - 180px);
}

.nc-yaml textarea,
.nc-code-editor {
  width: 100%;
  min-height: min(650px, 70vh);
  resize: vertical;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 13px;
  line-height: 1.5;
}

ha-code-editor.nc-yaml-editor {
  flex: 1 1 auto;
  min-height: 0;
  height: min(650px, calc(100dvh - 250px));
  max-height: none;
  --nc-code-editor-height: min(650px, calc(100dvh - 250px));
}

.nc-modal-backdrop {
  position: fixed;
  inset: 0;
  z-index: 10000;
  background: rgba(0, 0, 0, 0.48);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.nc-editor-view {
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 24px;
}

.nc-editor-shell {
  background: var(--card-background-color);
  color: var(--primary-text-color);
  border-radius: 16px;
  box-shadow: var(--ha-box-shadow);
  overflow: hidden;
}

.nc-editor-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 20px 24px;
  border-bottom: 1px solid var(--divider-color);
}

.nc-editor-header h1,
.nc-editor-header h2 {
  margin: 0;
}

.nc-editor-header h1 {
  font-size: 22px;
}

.nc-editor-identity {
  min-width: 0;
  flex: 1 1 auto;
}

.nc-editor-title-row {
  display: flex;
  align-items: baseline;
  flex-wrap: wrap;
  min-width: 0;
  gap: 10px;
}

.nc-editor-title-row h1,
.nc-editor-title-row h2 {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.nc-editor-title-separator {
  color: var(--secondary-text-color);
  font-size: 18px;
}

.nc-editor-header h2 {
  color: var(--secondary-text-color);
  font-size: 18px;
  font-weight: 500;
}

.nc-editor-section-controls {
  display: flex;
  align-items: center;
  min-width: 118px;
  flex: 0 1 auto;
}

.nc-section-manage-button {
  display: none;
}

.nc-editor-shell > .nc-modal-header {
  background: var(--card-background-color);
  color: var(--primary-text-color);
}

.nc-modal {
  width: min(900px, 100%);
  max-height: 92vh;
  overflow: auto;
  background: var(--card-background-color);
  color: var(--primary-text-color);
  border-radius: 18px;
  box-shadow: 0 20px 70px rgba(0,0,0,.35);
}

.nc-alert-yaml-modal {
  max-height: calc(100vh - 40px);
  overflow: hidden;
}

.nc-alert-yaml-modal .nc-modal-body {
  min-height: 0;
  overflow: hidden;
}

ha-code-editor.nc-alert-yaml-editor {
  --nc-code-editor-height: min(650px, calc(100vh - 180px));
  max-height: calc(100vh - 180px);
}

.nc-discard-modal {
  width: min(440px, 100%);
}

.nc-discard-modal p {
  margin: 0;
  line-height: 1.5;
}

.nc-modal-header {
  background: var(--secondary-background-color);
  padding: 20px;
  border-bottom: 1px solid var(--divider-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
  .nc-editor-shell > .nc-modal-header {
    background: var(--card-background-color);
    color: var(--primary-text-color);
  }
  margin: 0;
}

.nc-modal-body {
  padding: 24px;
}

.nc-editor-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 232px;
  grid-template-areas: "content sidebar";
  gap: 28px;
}

.nc-section-header {
  grid-area: sidebar;
  position: sticky;
  top: 0;
  z-index: 15;
  align-self: start;
  display: grid;
  gap: 2px;
  padding: 4px 0 4px 14px;
  border-left: 1px solid var(--divider-color);
  background: transparent;
}

.nc-mobile-section-menu {
  display: none;
}

.nc-section-nav-row {
  display: flex;
  align-items: center;
  min-width: 0;
}

.nc-section-header .nc-section-nav-button {
  flex: 1 1 auto;
  min-width: 0;
  width: 100%;
  border: 0;
  border-radius: 9px;
  padding: 10px 12px;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 13px;
  font-weight: 600;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  justify-content: flex-start;
  gap: 7px;
}

.nc-section-header .nc-section-nav-button > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}

.nc-section-header .nc-section-nav-button:hover {
  background: var(--primary-background-color);
  color: var(--primary-text-color);
}

.nc-section-header .nc-section-nav-button.active {
  background: var(--secondary-background-color);
  color: var(--primary-text-color);
  box-shadow: none;
  border-left: 3px solid var(--primary-color);
  padding-left: 9px;
}

.nc-section-header .nc-section-nav-button.nc-section-nav-child {
  width: calc(100% - 12px);
  margin-left: 12px;
  font-size: 12px;
}

.nc-section-collapse-button {
  display: inline-grid;
  width: 30px;
  height: 30px;
  place-items: center;
  flex: 0 0 auto;
  border: 0;
  border-radius: 50%;
  padding: 0;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
}

.nc-section-collapse-button:hover {
  background: var(--secondary-background-color);
  color: var(--primary-text-color);
}

.nc-section-collapse-button ha-icon {
  --mdc-icon-size: 18px;
}

.nc-optional-setting[hidden] {
  display: none;
}

.nc-section-header .nc-section-status {
  width: 8px;
  height: 8px;
  flex: 0 0 8px;
  border-radius: 50%;
  background: var(--error-color);
}

.nc-section-header .nc-section-status.active {
  background: var(--success-color, #4caf50);
}

.nc-section:not(.active) {
  display: none;
}

.nc-editor-sections {
  grid-area: content;
  min-width: 0;
}

.nc-modal-footer {
  position: sticky;
  bottom: 0;
  z-index: 2;
  align-items: center;
  flex-wrap: wrap;
  padding: 16px 20px;
  border-top: 1px solid var(--divider-color);
  background: var(--card-background-color);
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.nc-editor-state {
  margin-right: auto;
  color: var(--secondary-text-color);
  font-size: 12px;
}

.nc-yaml-utility {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid var(--divider-color);
}

.nc-yaml-utility .nc-alert-yaml-editor {
  min-height: 360px;
}

.nc-section {
  border: 0;
  border-radius: 0;
  padding: 0 0 28px;
  margin-bottom: 28px;
}

.nc-section-content {
  padding: 0;
}

.nc-section-actions {
  display: flex;
  justify-content: flex-start;
  margin-top: 18px;
}

.nc-setting-controls {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.nc-icon-button {
  display: inline-grid;
  width: 36px;
  height: 36px;
  place-items: center;
  border: 0;
  border-radius: 50%;
  padding: 0;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
}

.nc-icon-button:hover {
  background: var(--secondary-background-color);
  color: var(--primary-text-color);
}

.nc-icon-button.danger:hover {
  color: var(--error-color);
}

.nc-icon-button ha-icon {
  --mdc-icon-size: 20px;
}

.nc-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 22px;
}

.nc-field {
  display: grid;
  gap: 10px;
}

.nc-field.full {
  grid-column: 1 / -1;
}

.nc-field label {
  font-weight: 600;
  font-size: 15px;
}

.nc-field-heading {
  display: flex;
  align-items: center;
  gap: 12px;
  width: 100%;
  font-size: 15px;
}

.nc-evaluate-settings {
  display: grid;
  gap: 26px;
}

.nc-evaluate-toggles {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 14px 28px;
}

.nc-evaluate-toggle {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 12px;
  width: 100%;
  font-size: 15px;
  font-weight: 600;
}

.nc-evaluate-toggle ha-switch,
.nc-field-heading ha-switch {
  flex: 0 0 auto;
}

.nc-field ha-input,
.nc-field ha-icon-picker,
.nc-field ha-selector {
  display: block;
  width: 100%;
}

.nc-field ha-selector.nc-description-input {
  width: 100%;
}

.nc-field ha-icon-picker {
  width: min(100%, 14rem);
}

.nc-field ha-input.nc-duration-input,
.nc-field ha-input.nc-number-field {
  width: min(100%, 10rem);
}

.nc-field ha-selector.nc-duration-input {
  display: block;
  width: min(100%, 24rem);
  max-width: 100%;
}

ha-code-editor.nc-action-editor {
  --code-editor-background-color: var(--secondary-background-color);
  --code-editor-gutter-color: var(--secondary-background-color);
  display: block;
  width: 100%;
  height: auto;
  min-height: 0;
}

.nc-target-picker {
  display: grid;
  gap: 8px;
}

.nc-recipient-input {
  position: relative;
  z-index: 40;
}

.nc-section-recipient {
  position: relative;
  z-index: 30;
  overflow: visible;
}

.nc-recipient-toolbar {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 8px;
}

.nc-recipient-toolbar ha-input {
  min-width: 0;
  width: 100%;
}

.nc-recipient-filters {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  grid-column: 1 / -1;
}

.nc-recipient-filter {
  border: 1px solid var(--divider-color);
  border-radius: 999px;
  padding: 5px 9px;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 12px;
}

.nc-recipient-filter.active,
.nc-recipient-filter:hover {
  border-color: var(--primary-color);
  background: var(--primary-color);
  color: var(--text-primary-color, white);
}

.nc-recipient-results {
  display: grid;
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  left: 0;
  z-index: 50;
  grid-template-columns: 1fr;
  gap: 6px;
  max-height: 240px;
  overflow: auto;
  padding: 2px;
  border: 1px solid var(--divider-color);
  border-radius: 9px;
  background: var(--card-background-color);
  box-shadow: var(--ha-box-shadow);
}

.nc-recipient-results[hidden] {
  display: none;
}

.nc-recipient-option {
  min-width: 0;
  overflow: hidden;
  border: 1px solid var(--divider-color);
  border-radius: 8px;
  padding: 8px 10px;
  background: var(--primary-background-color);
  color: var(--primary-text-color);
  cursor: pointer;
  text-align: left;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.nc-recipient-option:hover {
  border-color: var(--primary-color);
}

.nc-recipient-empty {
  grid-column: 1 / -1;
  padding: 12px;
  color: var(--secondary-text-color);
  text-align: center;
}

.nc-target-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  min-height: 24px;
}

.nc-target-selection-label {
  color: var(--secondary-text-color);
  font-size: 12px;
  font-weight: 600;
}

.nc-target-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  padding: 5px 7px 5px 10px;
  border-radius: 999px;
  background: var(--secondary-background-color);
  color: var(--primary-text-color);
  font-size: 13px;
}

.nc-chip-remove {
  border: 0;
  padding: 0;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 0;
}

.nc-chip-remove::after {
  content: "\xD7";
  font-size: 18px;
  line-height: 1;
}



.nc-switch-label {
  display: flex;
  align-items: center;
  gap: 10px;
  width: fit-content;
  cursor: pointer;
}

.nc-setting-group {
  display: grid;
  gap: 14px;
}

.nc-subfield {
  display: grid;
  gap: 8px;
  width: min(100%, 24rem);
  color: var(--primary-text-color);
  font-size: 15px;
  font-weight: 600;
}

.nc-setting-row {
  justify-content: space-between;
  width: 100%;
}

.nc-confirmation-clear {
  margin-top: 16px;
}

.nc-duration-input {
  font-variant-numeric: tabular-nums;
}

.nc-help {
  margin-top: 12px;
  color: var(--secondary-text-color);
  font-size: 12px;
  line-height: 1.5;
}

.nc-template-help-trigger {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  margin-top: 10px;
  color: var(--secondary-text-color);
  font-size: 12px;
}

.nc-template-help-trigger .nc-icon-button {
  width: 30px;
  height: 30px;
}

.nc-template-help-modal {
  width: min(560px, 100%);
}

.nc-condition-mode {
  display: flex;
  gap: 6px;
  margin-bottom: 12px;
}

.nc-condition-mode-button {
  border: 1px solid var(--divider-color);
  border-radius: 999px;
  padding: 7px 11px;
  background: transparent;
  color: var(--secondary-text-color);
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
}

.nc-condition-mode-button.active,
.nc-condition-mode-button:hover {
  border-color: var(--primary-color);
  background: var(--primary-color);
  color: var(--text-primary-color, white);
}

.nc-condition-rows {
  display: grid;
  gap: 10px;
  margin-bottom: 10px;
}

.nc-condition-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  align-items: start;
  gap: 10px;
  padding: 12px;
  border: 1px solid var(--divider-color);
  border-radius: 10px;
  background: var(--secondary-background-color);
}

.nc-condition-row > * {
  min-width: 0;
  max-width: 100%;
}

.nc-condition-row > .nc-field {
  width: 100%;
  min-width: 0;
  align-self: start;
}

.nc-condition-row > .nc-condition-duration {
  grid-column: 1 / -1;
}

.nc-condition-row .nc-field ha-input,
.nc-condition-row .nc-field ha-selector {
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  max-width: 100%;
}

.nc-condition-row .nc-field ha-selector.nc-duration-input {
  width: 100%;
  max-width: 100%;
  min-width: 0;
}

.nc-condition-actions {
  grid-column: 1 / -1;
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-self: end;
  align-self: end;
  justify-content: flex-end;
}

.nc-condition-actions .nc-button {
  white-space: nowrap;
}

.nc-condition-id-toggle {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

.nc-condition-id-toggle ha-icon {
  --mdc-icon-size: 16px;
}

.nc-error {
  color: var(--error-color);
  background: rgba(244, 67, 54, 0.1);
  border-radius: 9px;
  padding: 10px;
  white-space: pre-wrap;
}

.nc-toast-list {
  position: fixed;
  right: 20px;
  bottom: 20px;
  z-index: 20000;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.nc-toast {
  padding: 12px 16px;
  border-radius: 10px;
  background: var(--primary-text-color);
  color: var(--primary-background-color);
  box-shadow: var(--ha-box-shadow);
}

.nc-toast.error {
  background: var(--error-color);
  color: white;
}

@container (min-width: 701px) and (max-width: 800px) {
  .nc-condition-row {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr) auto;
  }

  .nc-alert-actions .nc-button {
    flex: 0 0 auto;
    justify-content: center;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }
}

@container (min-width: 801px) and (max-width: 1100px) {
  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr) auto;
  }

  .nc-alert-actions .nc-button {
    flex: 0 0 auto;
    justify-content: center;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }
}

@container (max-width: 700px) {
  .nc-page {
    padding: 14px;
  }

  .nc-editor-view {
    padding: 14px;
  }

  .nc-header {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr);
    align-items: center;
    gap: 10px;
  }

  .nc-back-button {
    display: inline-grid;
    grid-column: 1;
    grid-row: 2;
  }

  .nc-title {
    grid-column: 1 / -1;
    grid-row: 1;
    min-width: 0;
    justify-self: start;
  }

  .nc-title h1 {
    font-size: 24px;
  }

  .nc-actions {
    grid-column: 1 / -1;
    grid-row: 2;
    justify-content: flex-end;
    width: 100%;
  }

  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr);
  }

  .nc-alert-actions {
    grid-column: 1 / -1;
    width: 100%;
  }

  .nc-alert-actions .nc-button {
    flex: 0 0 auto;
    justify-content: center;
    padding: 8px 4px;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }

  .nc-grid,
  .nc-condition-row,
  .nc-recipient-toolbar {
    grid-template-columns: 1fr;
  }

  .nc-evaluate-toggles {
    grid-template-columns: 1fr;
  }

  .nc-modal-body {
    padding: 16px;
  }

  .nc-editor-header {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: flex-start;
    gap: 6px;
    padding: 16px;
  }

  .nc-editor-identity {
    grid-column: 1;
    grid-row: 1;
  }

  .nc-editor-section-controls {
    min-width: 0;
    width: auto;
    grid-column: 1 / -1;
    grid-row: 2;
  }

  .nc-editor-title-row {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    gap: 3px;
  }

  .nc-editor-title-separator {
    display: none;
  }

  .nc-editor-header h1 {
    font-size: 20px;
  }

  .nc-editor-header h2 {
    font-size: 14px;
  }

  .nc-editor-layout {
    display: block;
    position: relative;
  }

  .nc-editor-shell {
    overflow: visible;
  }

  .nc-editor-header {
    position: relative;
    z-index: 100;
  }

  .nc-section-header:not(.nc-mobile-section-menu) {
    display: none;
  }

  .nc-section-manage-button {
    display: inline-grid;
    grid-column: 2;
    grid-row: 1;
    width: 40px;
    min-height: 40px;
    padding: 8px;
  }

  .nc-section-manage-button ha-icon {
    --mdc-icon-size: 20px;
  }

  .nc-mobile-section-menu {
    display: none;
    position: absolute;
    top: calc(100% - 8px);
    right: 16px;
    z-index: 110;
    width: min(300px, calc(100% - 32px));
    gap: 2px;
    padding: 8px;
    border: 1px solid var(--divider-color);
    border-radius: 10px;
    background: var(--card-background-color);
    box-shadow: var(--ha-box-shadow);
  }

  .nc-mobile-section-menu.mobile-open {
    display: grid;
  }

  .nc-toolbar,
  .nc-yaml .nc-actions {
    display: grid;
    grid-template-columns: 1fr;
    width: 100%;
  }

  .nc-yaml .nc-actions .nc-button {
    width: 100%;
  }

  .nc-code-editor,
  ha-code-editor.nc-alert-yaml-editor {
    --nc-code-editor-height: min(420px, 62vh);
    min-height: min(420px, 62vh);
  }

  .nc-history-item {
    grid-template-columns: 1fr;
    gap: 4px;
  }

  .nc-history-filter-heading {
    align-items: center;
    flex-direction: row;
    gap: 8px;
  }

  .nc-history-filter-main {
    flex: 1 1 auto;
    min-width: 0;
  }

  .nc-history-filter-row {
    align-items: center;
  }

  .nc-history-controls {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
  }

  .nc-history-controls .nc-history-search {
    min-width: 0;
  }

  .nc-history-controls ha-input {
    width: 100%;
  }

  .nc-history-filter-details {
    min-width: 0;
  }

  .nc-history-filter-details summary {
    justify-content: center;
    width: 100%;
    padding: 0 8px;
  }

  .nc-history-secondary-controls {
    display: grid;
    grid-template-columns: 1fr;
    margin-top: 8px;
  }

  .nc-history-secondary-controls ha-selector {
    width: 100%;
  }
}

@media (min-width: 801px) and (max-width: 980px) {
  .nc-condition-row {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }

  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr) auto;
  }

  .nc-alert-actions .nc-button {
    flex: 1 1 0;
    min-width: 0;
    justify-content: center;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }
}

@container (min-width: 701px) and (max-width: 800px) {
  .nc-condition-row {
    grid-template-columns: 1fr;
  }
}

@media (min-width: 701px) and (max-width: 800px) {
  .nc-condition-row {
    grid-template-columns: 1fr;
  }

  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr) auto;
  }

  .nc-alert-actions .nc-button {
    flex: 0 0 auto;
    justify-content: center;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }
}

@media (max-width: 700px) {
  .nc-page {
    padding: 14px;
  }

  .nc-header {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr);
    align-items: center;
    gap: 10px;
  }

  .nc-back-button {
    display: inline-grid;
    grid-column: 1;
    grid-row: 2;
  }

  .nc-title {
    grid-column: 1 / -1;
    grid-row: 1;
    min-width: 0;
    justify-self: start;
  }

  .nc-title h1 {
    font-size: 24px;
  }

  .nc-actions {
    grid-column: 1 / -1;
    grid-row: 2;
    justify-content: flex-end;
    width: 100%;
  }

  .nc-alert {
    grid-template-columns: auto minmax(0, 1fr);
  }

  .nc-alert-actions {
    grid-column: 1 / -1;
    width: 100%;
  }

  .nc-alert-actions .nc-button {
    flex: 1 1 0;
    min-width: 0;
    justify-content: center;
    padding: 8px 4px;
  }

  .nc-alert-actions .nc-button-label {
    display: none;
  }

  .nc-grid {
    grid-template-columns: 1fr;
  }

  .nc-modal-body {
    padding: 16px;
  }

  .nc-editor-layout {
    display: block;
    position: relative;
  }

  .nc-editor-shell {
    overflow: visible;
  }

  .nc-editor-header {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    position: relative;
    align-items: start;
    gap: 6px;
    padding: 16px;
    z-index: 100;
  }

  .nc-editor-identity {
    grid-column: 1;
    grid-row: 1;
  }

  .nc-editor-section-controls {
    grid-column: 1 / -1;
    grid-row: 2;
  }

  .nc-section-header:not(.nc-mobile-section-menu) {
    display: none;
  }

  .nc-section-manage-button {
    display: inline-grid;
    grid-column: 2;
    grid-row: 1;
    width: 40px;
    min-height: 40px;
    padding: 8px;
  }

  .nc-section-manage-button ha-icon {
    --mdc-icon-size: 20px;
  }

  .nc-mobile-section-menu {
    display: none;
    position: absolute;
    top: calc(100% - 8px);
    right: 16px;
    z-index: 110;
    width: min(300px, calc(100% - 32px));
    gap: 2px;
    padding: 8px;
    border: 1px solid var(--divider-color);
    border-radius: 10px;
    background: var(--card-background-color);
    box-shadow: var(--ha-box-shadow);
  }

  .nc-mobile-section-menu.mobile-open {
    display: grid;
  }

  .nc-toolbar,
  .nc-yaml .nc-actions {
    display: grid;
    grid-template-columns: 1fr;
    width: 100%;
  }

  .nc-yaml .nc-actions .nc-button {
    width: 100%;
  }

  .nc-code-editor,
  ha-code-editor.nc-alert-yaml-editor {
    --nc-code-editor-height: min(420px, 62vh);
    min-height: min(420px, 62vh);
  }

  .nc-condition-row {
    grid-template-columns: 1fr;
  }

  .nc-recipient-toolbar {
    grid-template-columns: 1fr;
  }

  .nc-history-item {
    grid-template-columns: 1fr;
    gap: 4px;
  }

  .nc-history-filter-heading {
    align-items: center;
    flex-direction: row;
    gap: 8px;
  }

  .nc-history-filter-main {
    flex: 1 1 auto;
    min-width: 0;
  }

  .nc-history-controls {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
  }

  .nc-history-controls ha-input {
    width: 100%;
  }

  .nc-history-filter-details {
    min-width: 0;
  }

  .nc-history-filter-details summary {
    justify-content: center;
    width: 100%;
    padding: 0 8px;
  }

  .nc-history-secondary-controls {
    display: grid;
    grid-template-columns: 1fr;
    margin-top: 8px;
  }

  .nc-history-secondary-controls ha-selector {
    width: 100%;
  }
}
.nc-alert-yaml-modal {
  width: min(1000px, 100%);
  max-height: 92vh;
}

.nc-alert-yaml-editor {
  min-height: 600px;
  width: 100%;
}

ha-code-editor.nc-alert-yaml-editor {
  --code-editor-background-color: var(--secondary-background-color);
  --code-editor-gutter-color: var(--secondary-background-color);
  display: block;
  height: min(650px, 70vh);
  max-height: min(650px, 70vh);
  min-height: min(650px, 70vh);
}
`;

// frontend/yaml-view.ts
var YamlViewElement = class extends i4 {
  static properties = {
    hass: { attribute: false },
    showToast: { attribute: false },
    refreshPanel: { attribute: false }
  };
  yaml = "";
  busyAction = null;
  editor = null;
  loadedHass = null;
  createRenderRoot() {
    return this;
  }
  renderImmediately() {
    D(this.render(), this);
  }
  updated() {
    if (this.hass && this.hass !== this.loadedHass) {
      this.loadedHass = this.hass;
      void this.load();
    }
  }
  async load() {
    try {
      const config = await getConfig(this.hass);
      this.yaml = stringify3(config);
      this.renderImmediately();
      await customElements.whenDefined("ha-code-editor");
      this.editor = this.querySelector("ha-code-editor");
      await this.editor?.updateComplete;
      if (this.editor) {
        this.editor.value = this.yaml;
        constrainCodeEditor(this.editor);
      }
    } catch (err) {
      this.showToast(errorMessage(err), true);
    }
  }
  render() {
    return b2`<div class="nc-card nc-yaml">
      <div class="nc-toolbar">
        <div>
          ${localize(this.hass, "yaml.description")}
        </div>
        <div class="nc-actions">
          <button
            class="nc-button secondary"
            ?disabled=${this.busyAction !== null}
            @click=${this.copyYaml}
          >
            ${localize(this.hass, "yaml.copy")}
          </button>
          <button
            class="nc-button secondary"
            ?disabled=${this.busyAction !== null}
            @click=${this.validateYamlText}
          >
            ${localize(this.hass, "yaml.validate")}
          </button>
          <button
            class="nc-button secondary"
            ?disabled=${this.busyAction !== null}
            @click=${this.reloadYaml}
          >
            ${localize(this.hass, "yaml.reload")}
          </button>
          <button
            class="nc-button"
            ?disabled=${this.busyAction !== null}
            @click=${this.saveYamlText}
          >
            ${localize(this.hass, "yaml.save")}
          </button>
        </div>
      </div>
      <ha-code-editor
        id="nc-yaml-editor"
        class="nc-code-editor nc-yaml-editor"
        mode="yaml"
        language="yaml"
        aria-label=${localize(this.hass, "yaml.aria")}
        @input=${this.updateYaml}
        @value-changed=${this.updateYaml}
        ${n5((editor) => {
      this.editor = editor ?? null;
      if (editor && this.yaml) {
        editor.value = this.yaml;
      }
    })}
      ></ha-code-editor>
    </div>`;
  }
  updateYaml = (event) => {
    this.yaml = event.currentTarget.value || "";
  };
  parseEditor() {
    const value = parse(this.yaml);
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new Error("YAML must contain a mapping.");
    }
    return value;
  }
  copyYaml = async () => {
    try {
      await navigator.clipboard.writeText(this.yaml);
      this.showToast(localize(this.hass, "yaml.copied"));
    } catch (err) {
      this.showToast(errorMessage(err), true);
    }
  };
  reloadYaml = async () => {
    this.busyAction = "reload";
    this.renderImmediately();
    try {
      await reload(this.hass);
      await this.load();
      this.showToast(localize(this.hass, "yaml.reloaded"));
    } catch (err) {
      this.showToast(errorMessage(err), true);
    } finally {
      this.busyAction = null;
      this.renderImmediately();
    }
  };
  validateYamlText = async () => {
    this.busyAction = "validate";
    this.renderImmediately();
    try {
      await validateConfig(this.hass, this.parseEditor());
      this.showToast(localize(this.hass, "yaml.valid"));
    } catch (err) {
      this.showToast(errorMessage(err), true);
    } finally {
      this.busyAction = null;
      this.renderImmediately();
    }
  };
  saveYamlText = async () => {
    this.busyAction = "save";
    this.renderImmediately();
    try {
      const result = await saveConfig(this.hass, this.parseEditor());
      if (!result.saved) {
        throw new Error(localize(this.hass, "yaml.not_saved"));
      }
      this.showToast(localize(this.hass, "yaml.saved"));
      await this.refreshPanel();
    } catch (err) {
      this.showToast(errorMessage(err), true);
    } finally {
      this.busyAction = null;
      this.renderImmediately();
    }
  };
};
customElements.define("ha-notifications-yaml-view", YamlViewElement);

// frontend/panel.ts
var panelTabs = [
  { key: "alerts", label: "panel.tabs.alerts" },
  { key: "active", label: "panel.tabs.active" },
  { key: "history", label: "panel.tabs.history" },
  { key: "yaml", label: "panel.tabs.yaml" }
];
function activeTabClass(active) {
  const classes = ["nc-tab"];
  if (active) {
    classes.push("active");
  }
  return classes.join(" ");
}
function toggleAlertToast(alert) {
  if (alert.enabled) {
    return "Alert disabled.";
  }
  return "Alert enabled.";
}
var HaNotificationsPanel = class extends i4 {
  _hass = null;
  alerts = [];
  automationStatus = {};
  history = [];
  historyAlertId = null;
  historyAlertName = null;
  historyFilters = {
    search: "",
    alertId: "",
    type: "",
    severity: ""
  };
  historyGroupByFlow = false;
  tab = "alerts";
  loading = false;
  refreshing = false;
  refreshTimer = null;
  _registries = null;
  _registriesPromise = null;
  _initialized = false;
  editorActive = false;
  toasts = [];
  set hass(value) {
    const changed = this._hass !== null && this._hass !== value;
    this._hass = value;
    this.requestUpdate();
    if (this.isConnected && !this._initialized) {
      this._initialized = true;
      void this.refresh();
    } else if (this.isConnected && changed) {
      void this.refresh({ silent: true });
    }
  }
  get hass() {
    return this._hass;
  }
  isAdmin() {
    return Boolean(this._hass?.user?.is_admin);
  }
  connectedCallback() {
    super.connectedCallback();
    this.startAutoRefresh();
    if (this._hass) {
      this._initialized = true;
      void this.refresh();
    }
  }
  disconnectedCallback() {
    this.stopAutoRefresh();
    super.disconnectedCallback();
  }
  async getRegistries() {
    if (this._registries) {
      return this._registries;
    }
    if (!this._registriesPromise) {
      this._registriesPromise = loadRegistries(this._hass).then((registries) => {
        this._registries = registries;
        return registries;
      }).catch((err) => {
        this._registriesPromise = null;
        throw err;
      });
    }
    return this._registriesPromise;
  }
  startAutoRefresh() {
    if (this.refreshTimer !== null) {
      return;
    }
    this.refreshTimer = window.setInterval(() => {
      void this.refresh({ silent: true });
    }, 5e3);
  }
  stopAutoRefresh() {
    if (this.refreshTimer === null) {
      return;
    }
    window.clearInterval(this.refreshTimer);
    this.refreshTimer = null;
  }
  editorOpen() {
    return this.editorActive || this.tab === "yaml";
  }
  async refresh({ silent = false } = {}) {
    if (!this._hass || !this.isAdmin() || this.refreshing) {
      return;
    }
    if (silent && this.editorOpen()) {
      return;
    }
    this.refreshing = true;
    if (!silent) {
      this.loading = true;
    }
    this.requestUpdate();
    try {
      const [alertsResult, automationStatusResult, historyResult] = await Promise.allSettled([
        getAlerts(this._hass),
        getAutomationStatus(this._hass),
        getHistory(this._hass, this.historyAlertId || void 0)
      ]);
      if (alertsResult.status === "fulfilled") {
        this.alerts = alertsResult.value;
        this.refreshHistoryAlertName();
      } else if (!silent) {
        this.showToast(errorMessage(alertsResult.reason), true);
      }
      if (historyResult.status === "fulfilled") {
        this.history = historyResult.value;
      } else if (!silent) {
        this.showToast(errorMessage(historyResult.reason), true);
      }
      if (automationStatusResult.status === "fulfilled") {
        this.automationStatus = automationStatusResult.value;
      } else if (!silent) {
        this.showToast(errorMessage(automationStatusResult.reason), true);
      }
    } finally {
      this.refreshing = false;
      if (!silent) {
        this.loading = false;
      }
      this.requestUpdate();
    }
  }
  render() {
    if (!this.isAdmin()) {
      return b2`${this.styleTemplate()}${this.adminRequiredTemplate()}${toastListTemplate(
        this.toasts
      )}`;
    }
    return b2`${this.styleTemplate()}
      <div class="nc-page" ?hidden=${this.editorActive}>
        ${this.headerTemplate()}${this.tabsTemplate()}${this.tabTemplate()}
      </div>
      ${toastListTemplate(this.toasts)}`;
  }
  styleTemplate() {
    return b2`<style>
      ${styles}
    </style>`;
  }
  adminRequiredTemplate() {
    return b2`<div class="nc-page">
      <div class="nc-card nc-empty">
        <h2>${localize(this._hass, "panel.admin_required")}</h2>
        <p>
          ${localize(this._hass, "panel.admin_help")}
        </p>
      </div>
    </div>`;
  }
  headerTemplate() {
    return b2`<div class="nc-header">
      <a
        class="nc-back-button"
        href="/"
        aria-label=${localize(this._hass, "panel.back_home")}
        title=${localize(this._hass, "panel.back_home")}
        @click=${this.navigateHome}
      >
        <ha-icon icon="mdi:arrow-left"></ha-icon>
      </a>
      <div class="nc-title">
        <div class="nc-title-icon">
          <img
            src="/ha_notifications/brand/icon.png"
            alt=""
            aria-hidden="true"
          />
        </div>
        <div>
          <h1>${localize(this._hass, "panel.title")}</h1>
          <p>${localize(this._hass, "panel.subtitle")}</p>
        </div>
      </div>
      <div class="nc-actions">
        <button class="nc-button" @click=${() => this.addAlert()}>
          + ${localize(this._hass, "panel.add_alert")}
        </button>
      </div>
    </div>`;
  }
  navigateHome(event) {
    if (!this._hass?.navigate) {
      return;
    }
    event.preventDefault();
    this._hass.navigate("/");
  }
  tabsTemplate() {
    return b2`<div class="nc-tabs">
      ${panelTabs.map(
      ({ key, label }) => b2`<button
            class=${activeTabClass(this.tab === key)}
            @click=${() => this.selectTab(key)}
          >
            ${localize(this._hass, label)}
          </button>`
    )}
    </div>`;
  }
  tabTemplate() {
    if (this.tab === "alerts") {
      return this.alertsTemplate();
    }
    if (this.tab === "active") {
      return this.activeTemplate();
    }
    if (this.tab === "history") {
      return b2`<ha-notifications-history-view
        .history=${this.history}
        .options=${this.historyViewOptions()}
      ></ha-notifications-history-view>`;
    }
    return b2`<ha-notifications-yaml-view
      .hass=${this._hass}
      .showToast=${(message, error) => this.showToast(message, error)}
      .refreshPanel=${() => this.refresh()}
    ></ha-notifications-yaml-view>`;
  }
  alertsTemplate() {
    return this.alertListTemplate(this.alerts, "panel.no_alerts", true);
  }
  activeTemplate() {
    const activeAlerts = this.alerts.filter((alert) => {
      const status = this.automationStatus[alert.id];
      return Boolean(status?.active_runs || status?.active_runs_uncertain);
    });
    return this.alertListTemplate(activeAlerts, "panel.no_active_alerts");
  }
  alertListTemplate(alerts, emptyTitle, showCreate = false) {
    if (alerts.length) {
      return b2`<div class="nc-alerts">
        ${alerts.map(
        (alert) => renderAlertCard(alert, this._hass, {
          onTest: (item) => this.testAlert(item),
          onToggle: (item) => this.toggleAlert(item),
          onEdit: (item) => this.editAlert(item),
          onShowHistory: (item) => this.showAlertHistory(item),
          onDelete: (item) => this.removeAlert(item)
        }, this.automationStatus[alert.id])
      )}
      </div>`;
    }
    return b2`<div class="nc-card nc-empty">
      <h2>${localize(this._hass, emptyTitle)}</h2>
      ${showCreate ? b2`<p>${localize(this._hass, "panel.create_first")}</p>
            <button class="nc-button" @click=${() => this.addAlert()}>
              ${localize(this._hass, "panel.create_alert")}
            </button>` : ""}
    </div>`;
  }
  historyViewOptions() {
    return {
      alertName: this.historyAlertName,
      hass: this._hass || void 0,
      locale: this._hass?.locale,
      alerts: this.alerts.map((alert) => ({
        id: alert.id,
        name: alert.name
      })),
      filters: this.historyFilters,
      groupByFlow: this.historyGroupByFlow,
      types: [
        ...new Set(this.history.map((item) => item.event?.type).filter(Boolean))
      ],
      onFiltersChanged: (filters) => {
        this.historyFilters = filters;
        this.requestUpdate();
      },
      onGroupByFlowChanged: (groupByFlow) => {
        this.historyGroupByFlow = groupByFlow;
        this.requestUpdate();
      },
      onAlertSelected: (alertId, alertName) => this.showHistoryForAlert(alertId, alertName),
      onShowAll: () => this.showAllHistory()
    };
  }
  selectTab(tab) {
    this.tab = tab;
    this.requestUpdate();
  }
  async testAlert(alert) {
    if (!this._hass) return;
    try {
      await triggerAlert(this._hass, alert.id);
      this.showToast(localize(this._hass, "panel.test_triggered"));
      await this.refresh({ silent: true });
    } catch (error) {
      this.showToast(errorMessage(error), true);
    }
  }
  refreshHistoryAlertName() {
    if (!this.historyAlertId) {
      return;
    }
    const alert = this.alerts.find((item) => item.id === this.historyAlertId);
    if (alert) {
      this.historyAlertName = alert.name;
    }
  }
  addAlert = async () => {
    let registries;
    try {
      registries = await this.getRegistries();
    } catch (err) {
      this.showToast(errorMessage(err), true);
      return;
    }
    this.editorActive = true;
    this.requestUpdate();
    openEditor({
      root: this.renderRoot,
      hass: this._hass,
      alert: null,
      registries,
      onValidateCondition: async (draft) => {
        await validateAlert(this._hass, draft);
        this.showToast(localize(this._hass, "panel.condition_valid"));
      },
      onSave: async (alert) => {
        const saved = await saveAlert(this._hass, alert);
        this.showToast(localize(this._hass, "panel.alert_created"));
        return saved;
      },
      onSaved: async () => {
        await this.refresh();
      },
      onClosed: () => {
        this.editorActive = false;
        void this.refresh();
        this.requestUpdate();
      }
    });
  };
  async editAlert(alert) {
    let registries;
    try {
      registries = await this.getRegistries();
    } catch (err) {
      this.showToast(errorMessage(err), true);
      return;
    }
    this.editorActive = true;
    this.requestUpdate();
    openEditor({
      root: this.renderRoot,
      hass: this._hass,
      alert,
      registries,
      onValidateCondition: async (draft) => {
        await validateAlert(this._hass, draft);
        this.showToast(localize(this._hass, "panel.condition_valid"));
      },
      onSave: async (updated) => {
        const saved = await saveAlert(this._hass, updated);
        this.replaceSavedAlert(saved);
        this.showToast(localize(this._hass, "panel.alert_saved"));
        return saved;
      },
      onSaved: async () => {
        await this.refresh();
      },
      onClosed: () => {
        this.editorActive = false;
        void this.refresh();
        this.requestUpdate();
      }
    });
  }
  replaceSavedAlert(saved) {
    this.alerts = this.alerts.map((item) => {
      if (item.id === saved.id) {
        return {
          ...item,
          ...saved
        };
      }
      return item;
    });
    this.requestUpdate();
  }
  async showAlertHistory(alert) {
    await this.showHistoryForAlert(alert.id, alert.name);
  }
  async showHistoryForAlert(alertId, alertName) {
    if (!this._hass) {
      return;
    }
    this.historyAlertId = alertId;
    this.historyAlertName = alertName;
    this.historyFilters = {
      search: "",
      alertId: "",
      type: "",
      severity: ""
    };
    this.tab = "history";
    this.history = [];
    await this.refresh();
    this.requestUpdate();
  }
  async showAllHistory() {
    if (!this._hass) {
      return;
    }
    this.historyAlertId = null;
    this.historyAlertName = null;
    this.historyFilters = {
      search: "",
      alertId: "",
      type: "",
      severity: ""
    };
    this.tab = "history";
    this.history = [];
    await this.refresh();
    this.requestUpdate();
  }
  async toggleAlert(alert) {
    try {
      await saveAlert(this._hass, { ...alert, enabled: !alert.enabled });
      this.showToast(toggleAlertToast(alert));
      await this.refresh();
    } catch (err) {
      this.showToast(errorMessage(err), true);
    }
  }
  async removeAlert(alert) {
    if (!window.confirm(`Delete "${alert.name}"?`)) {
      return;
    }
    try {
      await deleteAlert(this._hass, alert.id);
      this.showToast(localize(this._hass, "panel.alert_deleted"));
      await this.refresh();
    } catch (err) {
      this.showToast(errorMessage(err), true);
    }
  }
  formatTime(value) {
    return formatLocalDateTime(value, false, this._hass?.locale);
  }
  showToast(message, error = false) {
    showToast(this, message, error);
  }
};
if (!customElements.get("ha-notifications-panel")) {
  customElements.define("ha-notifications-panel", HaNotificationsPanel);
}
var HaNotificationsCard = class extends HaNotificationsPanel {
  config = null;
  setConfig(config) {
    if (!config || config.type !== "custom:ha-notifications-card") {
      throw new Error("Card type must be custom:ha-notifications-card.");
    }
    this.config = config;
    this.requestUpdate();
  }
  getCardSize() {
    return 12;
  }
  static getStubConfig() {
    return { type: "custom:ha-notifications-card" };
  }
};
if (!customElements.get("ha-notifications-card")) {
  customElements.define("ha-notifications-card", HaNotificationsCard);
}
var customCardWindow = window;
customCardWindow.customCards = customCardWindow.customCards || [];
if (!customCardWindow.customCards.some(
  (card) => card.type === "ha-notifications-card"
)) {
  customCardWindow.customCards.push({
    type: "ha-notifications-card",
    name: "HA Notifications",
    description: "Manage HA Notifications alerts, history, and YAML."
  });
}
/*! Bundled license information:

@lit/reactive-element/css-tag.js:
  (**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

@lit/reactive-element/reactive-element.js:
lit-html/lit-html.js:
lit-element/lit-element.js:
lit-html/directive.js:
lit-html/async-directive.js:
  (**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/is-server.js:
  (**
   * @license
   * Copyright 2022 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)

lit-html/directive-helpers.js:
lit-html/directives/ref.js:
  (**
   * @license
   * Copyright 2020 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   *)
*/
